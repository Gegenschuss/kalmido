--
-- PostgreSQL database dump
--

\restrict p5X2aQRSk5xstjDtvA31qQM58pvJz39efiP7zi1rlJFM6L8Ei72usCwZ5tbTkEZ

-- Dumped from database version 17.11 (Debian 17.11-1.pgdg13+2)
-- Dumped by pg_dump version 17.11 (Debian 17.11-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA public;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


--
-- Name: kalmido_dl_touch(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.kalmido_dl_touch() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE k text; o bigint; n bigint; ol bigint; nl bigint; u bigint;
BEGIN
  IF TG_ARGV[0] = 'full' THEN  -- one unstamped "full" row is enough
    IF NOT EXISTS (SELECT 1 FROM dl_changes WHERE ver IS NULL AND task_id IS NULL) THEN INSERT INTO dl_changes(task_id) VALUES (NULL); END IF;
    RETURN NULL;
  END IF;
  FOREACH k IN ARRAY TG_ARGV LOOP
    o := NULL; n := NULL; ol := NULL; nl := NULL; u := NULL;
    IF TG_OP <> 'INSERT' THEN o := (to_jsonb(OLD)->>k)::bigint; END IF;
    IF TG_OP <> 'DELETE' THEN n := (to_jsonb(NEW)->>k)::bigint; END IF;
    IF TG_TABLE_NAME = 'tasks' THEN  -- the list before / after: who may learn that it left
      IF TG_OP <> 'INSERT' THEN ol := OLD.list_id; END IF;
      IF TG_OP <> 'DELETE' THEN nl := NEW.list_id; END IF;
    END IF;
    IF TG_TABLE_NAME = 'task_seen' THEN  -- a read mark changes the task for its reader only
      IF TG_OP <> 'DELETE' THEN u := NEW.user_id; ELSE u := OLD.user_id; END IF;
    END IF;
    IF o IS NOT NULL THEN INSERT INTO dl_changes(task_id, list_id, user_id) VALUES (o, ol, u); END IF;
    IF n IS NOT NULL AND (n IS DISTINCT FROM o OR nl IS DISTINCT FROM ol) THEN INSERT INTO dl_changes(task_id, list_id, user_id) VALUES (n, nl, u); END IF;
  END LOOP;
  RETURN NULL;
END $$;


--
-- Name: kalmido_fold(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.kalmido_fold(t text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE STRICT PARALLEL SAFE
    AS $$
DECLARE x text := lower(public.unaccent('public.unaccent'::regdictionary, t)); y text := lower(public.unaccent('public.unaccent'::regdictionary, replace(replace(replace(replace(replace(replace(replace(t,'ä','ae'),'ö','oe'),'ü','ue'),'Ä','Ae'),'Ö','Oe'),'Ü','Ue'),'ß','ss')));
BEGIN RETURN CASE WHEN x = y THEN x ELSE x || chr(10) || y END; END $$;


--
-- Name: kalmido_list_e2e_members(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.kalmido_list_e2e_members() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE m TEXT; g BIGINT;
BEGIN
  IF TG_OP = 'DELETE' THEN
    SELECT e2e, e2e_gen INTO m, g FROM lists WHERE id=OLD.list_id;
    IF m IS NOT NULL THEN
      -- rotation pending only when the person really held a key (not for someone who only waited on the list)
      IF EXISTS (SELECT 1 FROM list_keys WHERE list_id=OLD.list_id AND user_id=OLD.user_id) THEN
        UPDATE lists SET e2e_rotate=e2e_gen WHERE id=OLD.list_id;
      END IF;
      DELETE FROM list_keys WHERE list_id=OLD.list_id AND user_id=OLD.user_id;
      DELETE FROM list_key_pending WHERE list_id=OLD.list_id AND user_id=OLD.user_id;
    END IF;
    RETURN OLD;
  END IF;
  SELECT e2e, e2e_gen INTO m, g FROM lists WHERE id=NEW.list_id;
  IF m IS NULL THEN RETURN NEW; END IF;
  IF NEW.role = 'participant' THEN RAISE EXCEPTION 'kalmido_list_e2e: participant role in a list with the lock'; END IF;
  IF EXISTS (SELECT 1 FROM users WHERE id=NEW.user_id AND COALESCE(kind, '')='agent') THEN
    RAISE EXCEPTION 'kalmido_list_e2e: agent in a list with the lock'; END IF;
  IF NOT EXISTS (SELECT 1 FROM list_keys WHERE list_id=NEW.list_id AND user_id=NEW.user_id AND gen=g) THEN
    INSERT INTO list_key_pending(list_id, user_id, since)
      VALUES (NEW.list_id, NEW.user_id, to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"+00:00"'))
      ON CONFLICT DO NOTHING;
  END IF;
  RETURN NEW;
END $$;


--
-- Name: kalmido_ml_prune(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.kalmido_ml_prune() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE prev text := current_setting('app.role', true);
BEGIN
  IF to_regclass('task_links') IS NULL THEN RETURN NULL; END IF;
  PERFORM set_config('app.role', 'system', true);
  IF TG_TABLE_NAME = 'tasks' THEN
    DELETE FROM task_links k WHERE k.task_id = NEW.id AND (k.list_id = NEW.list_id OR NEW.parent_id IS NOT NULL
      OR (SELECT x.org_id FROM lists x WHERE x.id = k.list_id) IS DISTINCT FROM (SELECT o.org_id FROM lists o WHERE o.id = NEW.list_id));
  ELSE
    DELETE FROM task_links k WHERE (k.list_id = NEW.id OR k.task_id IN (SELECT t.id FROM tasks t WHERE t.list_id = NEW.id))
      AND (SELECT x.org_id FROM lists x WHERE x.id = k.list_id) IS DISTINCT FROM
          (SELECT o.org_id FROM tasks t JOIN lists o ON o.id = t.list_id WHERE t.id = k.task_id);
  END IF;
  PERFORM set_config('app.role', COALESCE(prev, ''), true);
  RETURN NULL;
END $$;


--
-- Name: kalmido_org_count(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.kalmido_org_count() RETURNS bigint
    LANGUAGE plpgsql STABLE
    AS $$DECLARE prev text := current_setting('app.role', true); n bigint; BEGIN PERFORM set_config('app.role', 'system', true); SELECT COUNT(*) INTO n FROM orgs WHERE personal_of IS NULL; PERFORM set_config('app.role', COALESCE(prev, ''), true); RETURN n; END$$;


--
-- Name: kalmido_time_task_list(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.kalmido_time_task_list() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN UPDATE time_entries SET list_id=NEW.list_id WHERE task_id=NEW.id; RETURN NULL; END $$;


--
-- Name: kalmido_time_task_title(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.kalmido_time_task_title() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN UPDATE time_entries SET task_title=NEW.title WHERE task_id=NEW.id AND user_id IN
  (SELECT owner_id FROM lists WHERE id=NEW.list_id UNION SELECT user_id FROM list_members WHERE list_id=NEW.list_id
   AND (role!='participant' OR user_id IS NOT DISTINCT FROM NEW.assignee_id)); RETURN NULL; END $$;


--
-- Name: kalmido_time_title_e2e(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.kalmido_time_title_e2e() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN IF left(NEW.task_title, 5) = 'e2e1:' THEN NEW.task_title := ''; END IF; RETURN NEW; END $$;


--
-- Name: kalmido_wiki_e2e_members(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.kalmido_wiki_e2e_members() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE sid BIGINT; g BIGINT; prev TEXT := current_setting('app.role', true);
BEGIN
  -- wiki_spaces has row-level security (core/rls.py): a membership change made without the organisation in the context
  -- (accepting an invitation, an instance admin) must still see the space -- "system" inside the trigger only, like
  -- kalmido_org_count(), the caller's value back before it returns
  PERFORM set_config('app.role', 'system', true);
  IF TG_OP = 'DELETE' THEN
    SELECT id INTO sid FROM wiki_spaces WHERE org_id=OLD.org_id AND e2e IS NOT NULL;
    IF sid IS NOT NULL THEN
      IF EXISTS (SELECT 1 FROM wiki_keys WHERE space_id=sid AND user_id=OLD.user_id) THEN
        UPDATE wiki_spaces SET e2e_rotate=e2e_gen WHERE id=sid;
      END IF;
      DELETE FROM wiki_keys WHERE space_id=sid AND user_id=OLD.user_id;
      DELETE FROM wiki_key_pending WHERE space_id=sid AND user_id=OLD.user_id;
    END IF;
    PERFORM set_config('app.role', COALESCE(prev, ''), true);
    RETURN OLD;
  END IF;
  SELECT id, e2e_gen INTO sid, g FROM wiki_spaces WHERE org_id=NEW.org_id AND e2e IS NOT NULL;
  IF sid IS NULL OR EXISTS (SELECT 1 FROM users WHERE id=NEW.user_id AND COALESCE(kind, '')='agent') THEN
    PERFORM set_config('app.role', COALESCE(prev, ''), true);
    RETURN NEW;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM wiki_keys WHERE space_id=sid AND user_id=NEW.user_id AND gen=g) THEN
    INSERT INTO wiki_key_pending(space_id, user_id, since)
      VALUES (sid, NEW.user_id, to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"+00:00"'))
      ON CONFLICT DO NOTHING;
  END IF;
  PERFORM set_config('app.role', COALESCE(prev, ''), true);
  RETURN NEW;
END $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activity (
    id bigint NOT NULL,
    task_id bigint NOT NULL,
    user_id bigint,
    kind text NOT NULL,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at text NOT NULL
);


--
-- Name: activity_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.activity ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.activity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: admin_alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_alerts (
    id bigint NOT NULL,
    kind text NOT NULL,
    key text NOT NULL,
    message text NOT NULL,
    tmpl text DEFAULT '[]'::text NOT NULL,
    created_at text NOT NULL,
    sent_at text,
    delivered bigint DEFAULT 0 NOT NULL,
    state text DEFAULT 'sent'::text NOT NULL,
    repeats bigint DEFAULT 0 NOT NULL
);


--
-- Name: admin_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.admin_alerts ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.admin_alerts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: admin_login_ips; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_login_ips (
    user_id bigint NOT NULL,
    ip_hash text NOT NULL,
    first_at text NOT NULL,
    last_at text NOT NULL
);


--
-- Name: agent_audit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_audit (
    id bigint NOT NULL,
    agent_id bigint NOT NULL,
    at text NOT NULL,
    day text NOT NULL,
    method text NOT NULL,
    route text NOT NULL,
    status bigint NOT NULL,
    task_id bigint,
    list_id bigint,
    ms bigint DEFAULT 0 NOT NULL,
    scope text DEFAULT ''::text NOT NULL
);


--
-- Name: agent_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.agent_audit ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.agent_audit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: agent_bridges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_bridges (
    agent_id bigint NOT NULL,
    list_a bigint NOT NULL,
    list_b bigint NOT NULL,
    by_id bigint,
    at text NOT NULL
);


--
-- Name: agent_chat; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_chat (
    id bigint NOT NULL,
    agent_id bigint NOT NULL,
    user_id bigint NOT NULL,
    sender text NOT NULL,
    body text NOT NULL,
    task_id bigint,
    created_at text NOT NULL,
    read_at text,
    delivered_at text,
    choices jsonb,
    choice text,
    job_id bigint,
    job_parent bigint,
    reply_to bigint,
    offer_save bigint DEFAULT 0 NOT NULL,
    edited_at text,
    edits jsonb,
    kind text,
    job_msg text,
    client_id text,
    pinned_at text,
    pinned_by bigint
);


--
-- Name: agent_chat_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.agent_chat ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.agent_chat_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: agent_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_events (
    id bigint NOT NULL,
    agent_id bigint NOT NULL,
    uuid text NOT NULL,
    event text NOT NULL,
    payload text DEFAULT '{}'::text NOT NULL,
    created_at text NOT NULL
);


--
-- Name: agent_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.agent_events ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.agent_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: agent_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_jobs (
    id bigint NOT NULL,
    agent_id bigint NOT NULL,
    task_id bigint,
    user_id bigint,
    title text NOT NULL,
    state text DEFAULT 'running'::text NOT NULL,
    log text DEFAULT ''::text NOT NULL,
    action text,
    action_by bigint,
    action_at text,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    kind text,
    input text,
    proposal text,
    prop_state text DEFAULT ''::text NOT NULL,
    applied text,
    list_id bigint,
    approval text,
    name text,
    parent_id bigint
);


--
-- Name: agent_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.agent_jobs ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.agent_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: agent_list_access; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_list_access (
    agent_id bigint NOT NULL,
    list_id bigint NOT NULL,
    day text NOT NULL,
    kind text NOT NULL,
    n bigint DEFAULT 0 NOT NULL
);


--
-- Name: agent_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_schedules (
    id bigint NOT NULL,
    agent_id bigint NOT NULL,
    user_id bigint NOT NULL,
    title text NOT NULL,
    prompt text NOT NULL,
    freq text DEFAULT 'daily'::text NOT NULL,
    days text DEFAULT ''::text NOT NULL,
    at_time text DEFAULT '09:00'::text NOT NULL,
    tz text DEFAULT ''::text NOT NULL,
    list_id bigint,
    enabled bigint DEFAULT 1 NOT NULL,
    next_at text,
    last_at text,
    last_state text DEFAULT ''::text NOT NULL,
    last_seq bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    list_check bigint DEFAULT 0 NOT NULL
);


--
-- Name: agent_schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.agent_schedules ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.agent_schedules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: agent_setup_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_setup_codes (
    id bigint NOT NULL,
    agent_id bigint NOT NULL,
    code_hash text NOT NULL,
    os text DEFAULT ''::text NOT NULL,
    folder text DEFAULT ''::text NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    expires_at text NOT NULL,
    used_at text,
    token_id bigint
);


--
-- Name: agent_setup_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.agent_setup_codes ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.agent_setup_codes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: agent_steps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_steps (
    id bigint NOT NULL,
    agent_id bigint NOT NULL,
    user_id bigint NOT NULL,
    job_id bigint,
    message_id bigint,
    state text DEFAULT 'live'::text NOT NULL,
    text text NOT NULL,
    created_at text NOT NULL
);


--
-- Name: agent_steps_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.agent_steps ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.agent_steps_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: agent_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_usage (
    id bigint NOT NULL,
    agent_id bigint NOT NULL,
    model text NOT NULL,
    input_tokens bigint DEFAULT 0 NOT NULL,
    output_tokens bigint DEFAULT 0 NOT NULL,
    cache_read_tokens bigint DEFAULT 0 NOT NULL,
    cache_write_tokens bigint DEFAULT 0 NOT NULL,
    cost_usd double precision,
    task_id bigint,
    list_id bigint,
    job_id bigint,
    note text DEFAULT ''::text NOT NULL,
    day text NOT NULL,
    created_at text NOT NULL
);


--
-- Name: agent_usage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.agent_usage ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.agent_usage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: agents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agents (
    user_id bigint NOT NULL,
    enabled bigint DEFAULT 1 NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'idle'::text NOT NULL,
    status_text text DEFAULT ''::text NOT NULL,
    status_at text,
    webhook_id bigint,
    created_at text NOT NULL,
    status_task bigint,
    usage_limits text DEFAULT ''::text NOT NULL,
    usage_alerted text DEFAULT ''::text NOT NULL,
    proposals text DEFAULT 'shared'::text NOT NULL,
    runtime text DEFAULT ''::text NOT NULL,
    reset_seq bigint DEFAULT 0 NOT NULL,
    last_poll_at text,
    typing_user bigint,
    typing_until double precision DEFAULT 0 NOT NULL,
    owner_id bigint,
    admin_paused bigint DEFAULT 0 NOT NULL,
    scopes text DEFAULT ''::text NOT NULL,
    allowed_ips text DEFAULT ''::text NOT NULL,
    provider text DEFAULT ''::text NOT NULL,
    org_id bigint,
    list_ids text DEFAULT ''::text NOT NULL,
    host_info text DEFAULT ''::text NOT NULL,
    quota text DEFAULT ''::text NOT NULL,
    stale_sent text DEFAULT ''::text NOT NULL,
    office_drafts bigint DEFAULT 0 NOT NULL
);

ALTER TABLE ONLY public.agents FORCE ROW LEVEL SECURITY;


--
-- Name: api_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_tokens (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    name text NOT NULL,
    token_hash text NOT NULL,
    prefix text DEFAULT ''::text NOT NULL,
    scopes text DEFAULT 'read'::text NOT NULL,
    expires_at text,
    created_at text NOT NULL,
    last_used_at text,
    allowed_ips text DEFAULT ''::text NOT NULL,
    list_ids text DEFAULT ''::text NOT NULL,
    host text DEFAULT ''::text NOT NULL,
    folder text DEFAULT ''::text NOT NULL,
    os text DEFAULT ''::text NOT NULL
);


--
-- Name: api_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.api_tokens ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.api_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: app_passwords; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_passwords (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    name text NOT NULL,
    pw_hash text NOT NULL,
    created_at text NOT NULL,
    last_used_at text,
    last_client text,
    caps text DEFAULT ''::text NOT NULL
);


--
-- Name: app_passwords_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.app_passwords ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.app_passwords_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: appt_bookings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.appt_bookings (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    type_id bigint,
    start text NOT NULL,
    "end" text NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    email text DEFAULT ''::text NOT NULL,
    phone text DEFAULT ''::text NOT NULL,
    message text DEFAULT ''::text NOT NULL,
    lang text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    confirm_hash text,
    cancel_hash text,
    ip text DEFAULT ''::text NOT NULL,
    event_id bigint,
    contact_id bigint,
    deal_id bigint,
    cancel_reason text DEFAULT ''::text NOT NULL,
    cancelled_by text DEFAULT ''::text NOT NULL,
    created_at text NOT NULL,
    confirmed_at text,
    cancelled_at text
);


--
-- Name: appt_bookings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.appt_bookings ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.appt_bookings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: appt_pages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.appt_pages (
    user_id bigint NOT NULL,
    slug text NOT NULL,
    enabled bigint DEFAULT 0 NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    intro text DEFAULT ''::text NOT NULL,
    cal_id bigint,
    office_org_id bigint,
    hours text DEFAULT ''::text NOT NULL,
    tz text DEFAULT ''::text NOT NULL,
    created_at text NOT NULL,
    updated_at text NOT NULL
);


--
-- Name: appt_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.appt_types (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    duration_min bigint DEFAULT 30 NOT NULL,
    buffer_min bigint DEFAULT 0 NOT NULL,
    notice_h bigint DEFAULT 12 NOT NULL,
    days_ahead bigint DEFAULT 30 NOT NULL,
    location text DEFAULT ''::text NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    active bigint DEFAULT 1 NOT NULL,
    sort double precision DEFAULT 0 NOT NULL,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    deleted_at text
);


--
-- Name: appt_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.appt_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.appt_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: assistant_access; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assistant_access (
    user_id bigint NOT NULL,
    list_id bigint NOT NULL,
    created_at text NOT NULL
);


--
-- Name: assistant_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assistant_log (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    kind text NOT NULL,
    task_id bigint,
    list_id bigint,
    job_id bigint,
    status text NOT NULL,
    ms bigint DEFAULT 0 NOT NULL,
    chars_in bigint DEFAULT 0 NOT NULL,
    chars_out bigint DEFAULT 0 NOT NULL,
    model text DEFAULT ''::text NOT NULL,
    at text NOT NULL,
    day text NOT NULL
);


--
-- Name: assistant_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.assistant_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.assistant_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attachments (
    id bigint NOT NULL,
    task_id bigint NOT NULL,
    name text NOT NULL,
    mime text DEFAULT ''::text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    path text NOT NULL,
    created_at text NOT NULL,
    comment_id bigint,
    user_id bigint,
    enc bigint DEFAULT 0 NOT NULL,
    enc_by bigint,
    e2e_gen bigint DEFAULT 0 NOT NULL
);


--
-- Name: attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.attachments ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.attachments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: book_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.book_members (
    book_id bigint NOT NULL,
    user_id bigint NOT NULL,
    role text DEFAULT 'view'::text NOT NULL,
    added_at text NOT NULL
);


--
-- Name: bookmarks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bookmarks (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    org_id bigint,
    url text NOT NULL,
    url_key text NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    site text DEFAULT ''::text NOT NULL,
    image text DEFAULT ''::text NOT NULL,
    image_mime text DEFAULT ''::text NOT NULL,
    image_url text DEFAULT ''::text NOT NULL,
    tags text DEFAULT '[]'::text NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    state text DEFAULT 'unread'::text NOT NULL,
    text text DEFAULT ''::text NOT NULL,
    preview text DEFAULT 'pending'::text NOT NULL,
    preview_error text DEFAULT ''::text NOT NULL,
    fetched_at text,
    src text DEFAULT ''::text NOT NULL,
    src_id text DEFAULT ''::text NOT NULL,
    kk_arch bigint DEFAULT 0 NOT NULL,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    deleted_at text
);

ALTER TABLE ONLY public.bookmarks FORCE ROW LEVEL SECURITY;


--
-- Name: bookmarks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.bookmarks ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.bookmarks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: books; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.books (
    id bigint NOT NULL,
    owner_id bigint NOT NULL,
    name text NOT NULL,
    color text DEFAULT ''::text NOT NULL,
    src_id bigint,
    occ_list_id bigint,
    created_at text NOT NULL,
    changed_at text NOT NULL,
    org_id bigint,
    owner_org_id bigint,
    org_role text DEFAULT 'view'::text NOT NULL
);

ALTER TABLE ONLY public.books FORCE ROW LEVEL SECURITY;


--
-- Name: books_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.books ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.books_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: budget_cats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budget_cats (
    id bigint NOT NULL,
    list_id bigint NOT NULL,
    name text NOT NULL,
    kind text DEFAULT 'out'::text NOT NULL,
    lim text DEFAULT ''::text NOT NULL,
    sort bigint DEFAULT 0 NOT NULL,
    sid bigint DEFAULT 0 NOT NULL,
    created_at text NOT NULL
);


--
-- Name: budget_cats_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.budget_cats ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.budget_cats_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: budget_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budget_entries (
    id bigint NOT NULL,
    list_id bigint NOT NULL,
    day text NOT NULL,
    amount text DEFAULT ''::text NOT NULL,
    kind text DEFAULT 'out'::text NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    counterpart text DEFAULT ''::text NOT NULL,
    cat_id bigint,
    recurring_id bigint,
    rmonth text DEFAULT ''::text NOT NULL,
    source text DEFAULT 'manual'::text NOT NULL,
    dkey text DEFAULT ''::text NOT NULL,
    sid bigint DEFAULT 0 NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL
);


--
-- Name: budget_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.budget_entries ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.budget_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: budget_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budget_files (
    id bigint NOT NULL,
    entry_id bigint NOT NULL,
    list_id bigint NOT NULL,
    name text NOT NULL,
    mime text DEFAULT ''::text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    path text NOT NULL,
    user_id bigint,
    created_at text NOT NULL
);


--
-- Name: budget_files_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.budget_files ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.budget_files_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: budget_meta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budget_meta (
    list_id bigint NOT NULL,
    mappings text DEFAULT '{}'::text NOT NULL,
    updated_at text NOT NULL
);


--
-- Name: budget_recurring; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budget_recurring (
    id bigint NOT NULL,
    list_id bigint NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    amount text DEFAULT ''::text NOT NULL,
    kind text DEFAULT 'out'::text NOT NULL,
    cat_id bigint,
    per text DEFAULT 'month'::text NOT NULL,
    start text NOT NULL,
    until text,
    contract_task_id bigint,
    sid bigint DEFAULT 0 NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL
);


--
-- Name: budget_recurring_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.budget_recurring ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.budget_recurring_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: cal_dav_res; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cal_dav_res (
    sub_id bigint NOT NULL,
    uid text NOT NULL,
    href text NOT NULL,
    etag text DEFAULT ''::text NOT NULL,
    rec bigint DEFAULT 0 NOT NULL
);


--
-- Name: cal_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cal_events (
    id bigint NOT NULL,
    sub_id bigint NOT NULL,
    uid text DEFAULT ''::text NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    location text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    all_day bigint DEFAULT 0 NOT NULL,
    start text NOT NULL,
    "end" text NOT NULL,
    d0 text NOT NULL,
    d1 text NOT NULL
);


--
-- Name: cal_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.cal_events ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.cal_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: cal_subs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cal_subs (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    kind text NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    color text DEFAULT ''::text NOT NULL,
    visible bigint DEFAULT 1 NOT NULL,
    "interval" bigint DEFAULT 15 NOT NULL,
    url text NOT NULL,
    url_hint text DEFAULT ''::text NOT NULL,
    username text DEFAULT ''::text NOT NULL,
    password text DEFAULT ''::text NOT NULL,
    etag text DEFAULT ''::text NOT NULL,
    last_modified text DEFAULT ''::text NOT NULL,
    ctag text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    error text DEFAULT ''::text NOT NULL,
    fails bigint DEFAULT 0 NOT NULL,
    events bigint DEFAULT 0 NOT NULL,
    truncated bigint DEFAULT 0 NOT NULL,
    digest text DEFAULT ''::text NOT NULL,
    tried_at text,
    synced_at text,
    fetched_at text,
    changed_at text,
    created_at text NOT NULL,
    dav_write bigint DEFAULT 0 NOT NULL,
    dav_can_write bigint DEFAULT 0 NOT NULL
);


--
-- Name: cal_subs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.cal_subs ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.cal_subs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: chat_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_files (
    id bigint NOT NULL,
    message_id bigint NOT NULL,
    name text NOT NULL,
    mime text DEFAULT ''::text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    path text NOT NULL,
    created_at text NOT NULL
);


--
-- Name: chat_files_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.chat_files ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.chat_files_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: chat_reactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_reactions (
    message_id bigint NOT NULL,
    user_id bigint NOT NULL,
    emoji text NOT NULL,
    created_at text NOT NULL
);


--
-- Name: chat_saves; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_saves (
    user_id bigint NOT NULL,
    kind text NOT NULL,
    msg_id bigint NOT NULL,
    task_id bigint,
    created_at text NOT NULL
);


--
-- Name: clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clients (
    id bigint NOT NULL,
    org_id bigint,
    name text NOT NULL,
    icon text DEFAULT ''::text NOT NULL,
    color text DEFAULT ''::text NOT NULL,
    contact text DEFAULT ''::text NOT NULL,
    email text DEFAULT ''::text NOT NULL,
    phone text DEFAULT ''::text NOT NULL,
    address text DEFAULT ''::text NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    rate double precision,
    budget_h double precision,
    budget_amount double precision,
    archived bigint DEFAULT 0 NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    street text DEFAULT ''::text NOT NULL,
    zip text DEFAULT ''::text NOT NULL,
    city text DEFAULT ''::text NOT NULL,
    country text DEFAULT ''::text NOT NULL,
    vat_id text DEFAULT ''::text NOT NULL,
    customer_no text DEFAULT ''::text NOT NULL,
    buyer_reference text DEFAULT ''::text NOT NULL,
    email_invoice text DEFAULT ''::text NOT NULL,
    payment_terms_days bigint,
    import_run_id bigint,
    display_name text DEFAULT ''::text NOT NULL,
    address_extra text DEFAULT ''::text NOT NULL
);

ALTER TABLE ONLY public.clients FORCE ROW LEVEL SECURITY;


--
-- Name: clients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clients ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: comment_reactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comment_reactions (
    comment_id bigint NOT NULL,
    user_id bigint NOT NULL,
    emoji text NOT NULL,
    created_at text NOT NULL
);


--
-- Name: comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comments (
    id bigint NOT NULL,
    task_id bigint NOT NULL,
    user_id bigint,
    body text DEFAULT ''::text NOT NULL,
    mentions text DEFAULT ''::text NOT NULL,
    created_at text NOT NULL,
    edited_at text,
    deleted_at text,
    suggestion text,
    reply_to bigint,
    choices jsonb,
    choice jsonb,
    ext_name text,
    portal bigint DEFAULT 0 NOT NULL,
    rule_name text
);


--
-- Name: comments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.comments ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: conn_blocks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conn_blocks (
    user_id bigint NOT NULL,
    blocked_id bigint NOT NULL,
    created_at text NOT NULL
);


--
-- Name: conn_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conn_links (
    a_id bigint NOT NULL,
    b_id bigint NOT NULL,
    created_at text NOT NULL,
    deleted_at text,
    deleted_by bigint
);


--
-- Name: conn_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conn_requests (
    id bigint NOT NULL,
    from_id bigint NOT NULL,
    to_id bigint NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    created_at text NOT NULL,
    decided_at text
);


--
-- Name: conn_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.conn_requests ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.conn_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: contact_care; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contact_care (
    user_id bigint NOT NULL,
    contact_id bigint NOT NULL,
    every_days bigint DEFAULT 0 NOT NULL,
    last text DEFAULT ''::text NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    updated_at text NOT NULL
);


--
-- Name: contact_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contact_links (
    src_id bigint NOT NULL,
    uid text NOT NULL,
    kind text NOT NULL,
    task_id bigint,
    digest text DEFAULT ''::text NOT NULL,
    book text DEFAULT ''::text NOT NULL
);


--
-- Name: contact_occ; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contact_occ (
    contact_id bigint NOT NULL,
    kind text NOT NULL,
    task_id bigint,
    digest text DEFAULT ''::text NOT NULL
);


--
-- Name: contact_srcs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contact_srcs (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    url text NOT NULL,
    url_hint text DEFAULT ''::text NOT NULL,
    username text DEFAULT ''::text NOT NULL,
    password text DEFAULT ''::text NOT NULL,
    list_id bigint,
    lead bigint DEFAULT 7 NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    error text DEFAULT ''::text NOT NULL,
    fails bigint DEFAULT 0 NOT NULL,
    count bigint DEFAULT 0 NOT NULL,
    tried_at text,
    synced_at text,
    created_at text NOT NULL
);


--
-- Name: contact_srcs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.contact_srcs ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.contact_srcs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: contact_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contact_tasks (
    contact_id bigint NOT NULL,
    task_id bigint NOT NULL,
    kind text DEFAULT 'about'::text NOT NULL,
    added_by bigint,
    added_at text NOT NULL
);


--
-- Name: contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contacts (
    id bigint NOT NULL,
    book_id bigint NOT NULL,
    uid text NOT NULL,
    href text NOT NULL,
    kind text DEFAULT 'individual'::text NOT NULL,
    fn text DEFAULT ''::text NOT NULL,
    given text DEFAULT ''::text NOT NULL,
    family text DEFAULT ''::text NOT NULL,
    middle text DEFAULT ''::text NOT NULL,
    prefix text DEFAULT ''::text NOT NULL,
    suffix text DEFAULT ''::text NOT NULL,
    nickname text DEFAULT ''::text NOT NULL,
    org text DEFAULT ''::text NOT NULL,
    dept text DEFAULT ''::text NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    emails text DEFAULT '[]'::text NOT NULL,
    phones text DEFAULT '[]'::text NOT NULL,
    addresses text DEFAULT '[]'::text NOT NULL,
    urls text DEFAULT '[]'::text NOT NULL,
    bday text DEFAULT ''::text NOT NULL,
    anniversary text DEFAULT ''::text NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    groups text DEFAULT '[]'::text NOT NULL,
    photo text DEFAULT ''::text NOT NULL,
    version text DEFAULT '3.0'::text NOT NULL,
    extra text DEFAULT ''::text NOT NULL,
    src_digest text DEFAULT ''::text NOT NULL,
    search text DEFAULT ''::text NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    nl_status text DEFAULT ''::text NOT NULL,
    nl_at text,
    nl_source text DEFAULT ''::text NOT NULL
);


--
-- Name: contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.contacts ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.contacts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ctr_notices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ctr_notices (
    task_id bigint NOT NULL,
    due text NOT NULL,
    agent_id bigint NOT NULL,
    user_id bigint,
    list_id bigint,
    sent_at text NOT NULL
);


--
-- Name: dav_meta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dav_meta (
    task_id bigint NOT NULL,
    uid text,
    href text,
    parent_uid text,
    extra text DEFAULT ''::text NOT NULL
);


--
-- Name: dav_sync; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dav_sync (
    user_id bigint NOT NULL,
    list_id bigint NOT NULL,
    token text NOT NULL,
    state bytea NOT NULL,
    created_at text NOT NULL
);


--
-- Name: dav_sync2; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dav_sync2 (
    user_id bigint NOT NULL,
    coll text NOT NULL,
    token text NOT NULL,
    state bytea NOT NULL,
    created_at text NOT NULL
);


--
-- Name: disc_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.disc_profiles (
    user_id bigint NOT NULL,
    email text DEFAULT ''::text NOT NULL,
    confirmed_at text,
    created_at text NOT NULL
);


--
-- Name: disc_quota; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.disc_quota (
    user_id bigint NOT NULL,
    day text NOT NULL,
    searches bigint DEFAULT 0 NOT NULL,
    checked bigint DEFAULT 0 NOT NULL
);


--
-- Name: disc_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.disc_tokens (
    token_hash text NOT NULL,
    user_id bigint NOT NULL,
    email text NOT NULL,
    expires_at text NOT NULL
);


--
-- Name: dl_changes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dl_changes (
    id bigint NOT NULL,
    ver bigint,
    task_id bigint,
    list_id bigint,
    user_id bigint
);


--
-- Name: dl_changes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dl_changes ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dl_changes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: doc_cfg; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doc_cfg (
    ws text NOT NULL,
    org_id bigint,
    data text DEFAULT '{}'::text NOT NULL,
    updated_at text NOT NULL
);

ALTER TABLE ONLY public.doc_cfg FORCE ROW LEVEL SECURITY;


--
-- Name: doc_mail; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doc_mail (
    token text NOT NULL,
    user_id bigint NOT NULL,
    org_id bigint,
    created_at text NOT NULL
);

ALTER TABLE ONLY public.doc_mail FORCE ROW LEVEL SECURITY;


--
-- Name: doc_meta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doc_meta (
    node_id bigint NOT NULL,
    org_id bigint,
    ws text NOT NULL,
    state text DEFAULT 'wait'::text NOT NULL,
    error text DEFAULT ''::text NOT NULL,
    method text DEFAULT ''::text NOT NULL,
    pages bigint DEFAULT 0 NOT NULL,
    tries bigint DEFAULT 0 NOT NULL,
    text text DEFAULT ''::text NOT NULL,
    doc_date text,
    due_date text,
    amount text DEFAULT ''::text NOT NULL,
    currency text DEFAULT ''::text NOT NULL,
    sender_id bigint,
    type_id bigint,
    auto text DEFAULT '{}'::text NOT NULL,
    suggest text DEFAULT ''::text NOT NULL,
    trained text DEFAULT ''::text NOT NULL,
    review bigint DEFAULT 0 NOT NULL,
    source text DEFAULT 'upload'::text NOT NULL,
    ext_id text,
    thumb text,
    version bigint DEFAULT 0 NOT NULL,
    task_id bigint,
    created_by bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    done_at text,
    asn bigint,
    taken_at text
);

ALTER TABLE ONLY public.doc_meta FORCE ROW LEVEL SECURITY;


--
-- Name: doc_models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doc_models (
    id bigint NOT NULL,
    org_id bigint,
    ws text NOT NULL,
    feature text NOT NULL,
    data text NOT NULL,
    updated_at text NOT NULL
);

ALTER TABLE ONLY public.doc_models FORCE ROW LEVEL SECURITY;


--
-- Name: doc_models_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.doc_models ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.doc_models_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: doc_node_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doc_node_tags (
    node_id bigint NOT NULL,
    tag_id bigint NOT NULL,
    auto text DEFAULT ''::text NOT NULL
);


--
-- Name: doc_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doc_rules (
    id bigint NOT NULL,
    org_id bigint,
    ws text NOT NULL,
    pos bigint DEFAULT 0 NOT NULL,
    data text NOT NULL,
    created_by bigint,
    created_at text NOT NULL
);

ALTER TABLE ONLY public.doc_rules FORCE ROW LEVEL SECURITY;


--
-- Name: doc_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.doc_rules ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.doc_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: doc_senders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doc_senders (
    id bigint NOT NULL,
    org_id bigint,
    ws text NOT NULL,
    name text NOT NULL,
    created_at text NOT NULL
);

ALTER TABLE ONLY public.doc_senders FORCE ROW LEVEL SECURITY;


--
-- Name: doc_senders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.doc_senders ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.doc_senders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: doc_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doc_tags (
    id bigint NOT NULL,
    org_id bigint,
    ws text NOT NULL,
    name text NOT NULL,
    created_at text NOT NULL
);

ALTER TABLE ONLY public.doc_tags FORCE ROW LEVEL SECURITY;


--
-- Name: doc_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.doc_tags ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.doc_tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: doc_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doc_types (
    id bigint NOT NULL,
    org_id bigint,
    ws text NOT NULL,
    name text NOT NULL,
    created_at text NOT NULL
);

ALTER TABLE ONLY public.doc_types FORCE ROW LEVEL SECURITY;


--
-- Name: doc_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.doc_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.doc_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: doc_words; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.doc_words (
    node_id bigint NOT NULL,
    h text NOT NULL
);


--
-- Name: e2e_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.e2e_keys (
    user_id bigint NOT NULL,
    pub text NOT NULL,
    bundle_pass text NOT NULL,
    bundle_rec text NOT NULL,
    created_at text NOT NULL,
    updated_at text NOT NULL
);


--
-- Name: env_deploys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.env_deploys (
    id bigint NOT NULL,
    env_id bigint NOT NULL,
    list_id bigint NOT NULL,
    milestone_id bigint,
    version text DEFAULT ''::text NOT NULL,
    at text NOT NULL,
    by_id bigint,
    source text DEFAULT 'manual'::text NOT NULL
);


--
-- Name: env_deploys_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.env_deploys ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.env_deploys_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ev_cal_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ev_cal_members (
    cal_id bigint NOT NULL,
    user_id bigint NOT NULL,
    role text DEFAULT 'view'::text NOT NULL,
    hidden bigint DEFAULT 0 NOT NULL,
    added_at text NOT NULL
);


--
-- Name: ev_cals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ev_cals (
    id bigint NOT NULL,
    owner_id bigint NOT NULL,
    name text NOT NULL,
    color text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    sort bigint DEFAULT 0 NOT NULL,
    created_at text NOT NULL,
    changed_at text NOT NULL,
    org_id bigint
);

ALTER TABLE ONLY public.ev_cals FORCE ROW LEVEL SECURITY;


--
-- Name: ev_cals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ev_cals ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ev_cals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ev_reminded; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ev_reminded (
    event_id bigint NOT NULL,
    user_id bigint NOT NULL,
    k text NOT NULL,
    at text NOT NULL
);


--
-- Name: event_attendees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_attendees (
    id bigint NOT NULL,
    event_id bigint NOT NULL,
    user_id bigint,
    contact_id bigint,
    email text DEFAULT ''::text NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    partstat text DEFAULT 'needs-action'::text NOT NULL,
    role text DEFAULT 'req'::text NOT NULL
);


--
-- Name: event_attendees_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.event_attendees ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.event_attendees_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.events (
    id bigint NOT NULL,
    cal_id bigint NOT NULL,
    uid text NOT NULL,
    href text NOT NULL,
    title text NOT NULL,
    location text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    all_day bigint DEFAULT 0 NOT NULL,
    start text NOT NULL,
    "end" text NOT NULL,
    tz text DEFAULT ''::text NOT NULL,
    rrule text DEFAULT ''::text NOT NULL,
    exdates text DEFAULT ''::text NOT NULL,
    overrides text DEFAULT ''::text NOT NULL,
    reminders text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'confirmed'::text NOT NULL,
    busy bigint DEFAULT 1 NOT NULL,
    url text,
    task_id bigint,
    extra text DEFAULT ''::text NOT NULL,
    seq bigint DEFAULT 0 NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    deleted_at text,
    first_day text DEFAULT ''::text NOT NULL,
    last_day text DEFAULT ''::text NOT NULL
);


--
-- Name: events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.events ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: file_text; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_text (
    id bigint NOT NULL,
    kind text NOT NULL,
    ref_id bigint NOT NULL,
    att_id bigint,
    list_file_id bigint,
    node_id bigint,
    org_id bigint,
    ws text NOT NULL,
    state text DEFAULT 'wait'::text NOT NULL,
    error text DEFAULT ''::text NOT NULL,
    method text DEFAULT ''::text NOT NULL,
    text text DEFAULT ''::text NOT NULL,
    pages bigint DEFAULT 0 NOT NULL,
    truncated bigint DEFAULT 0 NOT NULL,
    tries bigint DEFAULT 0 NOT NULL,
    sha256 text DEFAULT ''::text NOT NULL,
    created_at text NOT NULL,
    updated_at text NOT NULL
);

ALTER TABLE ONLY public.file_text FORCE ROW LEVEL SECURITY;


--
-- Name: file_text_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.file_text ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.file_text_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: file_words; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_words (
    ft_id bigint NOT NULL,
    h text NOT NULL
);


--
-- Name: filters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.filters (
    id bigint NOT NULL,
    name text NOT NULL,
    rules text DEFAULT '{}'::text NOT NULL,
    sort double precision DEFAULT 0 NOT NULL,
    created_at text NOT NULL,
    user_id bigint
);


--
-- Name: filters_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.filters ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.filters_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: folder_agents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.folder_agents (
    owner_id bigint NOT NULL,
    folder text NOT NULL,
    agent_id bigint NOT NULL,
    pos bigint DEFAULT 0 NOT NULL,
    listen bigint,
    created_at text NOT NULL
);


--
-- Name: folder_heads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.folder_heads (
    owner_id bigint NOT NULL,
    folder text NOT NULL,
    style text DEFAULT ''::text NOT NULL,
    updated_at text NOT NULL
);


--
-- Name: folder_notif; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.folder_notif (
    owner_id bigint NOT NULL,
    folder text NOT NULL,
    user_id bigint DEFAULT 0 NOT NULL,
    tpl text NOT NULL,
    custom text,
    updated_at text NOT NULL
);


--
-- Name: folder_people; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.folder_people (
    owner_id bigint NOT NULL,
    folder text NOT NULL,
    user_id bigint NOT NULL,
    role text DEFAULT 'edit'::text NOT NULL,
    created_at text NOT NULL
);


--
-- Name: folder_props; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.folder_props (
    owner_id bigint NOT NULL,
    folder text NOT NULL,
    props text DEFAULT '{}'::text NOT NULL,
    updated_at text NOT NULL
);


--
-- Name: forms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.forms (
    id bigint NOT NULL,
    list_id bigint NOT NULL,
    token text NOT NULL,
    token_hash text NOT NULL,
    title text NOT NULL,
    intro text DEFAULT ''::text NOT NULL,
    access text DEFAULT 'org'::text NOT NULL,
    section_id bigint,
    ask_email bigint DEFAULT 1 NOT NULL,
    enabled bigint DEFAULT 1 NOT NULL,
    count bigint DEFAULT 0 NOT NULL,
    last_at text,
    created_by bigint,
    created_at text NOT NULL,
    ttype text DEFAULT ''::text NOT NULL,
    files bigint DEFAULT 0 NOT NULL,
    portal bigint DEFAULT 0 NOT NULL
);


--
-- Name: forms_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.forms ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.forms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: fs_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fs_log (
    id bigint NOT NULL,
    node_id bigint NOT NULL,
    user_id bigint,
    agent bigint DEFAULT 0 NOT NULL,
    action text NOT NULL,
    detail text DEFAULT ''::text NOT NULL,
    at text NOT NULL
);


--
-- Name: fs_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.fs_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.fs_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: fs_nodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fs_nodes (
    id bigint NOT NULL,
    parent_id bigint,
    kind text DEFAULT 'file'::text NOT NULL,
    name text NOT NULL,
    owner_id bigint NOT NULL,
    org_id bigint,
    agent_id bigint,
    mime text DEFAULT ''::text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    cur_version bigint DEFAULT 0 NOT NULL,
    ref_kind text,
    ref_id bigint,
    org_access text DEFAULT ''::text NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    deleted_at text,
    deleted_by bigint
);

ALTER TABLE ONLY public.fs_nodes FORCE ROW LEVEL SECURITY;


--
-- Name: fs_nodes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.fs_nodes ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.fs_nodes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: fs_shares; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fs_shares (
    id bigint NOT NULL,
    node_id bigint NOT NULL,
    user_id bigint,
    group_id bigint,
    agent_id bigint,
    role text DEFAULT 'view'::text NOT NULL,
    expires_at text,
    created_by bigint,
    created_at text NOT NULL
);


--
-- Name: fs_shares_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.fs_shares ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.fs_shares_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: fs_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fs_versions (
    id bigint NOT NULL,
    node_id bigint NOT NULL,
    no bigint NOT NULL,
    path text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    mime text DEFAULT ''::text NOT NULL,
    sha256 text DEFAULT ''::text NOT NULL,
    created_by bigint,
    created_at text NOT NULL
);


--
-- Name: fs_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.fs_versions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.fs_versions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: git_closes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.git_closes (
    task_id bigint NOT NULL,
    conn_id bigint NOT NULL,
    kind text NOT NULL,
    ref text NOT NULL,
    undo text DEFAULT '{}'::text NOT NULL,
    created_at text NOT NULL,
    undone_at text
);


--
-- Name: git_commits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.git_commits (
    conn_id bigint NOT NULL,
    sha text NOT NULL,
    message text DEFAULT ''::text NOT NULL,
    author text DEFAULT ''::text NOT NULL,
    url text DEFAULT ''::text NOT NULL,
    branch text DEFAULT ''::text NOT NULL,
    at text
);


--
-- Name: git_conns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.git_conns (
    id bigint NOT NULL,
    list_id bigint NOT NULL,
    provider text NOT NULL,
    base_url text DEFAULT ''::text NOT NULL,
    owner text NOT NULL,
    repo text NOT NULL,
    token text DEFAULT ''::text NOT NULL,
    hook_secret text DEFAULT ''::text NOT NULL,
    default_branch text DEFAULT ''::text NOT NULL,
    etags text DEFAULT '{}'::text NOT NULL,
    polled_at text,
    next_at double precision DEFAULT 0 NOT NULL,
    fails bigint DEFAULT 0 NOT NULL,
    last_error text DEFAULT ''::text NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    tags_at text
);


--
-- Name: git_conns_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.git_conns ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.git_conns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: git_folders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.git_folders (
    conn_id bigint NOT NULL,
    owner_id bigint NOT NULL,
    folder text NOT NULL,
    created_at text NOT NULL
);


--
-- Name: git_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.git_links (
    task_id bigint NOT NULL,
    conn_id bigint NOT NULL,
    kind text NOT NULL,
    ref text NOT NULL,
    created_at text NOT NULL
);


--
-- Name: git_prs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.git_prs (
    conn_id bigint NOT NULL,
    number bigint NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    state text DEFAULT 'open'::text NOT NULL,
    author text DEFAULT ''::text NOT NULL,
    url text DEFAULT ''::text NOT NULL,
    head_ref text DEFAULT ''::text NOT NULL,
    head_sha text DEFAULT ''::text NOT NULL,
    ci text DEFAULT ''::text NOT NULL,
    ci_sha text DEFAULT ''::text NOT NULL,
    updated_at text,
    merged_at text
);


--
-- Name: git_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.git_tags (
    conn_id bigint NOT NULL,
    name text NOT NULL,
    seen_at text NOT NULL
);


--
-- Name: group_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_members (
    group_id bigint NOT NULL,
    user_id bigint NOT NULL,
    added_at text NOT NULL
);


--
-- Name: group_shares; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_shares (
    id bigint NOT NULL,
    group_id bigint NOT NULL,
    list_id bigint,
    owner_id bigint,
    folder text,
    role text DEFAULT 'edit'::text NOT NULL,
    added_by bigint,
    added_at text NOT NULL
);


--
-- Name: group_shares_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.group_shares ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.group_shares_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.groups (
    id bigint NOT NULL,
    name text NOT NULL,
    oidc_group text DEFAULT ''::text NOT NULL,
    created_at text NOT NULL,
    created_by bigint,
    avatar text DEFAULT ''::text NOT NULL
);


--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: habit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.habit_logs (
    habit_id bigint NOT NULL,
    day text NOT NULL,
    count bigint DEFAULT 0 NOT NULL,
    note text DEFAULT ''::text NOT NULL
);


--
-- Name: habits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.habits (
    id bigint NOT NULL,
    name text NOT NULL,
    color text DEFAULT ''::text NOT NULL,
    goal bigint DEFAULT 1 NOT NULL,
    days text DEFAULT '1234567'::text NOT NULL,
    remind_at text DEFAULT ''::text NOT NULL,
    reminded_on text DEFAULT ''::text NOT NULL,
    sort double precision DEFAULT 0 NOT NULL,
    archived bigint DEFAULT 0 NOT NULL,
    created_at text NOT NULL,
    per_week bigint DEFAULT 0 NOT NULL,
    user_id bigint
);


--
-- Name: habits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.habits ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.habits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: hub_absences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hub_absences (
    id bigint NOT NULL,
    org_id bigint,
    user_id bigint NOT NULL,
    kind text DEFAULT 'vacation'::text NOT NULL,
    start_date text NOT NULL,
    end_date text NOT NULL,
    half_day text DEFAULT ''::text NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    deleted_at text
);

ALTER TABLE ONLY public.hub_absences FORCE ROW LEVEL SECURITY;


--
-- Name: hub_absences_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.hub_absences ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.hub_absences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: hub_bookings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hub_bookings (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    job text DEFAULT ''::text NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    start text NOT NULL,
    "end" text NOT NULL,
    resource_kind text NOT NULL,
    resource_id bigint NOT NULL,
    res_label text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'option'::text NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    list_id bigint,
    event_id bigint,
    created_by bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    deleted_at text
);

ALTER TABLE ONLY public.hub_bookings FORCE ROW LEVEL SECURITY;


--
-- Name: hub_bookings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.hub_bookings ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.hub_bookings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: hub_mails; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hub_mails (
    id bigint NOT NULL,
    org_id bigint,
    owner_id bigint,
    client_id bigint,
    list_id bigint,
    ws text NOT NULL,
    message_id text NOT NULL,
    from_addr text DEFAULT ''::text NOT NULL,
    from_name text DEFAULT ''::text NOT NULL,
    to_addrs text DEFAULT ''::text NOT NULL,
    subject text DEFAULT ''::text NOT NULL,
    sent_at text,
    body text DEFAULT ''::text NOT NULL,
    files text DEFAULT '[]'::text NOT NULL,
    eml_id bigint,
    note text DEFAULT ''::text NOT NULL,
    folder_id bigint,
    created_at text NOT NULL,
    deleted_at text,
    deleted_by bigint
);

ALTER TABLE ONLY public.hub_mails FORCE ROW LEVEL SECURITY;


--
-- Name: hub_mails_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.hub_mails ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.hub_mails_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: hub_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hub_tokens (
    token text NOT NULL,
    kind text NOT NULL,
    user_id bigint NOT NULL,
    org_id bigint,
    client_id bigint,
    list_id bigint,
    created_at text NOT NULL
);

ALTER TABLE ONLY public.hub_tokens FORCE ROW LEVEL SECURITY;


--
-- Name: hub_words; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hub_words (
    mail_id bigint NOT NULL,
    h text NOT NULL
);


--
-- Name: imports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.imports (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    source text NOT NULL,
    file_name text DEFAULT ''::text NOT NULL,
    created text DEFAULT '{}'::text NOT NULL,
    report text DEFAULT '{}'::text NOT NULL,
    created_at text NOT NULL,
    undone_at text
);


--
-- Name: imports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.imports ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.imports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: issue_hooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.issue_hooks (
    list_id bigint NOT NULL,
    token_hash text NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    last_at text,
    received bigint DEFAULT 0 NOT NULL
);


--
-- Name: issue_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.issue_reports (
    list_id bigint NOT NULL,
    fp text NOT NULL,
    task_id bigint,
    count bigint DEFAULT 1 NOT NULL,
    first_at text NOT NULL,
    last_at text NOT NULL
);


--
-- Name: journal; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.journal (
    user_id bigint NOT NULL,
    day text NOT NULL,
    text text DEFAULT ''::text NOT NULL,
    mood bigint,
    updated_at text NOT NULL
);


--
-- Name: kalmido_meta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kalmido_meta (
    key text NOT NULL,
    value text NOT NULL
);


--
-- Name: kid_parents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kid_parents (
    kid_id bigint NOT NULL,
    parent_id bigint NOT NULL
);


--
-- Name: kid_pin_open; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kid_pin_open (
    token_hash text NOT NULL,
    kid_id bigint NOT NULL,
    until text NOT NULL
);


--
-- Name: kid_pins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kid_pins (
    kid_id bigint NOT NULL,
    pin_hash text NOT NULL,
    fails bigint DEFAULT 0 NOT NULL,
    lock_until text DEFAULT ''::text NOT NULL,
    set_by bigint,
    set_at text NOT NULL
);


--
-- Name: kid_rewards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kid_rewards (
    id bigint NOT NULL,
    kid_id bigint NOT NULL,
    title text NOT NULL,
    emoji text DEFAULT ''::text NOT NULL,
    cost bigint NOT NULL,
    once bigint DEFAULT 0 NOT NULL,
    state text DEFAULT 'open'::text NOT NULL,
    requested_at text,
    decided_by bigint,
    decided_at text,
    created_by bigint,
    created_at text NOT NULL
);


--
-- Name: kid_rewards_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.kid_rewards ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.kid_rewards_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: kid_stars; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kid_stars (
    id bigint NOT NULL,
    kid_id bigint NOT NULL,
    delta bigint NOT NULL,
    kind text NOT NULL,
    task_id bigint,
    reward_id bigint,
    title text DEFAULT ''::text NOT NULL,
    by_id bigint,
    at text NOT NULL,
    created_at text NOT NULL
);


--
-- Name: kid_stars_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.kid_stars ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.kid_stars_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: kk_conns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kk_conns (
    user_id bigint NOT NULL,
    url text NOT NULL,
    token text DEFAULT ''::text NOT NULL,
    list_id bigint,
    source text DEFAULT ''::text NOT NULL,
    archive bigint DEFAULT 1 NOT NULL,
    synced_at text,
    error text DEFAULT ''::text NOT NULL,
    created_at text NOT NULL
);


--
-- Name: list_activity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.list_activity (
    id bigint NOT NULL,
    list_id bigint NOT NULL,
    user_id bigint,
    kind text NOT NULL,
    data text DEFAULT '{}'::text NOT NULL,
    created_at text NOT NULL
);


--
-- Name: list_activity_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.list_activity ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.list_activity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: list_bell; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.list_bell (
    user_id bigint NOT NULL,
    list_id bigint NOT NULL,
    mode text NOT NULL,
    custom text
);


--
-- Name: list_envs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.list_envs (
    id bigint NOT NULL,
    list_id bigint NOT NULL,
    name text NOT NULL,
    sort bigint DEFAULT 0 NOT NULL,
    token_hash text DEFAULT ''::text NOT NULL,
    auto_close bigint DEFAULT 0 NOT NULL,
    created_at text NOT NULL,
    deleted_at text
);


--
-- Name: list_envs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.list_envs ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.list_envs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: list_fields; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.list_fields (
    id bigint NOT NULL,
    list_id bigint NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    options text DEFAULT '{}'::text NOT NULL,
    pinned bigint DEFAULT 0 NOT NULL,
    sort double precision DEFAULT 0 NOT NULL,
    created_at text NOT NULL
);


--
-- Name: list_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.list_fields ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.list_fields_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: list_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.list_files (
    id bigint NOT NULL,
    list_id bigint NOT NULL,
    name text NOT NULL,
    mime text DEFAULT ''::text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    path text NOT NULL,
    user_id bigint,
    created_at text NOT NULL
);


--
-- Name: list_files_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.list_files ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.list_files_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: list_key_pending; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.list_key_pending (
    list_id bigint NOT NULL,
    user_id bigint NOT NULL,
    since text NOT NULL
);


--
-- Name: list_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.list_keys (
    list_id bigint NOT NULL,
    gen bigint NOT NULL,
    user_id bigint NOT NULL,
    wrapped text NOT NULL,
    wrapped_by bigint,
    wrapper_pub text NOT NULL,
    created_at text NOT NULL
);


--
-- Name: list_layouts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.list_layouts (
    list_id bigint NOT NULL,
    user_id bigint NOT NULL,
    layout text NOT NULL,
    updated_at text NOT NULL
);


--
-- Name: list_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.list_links (
    id bigint NOT NULL,
    list_id bigint NOT NULL,
    title text NOT NULL,
    url text NOT NULL,
    sort double precision DEFAULT 0 NOT NULL,
    created_by bigint,
    created_at text NOT NULL
);


--
-- Name: list_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.list_links ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.list_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: list_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.list_members (
    list_id bigint NOT NULL,
    user_id bigint NOT NULL,
    role text DEFAULT 'edit'::text NOT NULL,
    folder text DEFAULT ''::text NOT NULL,
    sort double precision DEFAULT 0 NOT NULL,
    view text,
    added_at text NOT NULL,
    id bigint NOT NULL,
    own_role text,
    grole text
);


--
-- Name: list_members_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.list_members ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.list_members_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: list_milestones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.list_milestones (
    id bigint NOT NULL,
    list_id bigint NOT NULL,
    name text NOT NULL,
    day text NOT NULL,
    done bigint DEFAULT 0 NOT NULL,
    created_by bigint,
    created_at text NOT NULL
);


--
-- Name: list_milestones_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.list_milestones ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.list_milestones_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: list_mine_hide; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.list_mine_hide (
    user_id bigint NOT NULL,
    list_id bigint NOT NULL,
    created_at text NOT NULL
);


--
-- Name: list_notepads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.list_notepads (
    id bigint NOT NULL,
    list_id bigint NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    updated_by bigint,
    updated_at text NOT NULL,
    agent_id bigint,
    agent_key text DEFAULT ''::text NOT NULL
);


--
-- Name: list_notepads_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.list_notepads ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.list_notepads_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: list_notif; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.list_notif (
    list_id bigint NOT NULL,
    user_id bigint DEFAULT 0 NOT NULL,
    tpl text NOT NULL,
    custom text,
    updated_at text NOT NULL
);


--
-- Name: list_paperless; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.list_paperless (
    id bigint NOT NULL,
    list_id bigint NOT NULL,
    conn_id bigint,
    doc_id bigint,
    title text DEFAULT ''::text NOT NULL,
    correspondent text DEFAULT ''::text NOT NULL,
    created text DEFAULT ''::text NOT NULL,
    added_by bigint,
    added_at text NOT NULL
);


--
-- Name: list_paperless_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.list_paperless ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.list_paperless_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: list_rule_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.list_rule_runs (
    rule_id bigint NOT NULL,
    task_id bigint NOT NULL,
    key text NOT NULL,
    at text NOT NULL
);


--
-- Name: list_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.list_rules (
    id bigint NOT NULL,
    list_id bigint NOT NULL,
    org_id bigint,
    name text NOT NULL,
    trig text NOT NULL,
    trig_val text DEFAULT ''::text NOT NULL,
    act text NOT NULL,
    act_val text DEFAULT '{}'::text NOT NULL,
    target_list_id bigint,
    active bigint DEFAULT 1 NOT NULL,
    paused_reason text DEFAULT ''::text NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    deleted_at text
);

ALTER TABLE ONLY public.list_rules FORCE ROW LEVEL SECURITY;


--
-- Name: list_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.list_rules ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.list_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: list_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.list_status (
    id bigint NOT NULL,
    list_id bigint NOT NULL,
    user_id bigint,
    status text NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    created_at text NOT NULL
);


--
-- Name: list_status_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.list_status ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.list_status_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: list_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.list_tags (
    id bigint NOT NULL,
    list_id bigint NOT NULL,
    name text NOT NULL,
    color text DEFAULT ''::text NOT NULL,
    sort double precision DEFAULT 0 NOT NULL,
    created_at text NOT NULL
);


--
-- Name: list_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.list_tags ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.list_tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: lists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lists (
    id bigint NOT NULL,
    name text NOT NULL,
    color text DEFAULT ''::text NOT NULL,
    folder text DEFAULT ''::text NOT NULL,
    sort double precision DEFAULT 0 NOT NULL,
    view text DEFAULT 'list'::text NOT NULL,
    is_inbox bigint DEFAULT 0 NOT NULL,
    archived bigint DEFAULT 0 NOT NULL,
    created_at text NOT NULL,
    owner_id bigint,
    rate double precision,
    status text DEFAULT ''::text NOT NULL,
    status_note text DEFAULT ''::text NOT NULL,
    status_by bigint,
    status_at text,
    checklist bigint DEFAULT 0 NOT NULL,
    dep_shift bigint DEFAULT 0 NOT NULL,
    kind text DEFAULT 'list'::text NOT NULL,
    archived_at text,
    agent_tidy text DEFAULT 'off'::text NOT NULL,
    icon text,
    tickets bigint DEFAULT 0 NOT NULL,
    ticket_tpl text DEFAULT ''::text NOT NULL,
    tidy_agent bigint,
    nag text DEFAULT ''::text NOT NULL,
    day_hours double precision,
    description text DEFAULT ''::text NOT NULL,
    agent_listen text,
    col_cfg text,
    ptype text DEFAULT ''::text NOT NULL,
    family text DEFAULT ''::text NOT NULL,
    life text DEFAULT ''::text NOT NULL,
    trip text DEFAULT ''::text NOT NULL,
    client_id bigint,
    agent_members bigint DEFAULT 0 NOT NULL,
    agent_peers bigint DEFAULT 0 NOT NULL,
    sort_mode text DEFAULT ''::text NOT NULL,
    org_id bigint,
    folder_own text DEFAULT '[]'::text NOT NULL,
    page_layout text DEFAULT ''::text NOT NULL,
    page_style text DEFAULT ''::text NOT NULL,
    git_folder_off bigint DEFAULT 0 NOT NULL,
    stale_days bigint,
    agent_followup bigint DEFAULT 0 NOT NULL,
    done_in_section bigint,
    time_tracking bigint DEFAULT 0 NOT NULL,
    tb_sums text,
    fx_kpis text,
    org_visibility text DEFAULT ''::text NOT NULL,
    org_edit bigint DEFAULT 0 NOT NULL,
    tap_done bigint DEFAULT 0 NOT NULL,
    sprint_cfg text DEFAULT ''::text NOT NULL,
    points_on bigint DEFAULT 0 NOT NULL,
    review_cfg text DEFAULT ''::text NOT NULL,
    e2e text,
    e2e_gen bigint DEFAULT 0 NOT NULL,
    e2e_rotate bigint DEFAULT 0 NOT NULL,
    e2e_by bigint,
    e2e_at text,
    e2e_reenc bigint DEFAULT 0 NOT NULL,
    header_style text DEFAULT ''::text NOT NULL,
    header_file text DEFAULT ''::text NOT NULL
);

ALTER TABLE ONLY public.lists FORCE ROW LEVEL SECURITY;


--
-- Name: lists_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.lists ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.lists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: login_ips; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.login_ips (
    ip text NOT NULL,
    user_id bigint NOT NULL,
    at text NOT NULL
);


--
-- Name: mail_counts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mail_counts (
    k text NOT NULL,
    day text NOT NULL,
    n bigint DEFAULT 0 NOT NULL
);


--
-- Name: mail_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mail_tokens (
    token text NOT NULL,
    user_id bigint NOT NULL,
    list_id bigint,
    created_at text NOT NULL
);


--
-- Name: merge_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.merge_runs (
    id bigint NOT NULL,
    kind text NOT NULL,
    target_id bigint NOT NULL,
    org_id bigint,
    book_id bigint,
    user_id bigint,
    merged_ids text DEFAULT '[]'::text NOT NULL,
    snapshot text DEFAULT '{}'::text NOT NULL,
    summary text DEFAULT '{}'::text NOT NULL,
    created_at text NOT NULL,
    undone_at text,
    undone_by bigint
);

ALTER TABLE ONLY public.merge_runs FORCE ROW LEVEL SECURITY;


--
-- Name: merge_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.merge_runs ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.merge_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: msv_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.msv_links (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    name text NOT NULL,
    short text DEFAULT ''::text NOT NULL,
    color text DEFAULT ''::text NOT NULL,
    base_url text NOT NULL,
    token_enc text DEFAULT ''::text NOT NULL,
    remote_me text DEFAULT '{}'::text NOT NULL,
    default_inbox bigint DEFAULT 0 NOT NULL,
    "position" bigint DEFAULT 0 NOT NULL,
    last_ok text,
    last_err text DEFAULT ''::text NOT NULL,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    deleted_at text
);


--
-- Name: msv_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.msv_links ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.msv_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: nl_conns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nl_conns (
    id bigint NOT NULL,
    org_id bigint,
    owner_id bigint,
    ws text NOT NULL,
    kind text NOT NULL,
    url text DEFAULT ''::text NOT NULL,
    secret text DEFAULT ''::text NOT NULL,
    hint text DEFAULT ''::text NOT NULL,
    mode text DEFAULT 'consented'::text NOT NULL,
    auto bigint DEFAULT 0 NOT NULL,
    synced_at text,
    error text DEFAULT ''::text NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL
);

ALTER TABLE ONLY public.nl_conns FORCE ROW LEVEL SECURITY;


--
-- Name: nl_conns_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.nl_conns ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.nl_conns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: nl_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nl_members (
    seg_id bigint NOT NULL,
    org_id bigint,
    email text NOT NULL,
    remote_ref text DEFAULT ''::text NOT NULL,
    state text DEFAULT ''::text NOT NULL,
    synced_at text NOT NULL
);

ALTER TABLE ONLY public.nl_members FORCE ROW LEVEL SECURITY;


--
-- Name: nl_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nl_runs (
    id bigint NOT NULL,
    conn_id bigint NOT NULL,
    org_id bigint,
    kind text DEFAULT 'manual'::text NOT NULL,
    by_id bigint,
    state text DEFAULT 'busy'::text NOT NULL,
    started_at text NOT NULL,
    ended_at text,
    counts text DEFAULT '{}'::text NOT NULL,
    errors text DEFAULT '[]'::text NOT NULL
);

ALTER TABLE ONLY public.nl_runs FORCE ROW LEVEL SECURITY;


--
-- Name: nl_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.nl_runs ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.nl_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: nl_segments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nl_segments (
    id bigint NOT NULL,
    conn_id bigint NOT NULL,
    org_id bigint,
    name text NOT NULL,
    rule text DEFAULT '{}'::text NOT NULL,
    remote_id text DEFAULT ''::text NOT NULL,
    remote_name text DEFAULT ''::text NOT NULL,
    created_at text NOT NULL,
    updated_at text NOT NULL
);

ALTER TABLE ONLY public.nl_segments FORCE ROW LEVEL SECURITY;


--
-- Name: nl_segments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.nl_segments ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.nl_segments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notes (
    id bigint NOT NULL,
    list_id bigint NOT NULL,
    title text NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    tags text DEFAULT ''::text NOT NULL,
    pinned bigint DEFAULT 0 NOT NULL,
    created_by bigint,
    updated_by bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL
);


--
-- Name: notes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.notes ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.notes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    kind text NOT NULL,
    task_id bigint,
    list_id bigint,
    actor_id bigint,
    comment_id bigint,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at text NOT NULL,
    read_at text
);


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.notifications ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_agreements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_agreements (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    kind text DEFAULT 'insurance'::text NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    provider text DEFAULT ''::text NOT NULL,
    number text DEFAULT ''::text NOT NULL,
    cost text DEFAULT ''::text NOT NULL,
    per text DEFAULT 'month'::text NOT NULL,
    vat_pct text,
    start text DEFAULT ''::text NOT NULL,
    ends text DEFAULT ''::text NOT NULL,
    notice bigint DEFAULT 0 NOT NULL,
    notice_unit text DEFAULT 'm'::text NOT NULL,
    renew_months bigint DEFAULT 12 NOT NULL,
    lead_days bigint DEFAULT 30 NOT NULL,
    doc_node_id bigint,
    task_id bigint,
    cashflow bigint DEFAULT 1 NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    archived bigint DEFAULT 0 NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL
);

ALTER TABLE ONLY public.office_agreements FORCE ROW LEVEL SECURITY;


--
-- Name: office_agreements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_agreements ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_agreements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_archive; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_archive (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    run_id bigint,
    kind text DEFAULT 'invoice'::text NOT NULL,
    number text DEFAULT ''::text NOT NULL,
    project_no text DEFAULT ''::text NOT NULL,
    project text DEFAULT ''::text NOT NULL,
    client_id bigint,
    client_name text DEFAULT ''::text NOT NULL,
    date text DEFAULT ''::text NOT NULL,
    amount numeric(14,4),
    currency text DEFAULT 'EUR'::text NOT NULL,
    paid bigint DEFAULT 0 NOT NULL,
    file_name text DEFAULT ''::text NOT NULL,
    file text DEFAULT ''::text NOT NULL,
    sha256 text DEFAULT ''::text NOT NULL,
    bytes bigint DEFAULT 0 NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    tax_lines text,
    copy_of text
);

ALTER TABLE ONLY public.office_archive FORCE ROW LEVEL SECURITY;


--
-- Name: office_archive_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_archive ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_archive_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_archive_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_archive_log (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    archive_id bigint NOT NULL,
    at text NOT NULL,
    user_id bigint,
    field text NOT NULL,
    old text DEFAULT ''::text NOT NULL,
    new text DEFAULT ''::text NOT NULL,
    role text DEFAULT ''::text NOT NULL
);

ALTER TABLE ONLY public.office_archive_log FORCE ROW LEVEL SECURITY;


--
-- Name: office_archive_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_archive_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_archive_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_bank_imports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_bank_imports (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    filename text DEFAULT ''::text NOT NULL,
    fmt text DEFAULT 'csv'::text NOT NULL,
    count bigint DEFAULT 0 NOT NULL,
    dup_count bigint DEFAULT 0 NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    undone_at text
);

ALTER TABLE ONLY public.office_bank_imports FORCE ROW LEVEL SECURITY;


--
-- Name: office_bank_imports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_bank_imports ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_bank_imports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_bank_tx; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_bank_tx (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    import_id bigint,
    day text DEFAULT ''::text NOT NULL,
    amount text DEFAULT '0'::text NOT NULL,
    currency text DEFAULT 'EUR'::text NOT NULL,
    counterpart text DEFAULT ''::text NOT NULL,
    purpose text DEFAULT ''::text NOT NULL,
    iban text,
    ref text,
    hash text DEFAULT ''::text NOT NULL,
    match_kind text,
    match_id bigint,
    payment_id bigint,
    matched_by bigint,
    matched_at text,
    created_at text NOT NULL,
    deleted_at text
);

ALTER TABLE ONLY public.office_bank_tx FORCE ROW LEVEL SECURITY;


--
-- Name: office_bank_tx_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_bank_tx ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_bank_tx_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_client_contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_client_contacts (
    id bigint NOT NULL,
    org_id bigint,
    client_id bigint NOT NULL,
    name text NOT NULL,
    role text DEFAULT ''::text NOT NULL,
    email text DEFAULT ''::text NOT NULL,
    phone text DEFAULT ''::text NOT NULL,
    is_default bigint DEFAULT 0 NOT NULL,
    sort bigint DEFAULT 0 NOT NULL,
    import_run_id bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    contact_id bigint
);

ALTER TABLE ONLY public.office_client_contacts FORCE ROW LEVEL SECURITY;


--
-- Name: office_client_contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_client_contacts ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_client_contacts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_company; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_company (
    org_id bigint NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    street text DEFAULT ''::text NOT NULL,
    zip text DEFAULT ''::text NOT NULL,
    city text DEFAULT ''::text NOT NULL,
    country text DEFAULT ''::text NOT NULL,
    email text DEFAULT ''::text NOT NULL,
    phone text DEFAULT ''::text NOT NULL,
    tax_number text DEFAULT ''::text NOT NULL,
    vat_id text DEFAULT ''::text NOT NULL,
    iban text DEFAULT ''::text NOT NULL,
    bic text DEFAULT ''::text NOT NULL,
    bank_name text DEFAULT ''::text NOT NULL,
    register_court text DEFAULT ''::text NOT NULL,
    register_no text DEFAULT ''::text NOT NULL,
    managing_directors text DEFAULT ''::text NOT NULL,
    updated_at text DEFAULT ''::text NOT NULL,
    md_label text DEFAULT ''::text NOT NULL
);

ALTER TABLE ONLY public.office_company FORCE ROW LEVEL SECURITY;


--
-- Name: office_contracts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_contracts (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    name text NOT NULL,
    client_id bigint,
    date text DEFAULT ''::text NOT NULL,
    raw_included bigint DEFAULT 0 NOT NULL,
    rights_time_id bigint,
    rights_territory_id bigint,
    rights_media_id bigint,
    rights_note_de text DEFAULT ''::text NOT NULL,
    rights_note_en text DEFAULT ''::text NOT NULL,
    closing_de text DEFAULT ''::text NOT NULL,
    closing_en text DEFAULT ''::text NOT NULL,
    rates text DEFAULT '{}'::text NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    archived bigint DEFAULT 0 NOT NULL,
    created_at text NOT NULL,
    updated_at text NOT NULL
);

ALTER TABLE ONLY public.office_contracts FORCE ROW LEVEL SECURITY;


--
-- Name: office_contracts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_contracts ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_contracts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_deals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_deals (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    client_id bigint,
    contact text DEFAULT ''::text NOT NULL,
    value text DEFAULT '0'::text NOT NULL,
    stage text DEFAULT 'inquiry'::text NOT NULL,
    probability bigint DEFAULT 20 NOT NULL,
    expected_date text DEFAULT ''::text NOT NULL,
    offer_id bigint,
    list_id bigint,
    lost_reason text DEFAULT ''::text NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    sort double precision DEFAULT 0 NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    deleted_at text,
    source text DEFAULT ''::text NOT NULL,
    next_step text DEFAULT ''::text NOT NULL,
    follow_up text DEFAULT ''::text NOT NULL,
    email text DEFAULT ''::text NOT NULL,
    phone text DEFAULT ''::text NOT NULL,
    company text DEFAULT ''::text NOT NULL,
    lead_client_id bigint
);

ALTER TABLE ONLY public.office_deals FORCE ROW LEVEL SECURITY;


--
-- Name: office_deals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_deals ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_deals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_doc_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_doc_items (
    id bigint NOT NULL,
    doc_id bigint NOT NULL,
    sort double precision DEFAULT 0 NOT NULL,
    kind text DEFAULT 'service'::text NOT NULL,
    service_id bigint,
    title text DEFAULT ''::text NOT NULL,
    detail text DEFAULT ''::text NOT NULL,
    qty numeric(14,4) DEFAULT 1 NOT NULL,
    unit text DEFAULT 'day'::text NOT NULL,
    rate numeric(14,4) DEFAULT 0 NOT NULL,
    tax text DEFAULT 'standard'::text NOT NULL,
    raw_fee bigint DEFAULT 0 NOT NULL,
    producing bigint DEFAULT 0 NOT NULL,
    intext text DEFAULT 'intern'::text NOT NULL,
    cost numeric(14,4) DEFAULT 0 NOT NULL,
    discountable bigint DEFAULT 1 NOT NULL,
    org_id bigint NOT NULL,
    tax_pct text,
    net text,
    tax_amount text,
    cost_enc text,
    part_id bigint,
    ref_part_id bigint,
    agent_flag text DEFAULT ''::text NOT NULL
);

ALTER TABLE ONLY public.office_doc_items FORCE ROW LEVEL SECURITY;


--
-- Name: office_doc_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_doc_items ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_doc_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_doc_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_doc_log (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    doc_id bigint,
    user_id bigint,
    at text NOT NULL,
    action text NOT NULL,
    target text DEFAULT 'doc'::text NOT NULL,
    detail text DEFAULT '{}'::text NOT NULL
);

ALTER TABLE ONLY public.office_doc_log FORCE ROW LEVEL SECURITY;


--
-- Name: office_doc_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_doc_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_doc_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_doc_parts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_doc_parts (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    doc_id bigint NOT NULL,
    sort double precision DEFAULT 0 NOT NULL,
    kind text DEFAULT 'items'::text NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    print bigint DEFAULT 1 NOT NULL,
    settings text DEFAULT '{}'::text NOT NULL,
    sheet text DEFAULT '{}'::text NOT NULL,
    totals text DEFAULT '{}'::text NOT NULL,
    created_at text NOT NULL,
    updated_at text NOT NULL
);

ALTER TABLE ONLY public.office_doc_parts FORCE ROW LEVEL SECURITY;


--
-- Name: office_doc_parts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_doc_parts ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_doc_parts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_doc_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_doc_templates (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    kind text DEFAULT 'other'::text NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    lang text DEFAULT ''::text NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    sign bigint DEFAULT 1 NOT NULL,
    archived bigint DEFAULT 0 NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL
);

ALTER TABLE ONLY public.office_doc_templates FORCE ROW LEVEL SECURITY;


--
-- Name: office_doc_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_doc_templates ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_doc_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_docs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_docs (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    kind text DEFAULT 'offer'::text NOT NULL,
    number text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    lang text DEFAULT 'de'::text NOT NULL,
    currency text DEFAULT 'EUR'::text NOT NULL,
    fx_rate numeric(14,4),
    vat_mode text DEFAULT 'vat'::text NOT NULL,
    client_id bigint,
    recipient text DEFAULT '{}'::text NOT NULL,
    project_title text DEFAULT ''::text NOT NULL,
    project_ref text DEFAULT ''::text NOT NULL,
    date text DEFAULT ''::text NOT NULL,
    valid_until text DEFAULT ''::text NOT NULL,
    contract_id bigint,
    raw_mode text DEFAULT 'optional'::text NOT NULL,
    raw_factor numeric(14,4),
    prod_quotient numeric(14,4),
    producing_rate numeric(14,4),
    discount_pct numeric(14,4),
    intro text DEFAULT ''::text NOT NULL,
    closing text DEFAULT ''::text NOT NULL,
    rights text DEFAULT '{}'::text NOT NULL,
    fields text DEFAULT '[]'::text NOT NULL,
    totals text DEFAULT '{}'::text NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    sent_at text,
    locked_at text,
    locked_by bigint,
    sender text,
    recipient_snapshot text,
    tax_snapshot text,
    pack_version text,
    service_from text,
    service_to text,
    order_ref text,
    due_date text,
    payment_days bigint,
    cancels_id bigint,
    ref_doc_ids text,
    reminder_level bigint,
    reminder_fee numeric(14,4),
    reminder_deadline_days bigint,
    paid_at text,
    source_doc_id bigint,
    einvoice_format text,
    pdf_sha256 text,
    xml_sha256 text,
    datev_sent_at text,
    vat_note text,
    contact_id bigint,
    reminder_fee_state text DEFAULT ''::text NOT NULL,
    producing_on bigint,
    agent_id bigint,
    list_id bigint,
    version_of bigint,
    cashflow text DEFAULT 'auto'::text NOT NULL,
    series_id bigint,
    series_period text DEFAULT ''::text NOT NULL
);

ALTER TABLE ONLY public.office_docs FORCE ROW LEVEL SECURITY;


--
-- Name: office_docs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_docs ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_docs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_drive_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_drive_log (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    drive_id bigint NOT NULL,
    action text DEFAULT ''::text NOT NULL,
    prev text DEFAULT ''::text NOT NULL,
    by_user bigint,
    at text NOT NULL
);

ALTER TABLE ONLY public.office_drive_log FORCE ROW LEVEL SECURITY;


--
-- Name: office_drive_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_drive_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_drive_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_drives; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_drives (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    vehicle_id bigint,
    user_id bigint,
    day text DEFAULT ''::text NOT NULL,
    start_place text DEFAULT ''::text NOT NULL,
    dest text DEFAULT ''::text NOT NULL,
    purpose text DEFAULT ''::text NOT NULL,
    km numeric(14,1) DEFAULT 0 NOT NULL,
    odo_start numeric(14,1),
    odo_end numeric(14,1),
    kind text DEFAULT 'business'::text NOT NULL,
    client_id bigint,
    project text DEFAULT ''::text NOT NULL,
    trip_id bigint,
    created_by bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    deleted_at text
);

ALTER TABLE ONLY public.office_drives FORCE ROW LEVEL SECURITY;


--
-- Name: office_drives_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_drives ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_drives_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_equipment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_equipment (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    name text NOT NULL,
    category text DEFAULT ''::text NOT NULL,
    daily_rate numeric(14,4),
    name_en text DEFAULT ''::text NOT NULL,
    archived bigint DEFAULT 0 NOT NULL,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    import_run_id bigint,
    purchase_date text DEFAULT ''::text NOT NULL,
    purchase_net text DEFAULT ''::text NOT NULL,
    new_value text DEFAULT ''::text NOT NULL,
    current_value text DEFAULT ''::text NOT NULL,
    serial_no text DEFAULT ''::text NOT NULL,
    vendor text DEFAULT ''::text NOT NULL,
    receipt_node_id bigint,
    life_months bigint,
    agreement_id bigint
);

ALTER TABLE ONLY public.office_equipment FORCE ROW LEVEL SECURITY;


--
-- Name: office_equipment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_equipment ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_equipment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_fixed_costs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_fixed_costs (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    label text DEFAULT ''::text NOT NULL,
    amount text DEFAULT '0'::text NOT NULL,
    start text DEFAULT ''::text NOT NULL,
    until text DEFAULT ''::text NOT NULL,
    repeat text DEFAULT 'monthly'::text NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    category text DEFAULT ''::text NOT NULL,
    vat_rate bigint DEFAULT 0 NOT NULL,
    sub bigint DEFAULT 0 NOT NULL,
    notice_days bigint DEFAULT 0 NOT NULL,
    seats text DEFAULT '[]'::text NOT NULL,
    low_use bigint DEFAULT 0 NOT NULL,
    remind_days bigint DEFAULT 0 NOT NULL,
    remind_user bigint,
    url text DEFAULT ''::text NOT NULL
);

ALTER TABLE ONLY public.office_fixed_costs FORCE ROW LEVEL SECURITY;


--
-- Name: office_fixed_costs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_fixed_costs ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_fixed_costs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_gen_docs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_gen_docs (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    template_id bigint,
    kind text DEFAULT 'other'::text NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    body_hash text DEFAULT ''::text NOT NULL,
    client_id bigint,
    list_id bigint,
    doc_id bigint,
    node_id bigint,
    signed_node_id bigint,
    status text DEFAULT 'draft'::text NOT NULL,
    archived bigint DEFAULT 0 NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    sign bigint DEFAULT 0 NOT NULL,
    lang text DEFAULT ''::text NOT NULL,
    final_at text
);

ALTER TABLE ONLY public.office_gen_docs FORCE ROW LEVEL SECURITY;


--
-- Name: office_gen_docs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_gen_docs ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_gen_docs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_import_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_import_runs (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    kind text DEFAULT 'data'::text NOT NULL,
    counts text DEFAULT '{}'::text NOT NULL,
    detail text DEFAULT '{}'::text NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    undone_at text,
    undone_by bigint
);

ALTER TABLE ONLY public.office_import_runs FORCE ROW LEVEL SECURITY;


--
-- Name: office_import_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_import_runs ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_import_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_inv_series; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_inv_series (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    template_id bigint,
    title text DEFAULT ''::text NOT NULL,
    every text DEFAULT 'monthly'::text NOT NULL,
    start text DEFAULT ''::text NOT NULL,
    until text DEFAULT ''::text NOT NULL,
    next_date text DEFAULT ''::text NOT NULL,
    auto_send bigint DEFAULT 0 NOT NULL,
    active bigint DEFAULT 1 NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    deleted_at text
);

ALTER TABLE ONLY public.office_inv_series FORCE ROW LEVEL SECURITY;


--
-- Name: office_inv_series_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_inv_series ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_inv_series_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_numbers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_numbers (
    org_id bigint NOT NULL,
    kind text NOT NULL,
    period text DEFAULT ''::text NOT NULL,
    last bigint DEFAULT 0 NOT NULL
);

ALTER TABLE ONLY public.office_numbers FORCE ROW LEVEL SECURITY;


--
-- Name: office_pack_installs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_pack_installs (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    kind text NOT NULL,
    code text NOT NULL,
    version bigint NOT NULL,
    sha256 text NOT NULL,
    data text NOT NULL,
    meta text DEFAULT '{}'::text NOT NULL,
    badge text NOT NULL,
    source text DEFAULT ''::text NOT NULL,
    installed_at text NOT NULL,
    installed_by bigint,
    removed_at text
);

ALTER TABLE ONLY public.office_pack_installs FORCE ROW LEVEL SECURITY;


--
-- Name: office_pack_installs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_pack_installs ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_pack_installs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_pay_props; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_pay_props (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    doc_id bigint NOT NULL,
    agent_id bigint,
    requested_by bigint,
    date text DEFAULT ''::text NOT NULL,
    amount numeric(14,4) DEFAULT 0 NOT NULL,
    reference text DEFAULT ''::text NOT NULL,
    confidence text DEFAULT ''::text NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    state text DEFAULT 'open'::text NOT NULL,
    payment_id bigint,
    decided_by bigint,
    decided_at text,
    created_at text NOT NULL
);

ALTER TABLE ONLY public.office_pay_props FORCE ROW LEVEL SECURITY;


--
-- Name: office_pay_props_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_pay_props ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_pay_props_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_payments (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    doc_id bigint NOT NULL,
    date text DEFAULT ''::text NOT NULL,
    amount numeric(14,4) DEFAULT 0 NOT NULL,
    method text DEFAULT 'transfer'::text NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    created_by bigint,
    created_at text NOT NULL
);

ALTER TABLE ONLY public.office_payments FORCE ROW LEVEL SECURITY;


--
-- Name: office_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_payments ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_payments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_purchases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_purchases (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    doc_id bigint NOT NULL,
    date text DEFAULT ''::text NOT NULL,
    accepted_at text DEFAULT ''::text NOT NULL,
    amount text DEFAULT '0'::text NOT NULL,
    currency text DEFAULT 'EUR'::text NOT NULL,
    label text DEFAULT ''::text NOT NULL,
    source text DEFAULT 'item'::text NOT NULL,
    ref bigint,
    created_at text NOT NULL
);

ALTER TABLE ONLY public.office_purchases FORCE ROW LEVEL SECURITY;


--
-- Name: office_purchases_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_purchases ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_purchases_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_roles (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    kind text DEFAULT 'freelancer'::text NOT NULL,
    name_de text NOT NULL,
    name_en text DEFAULT ''::text NOT NULL,
    costs text DEFAULT '{}'::text NOT NULL,
    rate_day numeric(14,4),
    intext text DEFAULT 'extern'::text NOT NULL,
    markup_pct numeric(14,4),
    sort double precision DEFAULT 0 NOT NULL,
    archived bigint DEFAULT 0 NOT NULL,
    import_run_id bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL
);

ALTER TABLE ONLY public.office_roles FORCE ROW LEVEL SECURITY;


--
-- Name: office_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_roles ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_services (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    name_de text NOT NULL,
    name_en text DEFAULT ''::text NOT NULL,
    category text DEFAULT ''::text NOT NULL,
    sort double precision DEFAULT 0 NOT NULL,
    unit text DEFAULT 'day'::text NOT NULL,
    daily_rate numeric(14,4),
    hourly_rate numeric(14,4),
    raw_fee bigint DEFAULT 0 NOT NULL,
    producing bigint DEFAULT 0 NOT NULL,
    intext text DEFAULT 'extern'::text NOT NULL,
    role text DEFAULT ''::text NOT NULL,
    tax text DEFAULT 'standard'::text NOT NULL,
    archived bigint DEFAULT 0 NOT NULL,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    import_run_id bigint,
    role_id bigint
);

ALTER TABLE ONLY public.office_services FORCE ROW LEVEL SECURITY;


--
-- Name: office_services_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_services ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_services_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_sets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_sets (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    name text NOT NULL,
    discount_pct numeric(14,4),
    items text DEFAULT '[]'::text NOT NULL,
    archived bigint DEFAULT 0 NOT NULL,
    created_at text NOT NULL,
    updated_at text NOT NULL
);

ALTER TABLE ONLY public.office_sets FORCE ROW LEVEL SECURITY;


--
-- Name: office_sets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_sets ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_sets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_settings (
    org_id bigint NOT NULL,
    data text DEFAULT '{}'::text NOT NULL,
    updated_at text NOT NULL
);

ALTER TABLE ONLY public.office_settings FORCE ROW LEVEL SECURITY;


--
-- Name: office_signoffs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_signoffs (
    id bigint NOT NULL,
    org_id bigint,
    kind text DEFAULT 'offer'::text NOT NULL,
    doc_id bigint,
    list_id bigint,
    section_id bigint,
    task_id bigint,
    title text DEFAULT ''::text NOT NULL,
    token_hash text NOT NULL,
    token text NOT NULL,
    expires_at text,
    revoked_at text,
    state text DEFAULT 'open'::text NOT NULL,
    signer_name text,
    signer_email text,
    reason text,
    signed_at text,
    ip text,
    user_agent text,
    doc_hash text DEFAULT ''::text NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    gen_doc_id bigint,
    video_id bigint
);

ALTER TABLE ONLY public.office_signoffs FORCE ROW LEVEL SECURITY;


--
-- Name: office_signoffs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_signoffs ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_signoffs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_sub_reminders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_sub_reminders (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    fixed_id bigint NOT NULL,
    due text NOT NULL,
    task_id bigint,
    user_id bigint,
    created_at text NOT NULL
);

ALTER TABLE ONLY public.office_sub_reminders FORCE ROW LEVEL SECURITY;


--
-- Name: office_sub_reminders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_sub_reminders ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_sub_reminders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_texts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_texts (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    kind text NOT NULL,
    key text DEFAULT ''::text NOT NULL,
    text_de text DEFAULT ''::text NOT NULL,
    text_en text DEFAULT ''::text NOT NULL,
    sort double precision DEFAULT 0 NOT NULL,
    archived bigint DEFAULT 0 NOT NULL
);

ALTER TABLE ONLY public.office_texts FORCE ROW LEVEL SECURITY;


--
-- Name: office_texts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_texts ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_texts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_trip_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_trip_items (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    trip_id bigint NOT NULL,
    date text DEFAULT ''::text NOT NULL,
    category text DEFAULT 'other'::text NOT NULL,
    amount text DEFAULT '0'::text NOT NULL,
    currency text DEFAULT 'EUR'::text NOT NULL,
    fx_rate numeric(14,6),
    amount_home text DEFAULT '0'::text NOT NULL,
    text text DEFAULT ''::text NOT NULL,
    datev bigint DEFAULT 0 NOT NULL,
    datev_no text DEFAULT ''::text NOT NULL,
    billed_doc_id bigint,
    billed_at text,
    sort double precision DEFAULT 0 NOT NULL,
    created_at text NOT NULL,
    updated_at text NOT NULL
);

ALTER TABLE ONLY public.office_trip_items FORCE ROW LEVEL SECURITY;


--
-- Name: office_trip_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_trip_items ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_trip_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_trips; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_trips (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    date_from text DEFAULT ''::text NOT NULL,
    date_to text DEFAULT ''::text NOT NULL,
    dest text DEFAULT ''::text NOT NULL,
    overnight bigint DEFAULT 0 NOT NULL,
    people text DEFAULT '[]'::text NOT NULL,
    purpose text DEFAULT 'job'::text NOT NULL,
    client_id bigint,
    project text DEFAULT ''::text NOT NULL,
    km numeric(14,2),
    note text DEFAULT ''::text NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    country text DEFAULT ''::text NOT NULL,
    place text DEFAULT ''::text NOT NULL,
    t_start text DEFAULT ''::text NOT NULL,
    t_end text DEFAULT ''::text NOT NULL,
    vma_days text DEFAULT '[]'::text NOT NULL,
    vma_off bigint DEFAULT 0 NOT NULL
);

ALTER TABLE ONLY public.office_trips FORCE ROW LEVEL SECURITY;


--
-- Name: office_trips_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_trips ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_trips_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: office_vehicles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_vehicles (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    plate text DEFAULT ''::text NOT NULL,
    kind text DEFAULT 'private'::text NOT NULL,
    odo_start numeric(14,1),
    archived bigint DEFAULT 0 NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL
);

ALTER TABLE ONLY public.office_vehicles FORCE ROW LEVEL SECURITY;


--
-- Name: office_vehicles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.office_vehicles ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.office_vehicles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: org_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.org_keys (
    org_id bigint NOT NULL,
    wrapped text NOT NULL,
    kek_check text NOT NULL,
    created_at text NOT NULL,
    migrated_at text,
    recovery_shown_at text,
    wrapped_prev text,
    kek_check_prev text
);

ALTER TABLE ONLY public.org_keys FORCE ROW LEVEL SECURITY;


--
-- Name: org_list_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.org_list_log (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    list_id bigint,
    list_name text DEFAULT ''::text NOT NULL,
    action text NOT NULL,
    by_id bigint,
    owner_id bigint,
    to_id bigint,
    created_at text NOT NULL,
    detail text
);

ALTER TABLE ONLY public.org_list_log FORCE ROW LEVEL SECURITY;


--
-- Name: org_list_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.org_list_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.org_list_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: org_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.org_members (
    org_id bigint NOT NULL,
    user_id bigint NOT NULL,
    role text DEFAULT 'member'::text NOT NULL
);

ALTER TABLE ONLY public.org_members FORCE ROW LEVEL SECURITY;


--
-- Name: orgs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orgs (
    id bigint NOT NULL,
    name text NOT NULL,
    icon text DEFAULT ''::text NOT NULL,
    created_at text NOT NULL,
    domains text DEFAULT ''::text NOT NULL,
    personal_of bigint,
    hub_holiday_state text DEFAULT ''::text NOT NULL,
    color text DEFAULT ''::text NOT NULL,
    photo_meta_strip bigint DEFAULT 1 NOT NULL
);

ALTER TABLE ONLY public.orgs FORCE ROW LEVEL SECURITY;


--
-- Name: orgs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.orgs ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.orgs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: paperless_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.paperless_links (
    id bigint NOT NULL,
    task_id bigint NOT NULL,
    doc_id bigint,
    title text DEFAULT ''::text NOT NULL,
    correspondent text DEFAULT ''::text NOT NULL,
    created text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'ok'::text NOT NULL,
    message text DEFAULT ''::text NOT NULL,
    ptask text,
    att_id bigint,
    added_at text NOT NULL,
    conn_id bigint,
    added_by bigint
);


--
-- Name: paperless_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.paperless_links ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.paperless_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: pl_conn_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pl_conn_users (
    conn_id bigint NOT NULL,
    user_id bigint NOT NULL
);


--
-- Name: pl_conns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pl_conns (
    id bigint NOT NULL,
    kind text NOT NULL,
    owner_id bigint,
    name text NOT NULL,
    url text NOT NULL,
    created_at text NOT NULL
);


--
-- Name: pl_conns_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.pl_conns ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.pl_conns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: pl_imported; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pl_imported (
    ws text NOT NULL,
    src text NOT NULL,
    pl_id bigint NOT NULL,
    org_id bigint,
    node_id bigint,
    sha256 text DEFAULT ''::text NOT NULL,
    asn bigint,
    dup bigint DEFAULT 0 NOT NULL,
    created_at text NOT NULL
);

ALTER TABLE ONLY public.pl_imported FORCE ROW LEVEL SECURITY;


--
-- Name: pl_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pl_rules (
    ws text NOT NULL,
    src text NOT NULL,
    kind text NOT NULL,
    pl_id bigint NOT NULL,
    org_id bigint,
    rule_id bigint,
    created_at text NOT NULL
);

ALTER TABLE ONLY public.pl_rules FORCE ROW LEVEL SECURITY;


--
-- Name: pl_sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pl_sources (
    id bigint NOT NULL,
    org_id bigint,
    ws text NOT NULL,
    url text NOT NULL,
    token text DEFAULT ''::text NOT NULL,
    mapping text DEFAULT ''::text NOT NULL,
    follow bigint DEFAULT 0 NOT NULL,
    every_min bigint DEFAULT 15 NOT NULL,
    run_state text DEFAULT ''::text NOT NULL,
    run_kind text DEFAULT ''::text NOT NULL,
    run_by bigint,
    run_total bigint DEFAULT 0 NOT NULL,
    run_done bigint DEFAULT 0 NOT NULL,
    run_new bigint DEFAULT 0 NOT NULL,
    run_skip bigint DEFAULT 0 NOT NULL,
    run_fail bigint DEFAULT 0 NOT NULL,
    run_beat text,
    run_error text DEFAULT ''::text NOT NULL,
    synced_at text,
    error text DEFAULT ''::text NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    run_learn text DEFAULT ''::text NOT NULL,
    run_ws text DEFAULT ''::text NOT NULL
);

ALTER TABLE ONLY public.pl_sources FORCE ROW LEVEL SECURITY;


--
-- Name: pl_sources_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.pl_sources ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.pl_sources_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: pl_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pl_tokens (
    conn_id bigint NOT NULL,
    user_id bigint NOT NULL,
    token text NOT NULL,
    updated_at text NOT NULL
);


--
-- Name: pl_uploads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pl_uploads (
    id bigint NOT NULL,
    org_id bigint,
    ws text NOT NULL,
    created_by bigint,
    state text DEFAULT 'upload'::text NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    got bigint DEFAULT 0 NOT NULL,
    parts bigint DEFAULT 0 NOT NULL,
    chunk bigint DEFAULT 0 NOT NULL,
    info text DEFAULT ''::text NOT NULL,
    mapping text DEFAULT ''::text NOT NULL,
    error text DEFAULT ''::text NOT NULL,
    run_state text DEFAULT ''::text NOT NULL,
    run_by bigint,
    run_total bigint DEFAULT 0 NOT NULL,
    run_done bigint DEFAULT 0 NOT NULL,
    run_new bigint DEFAULT 0 NOT NULL,
    run_skip bigint DEFAULT 0 NOT NULL,
    run_fail bigint DEFAULT 0 NOT NULL,
    run_beat text,
    run_error text DEFAULT ''::text NOT NULL,
    run_learn text DEFAULT ''::text NOT NULL,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    src text DEFAULT ''::text NOT NULL,
    run_ws text DEFAULT ''::text NOT NULL
);

ALTER TABLE ONLY public.pl_uploads FORCE ROW LEVEL SECURITY;


--
-- Name: pl_uploads_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.pl_uploads ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.pl_uploads_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: playbook_proposals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.playbook_proposals (
    id bigint NOT NULL,
    list_id bigint NOT NULL,
    agent_id bigint NOT NULL,
    body text NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    base_version bigint DEFAULT 0 NOT NULL,
    state text DEFAULT 'open'::text NOT NULL,
    created_at text NOT NULL,
    decided_by bigint,
    decided_at text
);


--
-- Name: playbook_proposals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.playbook_proposals ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.playbook_proposals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: playbooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.playbooks (
    id bigint NOT NULL,
    list_id bigint,
    owner_id bigint,
    folder text,
    version bigint NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    source text DEFAULT 'edit'::text NOT NULL,
    author_id bigint,
    created_at text NOT NULL
);


--
-- Name: playbooks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.playbooks ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.playbooks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: pomos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pomos (
    id bigint NOT NULL,
    task_id bigint,
    kind text DEFAULT 'focus'::text NOT NULL,
    minutes bigint NOT NULL,
    start text NOT NULL,
    paused_at text,
    paused_s bigint DEFAULT 0 NOT NULL,
    "end" text,
    done bigint DEFAULT 0 NOT NULL,
    notified bigint DEFAULT 0 NOT NULL,
    user_id bigint
);


--
-- Name: pomos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.pomos ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.pomos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: portal_logins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.portal_logins (
    id bigint NOT NULL,
    email_hash text NOT NULL,
    org_id bigint,
    owner_id bigint,
    token_hash text NOT NULL,
    created_at text NOT NULL,
    expires_at text NOT NULL,
    used_at text,
    revoked_at text
);

ALTER TABLE ONLY public.portal_logins FORCE ROW LEVEL SECURITY;


--
-- Name: portal_logins_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.portal_logins ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.portal_logins_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: portal_tickets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.portal_tickets (
    id bigint NOT NULL,
    task_id bigint NOT NULL,
    list_id bigint NOT NULL,
    org_id bigint,
    owner_id bigint,
    form_id bigint,
    client_id bigint,
    name text DEFAULT ''::text NOT NULL,
    email text DEFAULT ''::text NOT NULL,
    email_hash text DEFAULT ''::text NOT NULL,
    token text NOT NULL,
    token_hash text NOT NULL,
    notify bigint DEFAULT 1 NOT NULL,
    created_at text NOT NULL,
    last_seen_at text,
    last_mail_at text,
    mailed_status bigint DEFAULT 0 NOT NULL,
    lang text DEFAULT ''::text NOT NULL
);

ALTER TABLE ONLY public.portal_tickets FORCE ROW LEVEL SECURITY;


--
-- Name: portal_tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.portal_tickets ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.portal_tickets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: public_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.public_links (
    id bigint NOT NULL,
    list_id bigint NOT NULL,
    token_hash text NOT NULL,
    token text NOT NULL,
    mode text DEFAULT 'view'::text NOT NULL,
    notes bigint DEFAULT 0 NOT NULL,
    password_hash text,
    pw_rev bigint DEFAULT 0 NOT NULL,
    expires_at text,
    created_by bigint,
    created_at text NOT NULL,
    last_used_at text,
    views bigint DEFAULT 0 NOT NULL,
    cv_show text DEFAULT ''::text NOT NULL
);


--
-- Name: public_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.public_links ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.public_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: push_subs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.push_subs (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    endpoint text NOT NULL,
    p256dh text NOT NULL,
    auth text NOT NULL,
    label text DEFAULT ''::text NOT NULL,
    created_at text NOT NULL,
    last_ok text,
    fails bigint DEFAULT 0 NOT NULL,
    backoff_until double precision DEFAULT 0 NOT NULL,
    dismiss_at double precision DEFAULT 0 NOT NULL,
    dismiss_day text DEFAULT ''::text NOT NULL,
    dismiss_n bigint DEFAULT 0 NOT NULL
);


--
-- Name: push_subs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.push_subs ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.push_subs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: push_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.push_tags (
    sub_id bigint NOT NULL,
    tag text NOT NULL,
    sent_at double precision NOT NULL,
    handled_at double precision
);


--
-- Name: rc_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rc_receipts (
    node_id bigint NOT NULL,
    org_id bigint,
    ws text NOT NULL,
    list_id bigint,
    category text DEFAULT ''::text NOT NULL,
    set_by bigint,
    set_at text NOT NULL,
    vat_pct text,
    paid_at text
);

ALTER TABLE ONLY public.rc_receipts FORCE ROW LEVEL SECURITY;


--
-- Name: rc_suggest; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rc_suggest (
    id bigint NOT NULL,
    node_id bigint NOT NULL,
    org_id bigint,
    ws text NOT NULL,
    agent_id bigint NOT NULL,
    list_id bigint,
    category text DEFAULT ''::text NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    state text DEFAULT 'open'::text NOT NULL,
    decided_by bigint,
    decided_at text,
    prev_list_id bigint,
    prev_category text DEFAULT ''::text NOT NULL,
    created_at text NOT NULL
);

ALTER TABLE ONLY public.rc_suggest FORCE ROW LEVEL SECURITY;


--
-- Name: rc_suggest_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.rc_suggest ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.rc_suggest_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: recovery_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recovery_codes (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    code_hash text NOT NULL,
    created_at text NOT NULL,
    used_at text
);


--
-- Name: recovery_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.recovery_codes ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.recovery_codes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rss_feeds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rss_feeds (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    url text NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    site_url text DEFAULT ''::text NOT NULL,
    etag text DEFAULT ''::text NOT NULL,
    last_modified text DEFAULT ''::text NOT NULL,
    last_fetch text,
    last_ok text,
    last_error text DEFAULT ''::text NOT NULL,
    fails bigint DEFAULT 0 NOT NULL,
    created_at text NOT NULL,
    deleted_at text
);


--
-- Name: rss_feeds_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.rss_feeds ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.rss_feeds_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rss_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rss_items (
    id bigint NOT NULL,
    feed_id bigint NOT NULL,
    user_id bigint NOT NULL,
    guid text NOT NULL,
    url text DEFAULT ''::text NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    summary text DEFAULT ''::text NOT NULL,
    published text NOT NULL,
    fetched_at text NOT NULL,
    read_at text,
    saved_task_id bigint
);


--
-- Name: rss_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.rss_items ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.rss_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sample_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sample_items (
    user_id bigint NOT NULL,
    kind text NOT NULL,
    item_id bigint NOT NULL
);


--
-- Name: sections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sections (
    id bigint NOT NULL,
    list_id bigint NOT NULL,
    name text NOT NULL,
    sort double precision DEFAULT 0 NOT NULL,
    wip_limit bigint
);


--
-- Name: sections_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.sections ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.sections_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    token_hash text NOT NULL,
    user_id bigint NOT NULL,
    created_at text NOT NULL,
    expires_at text NOT NULL,
    via text DEFAULT 'password'::text NOT NULL
);


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settings (
    key text NOT NULL,
    value text NOT NULL
);


--
-- Name: sev_known; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sev_known (
    kind text NOT NULL,
    ref text NOT NULL,
    at text NOT NULL
);


--
-- Name: sheet_cells; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sheet_cells (
    id bigint NOT NULL,
    sheet_id bigint NOT NULL,
    row_id bigint NOT NULL,
    col_id bigint NOT NULL,
    raw text DEFAULT ''::text NOT NULL,
    name text,
    frozen bigint DEFAULT 0 NOT NULL,
    frozen_value text,
    updated_by bigint,
    updated_at text NOT NULL,
    agent_id bigint,
    agent_batch text
);


--
-- Name: sheet_cells_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.sheet_cells ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.sheet_cells_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sheet_changes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sheet_changes (
    id bigint NOT NULL,
    sheet_id bigint NOT NULL,
    batch text NOT NULL,
    agent_id bigint,
    cell_id bigint,
    row_id bigint,
    col_id bigint,
    kind text NOT NULL,
    old_raw text,
    new_raw text,
    created_at text NOT NULL,
    undone_at text
);


--
-- Name: sheet_changes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.sheet_changes ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.sheet_changes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sheet_columns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sheet_columns (
    id bigint NOT NULL,
    sheet_id bigint NOT NULL,
    pos double precision DEFAULT 0 NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    kind text DEFAULT 'text'::text NOT NULL,
    options text DEFAULT '[]'::text NOT NULL,
    color_mode text DEFAULT 'cell'::text NOT NULL,
    width bigint,
    deleted_at text
);


--
-- Name: sheet_columns_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.sheet_columns ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.sheet_columns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sheet_lastvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sheet_lastvals (
    cell_id bigint NOT NULL,
    user_id bigint NOT NULL,
    value text DEFAULT ''::text NOT NULL,
    at text NOT NULL
);


--
-- Name: sheet_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sheet_links (
    id bigint NOT NULL,
    sheet_id bigint NOT NULL,
    row_id bigint,
    kind text NOT NULL,
    target_id bigint NOT NULL,
    list_id bigint,
    batch text NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    undone_at text
);


--
-- Name: sheet_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.sheet_links ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.sheet_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sheet_rows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sheet_rows (
    id bigint NOT NULL,
    sheet_id bigint NOT NULL,
    pos double precision DEFAULT 0 NOT NULL,
    deleted_at text
);


--
-- Name: sheet_rows_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.sheet_rows ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.sheet_rows_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sheets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sheets (
    id bigint NOT NULL,
    org_id bigint,
    owner_id bigint,
    title text DEFAULT ''::text NOT NULL,
    list_id bigint,
    created_by bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    updated_by bigint,
    deleted_at text,
    agent_id bigint,
    agent_batch text,
    rev bigint DEFAULT 0 NOT NULL
);

ALTER TABLE ONLY public.sheets FORCE ROW LEVEL SECURITY;


--
-- Name: sheets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.sheets ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.sheets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shop_memory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop_memory (
    list_id bigint NOT NULL,
    item text NOT NULL,
    section_id bigint NOT NULL,
    at text NOT NULL
);


--
-- Name: space_moves; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.space_moves (
    id bigint NOT NULL,
    kind text NOT NULL,
    obj_id bigint NOT NULL,
    from_org bigint,
    to_org bigint,
    by_id bigint,
    at text NOT NULL,
    detail text DEFAULT '{}'::text NOT NULL
);


--
-- Name: space_moves_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.space_moves ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.space_moves_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sprints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sprints (
    id bigint NOT NULL,
    list_id bigint NOT NULL,
    num bigint NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    start text NOT NULL,
    end_day text NOT NULL,
    goal text DEFAULT ''::text NOT NULL,
    state text DEFAULT 'planned'::text NOT NULL,
    review text,
    closed_at text,
    created_at text NOT NULL,
    created_by bigint
);


--
-- Name: sprints_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.sprints ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.sprints_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: task_bell; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_bell (
    task_id bigint NOT NULL,
    user_id bigint NOT NULL,
    org_id bigint,
    level text DEFAULT 'list'::text NOT NULL,
    until text,
    set_by bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    prev text,
    act text,
    act_by bigint
);

ALTER TABLE ONLY public.task_bell FORCE ROW LEVEL SECURITY;


--
-- Name: task_deps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_deps (
    task_id bigint NOT NULL,
    blocker_id bigint NOT NULL,
    created_by bigint,
    created_at text NOT NULL
);


--
-- Name: task_enc_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_enc_notes (
    task_id bigint NOT NULL,
    user_id bigint NOT NULL,
    body text NOT NULL,
    updated_at text NOT NULL
);


--
-- Name: task_field_values; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_field_values (
    task_id bigint NOT NULL,
    field_id bigint NOT NULL,
    value text NOT NULL
);


--
-- Name: task_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_links (
    task_id bigint NOT NULL,
    list_id bigint NOT NULL,
    section_id bigint,
    sort double precision DEFAULT 0 NOT NULL,
    org_id bigint,
    added_by bigint,
    created_at text NOT NULL
);

ALTER TABLE ONLY public.task_links FORCE ROW LEVEL SECURITY;


--
-- Name: task_list_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_list_tags (
    task_id bigint NOT NULL,
    tag_id bigint NOT NULL
);


--
-- Name: task_note_locks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_note_locks (
    task_id bigint NOT NULL,
    user_id bigint NOT NULL,
    body text NOT NULL,
    updated_at text NOT NULL
);


--
-- Name: task_people; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_people (
    task_id bigint NOT NULL,
    user_id bigint NOT NULL
);


--
-- Name: task_push; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_push (
    user_id bigint NOT NULL,
    task_id bigint NOT NULL,
    sent_at double precision DEFAULT 0 NOT NULL,
    pending bigint DEFAULT 0 NOT NULL,
    events bigint DEFAULT 0 NOT NULL,
    mentioned bigint DEFAULT 0 NOT NULL
);


--
-- Name: task_seen; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_seen (
    user_id bigint NOT NULL,
    task_id bigint NOT NULL,
    seen_id bigint DEFAULT 0 NOT NULL
);


--
-- Name: task_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_tags (
    task_id bigint NOT NULL,
    user_id bigint DEFAULT 0 NOT NULL,
    tag text NOT NULL
);


--
-- Name: task_vectors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_vectors (
    task_id bigint NOT NULL,
    org_id bigint,
    list_id bigint,
    model text NOT NULL,
    dim bigint NOT NULL,
    vec text NOT NULL,
    text_hash text NOT NULL,
    updated_at text NOT NULL
);

ALTER TABLE ONLY public.task_vectors FORCE ROW LEVEL SECURITY;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tasks (
    id bigint NOT NULL,
    list_id bigint NOT NULL,
    section_id bigint,
    parent_id bigint,
    title text NOT NULL,
    content text DEFAULT ''::text NOT NULL,
    priority bigint DEFAULT 0 NOT NULL,
    status bigint DEFAULT 0 NOT NULL,
    due text,
    due_time text,
    reminders text DEFAULT ''::text NOT NULL,
    reminded text DEFAULT ''::text NOT NULL,
    repeat text DEFAULT ''::text NOT NULL,
    repeat_from text DEFAULT 'due'::text NOT NULL,
    sort double precision DEFAULT 0 NOT NULL,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    completed_at text,
    deleted_at text,
    tt_id text,
    pinned bigint DEFAULT 0 NOT NULL,
    start text,
    duration bigint,
    created_by bigint,
    assignee_id bigint,
    url text,
    assigned_by bigint,
    completed_by bigint,
    waiting_at text,
    wait_note text DEFAULT ''::text NOT NULL,
    wait_until text,
    wait_by bigint,
    wait_fired text DEFAULT ''::text NOT NULL,
    ttype text DEFAULT ''::text NOT NULL,
    deadline bigint DEFAULT 0 NOT NULL,
    nag text DEFAULT ''::text NOT NULL,
    nag_at text DEFAULT ''::text NOT NULL,
    assignee_group_id bigint,
    plan_start text,
    ms bigint DEFAULT 0 NOT NULL,
    milestone_id bigint,
    fam text DEFAULT ''::text NOT NULL,
    rotation text DEFAULT ''::text NOT NULL,
    stars bigint,
    approval text DEFAULT ''::text NOT NULL,
    approver_id bigint,
    snippets jsonb,
    locked bigint DEFAULT 0 NOT NULL,
    sprint_id bigint,
    sprint_at text,
    points bigint,
    reviewer_id bigint,
    review text DEFAULT ''::text NOT NULL,
    review_at text,
    review_by bigint,
    review_sec bigint
);


--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.tasks ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tchat_msgs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tchat_msgs (
    id bigint NOT NULL,
    room_id bigint NOT NULL,
    user_id bigint,
    body text NOT NULL,
    task_id bigint,
    created_at text NOT NULL,
    edited_at text,
    deleted_at text,
    reply_to bigint,
    enc text,
    client_id text,
    pinned_at text,
    pinned_by bigint
);


--
-- Name: tchat_msgs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.tchat_msgs ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.tchat_msgs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tchat_reads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tchat_reads (
    room_id bigint NOT NULL,
    user_id bigint NOT NULL,
    last_id bigint DEFAULT 0 NOT NULL,
    muted bigint DEFAULT 0 NOT NULL
);


--
-- Name: tchat_rooms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tchat_rooms (
    id bigint NOT NULL,
    kind text NOT NULL,
    list_id bigint,
    a bigint,
    b bigint,
    created_at text NOT NULL,
    last_at text,
    e2e bigint DEFAULT 0 NOT NULL
);


--
-- Name: tchat_rooms_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.tchat_rooms ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.tchat_rooms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tchat_rx; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tchat_rx (
    message_id bigint NOT NULL,
    user_id bigint NOT NULL,
    emoji text NOT NULL,
    created_at text NOT NULL
);


--
-- Name: templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.templates (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    kind text DEFAULT 'task'::text NOT NULL,
    name text NOT NULL,
    data text DEFAULT '{}'::text NOT NULL,
    created_at text NOT NULL,
    updated_at text NOT NULL
);


--
-- Name: templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.templates ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tidy_pending; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tidy_pending (
    task_id bigint NOT NULL,
    actor_id bigint,
    created_at text NOT NULL,
    sent_at text
);


--
-- Name: time_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.time_entries (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    task_id bigint,
    list_id bigint,
    task_title text DEFAULT ''::text NOT NULL,
    start text NOT NULL,
    "end" text,
    seconds bigint DEFAULT 0 NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    source text DEFAULT 'manual'::text NOT NULL,
    pomo_id bigint,
    client_id text,
    reminded bigint DEFAULT 0 NOT NULL,
    auto_stopped bigint DEFAULT 0 NOT NULL,
    created_at text NOT NULL,
    updated_at text NOT NULL
);


--
-- Name: time_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.time_entries ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.time_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: upload_scan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.upload_scan (
    id bigint NOT NULL,
    kind text NOT NULL,
    ref_id bigint NOT NULL,
    ver bigint DEFAULT 0 NOT NULL,
    org_id bigint,
    state text DEFAULT 'unchecked'::text NOT NULL,
    sig text DEFAULT ''::text NOT NULL,
    why text DEFAULT ''::text NOT NULL,
    tries bigint DEFAULT 0 NOT NULL,
    next_at text,
    created_at text NOT NULL,
    checked_at text
);

ALTER TABLE ONLY public.upload_scan FORCE ROW LEVEL SECURITY;


--
-- Name: upload_scan_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.upload_scan ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.upload_scan_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_invites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_invites (
    user_id bigint NOT NULL,
    token_hash text NOT NULL,
    kind text DEFAULT 'invite'::text NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    expires_at text NOT NULL,
    sent_at text,
    used_at text
);


--
-- Name: user_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_keys (
    user_id bigint NOT NULL,
    wrapped text NOT NULL,
    kek_check text NOT NULL,
    created_at text NOT NULL,
    migrated_at text,
    wrapped_prev text,
    kek_check_prev text
);


--
-- Name: user_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_settings (
    user_id bigint NOT NULL,
    key text NOT NULL,
    value text NOT NULL
);


--
-- Name: user_task_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_task_order (
    user_id bigint NOT NULL,
    task_id bigint NOT NULL,
    pos bigint NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    username text NOT NULL,
    display_name text DEFAULT ''::text NOT NULL,
    password_hash text,
    proxy_login text,
    is_admin bigint DEFAULT 0 NOT NULL,
    drop_token text,
    created_at text NOT NULL,
    disabled bigint DEFAULT 0 NOT NULL,
    ical_token text,
    paperless_access bigint DEFAULT 0 NOT NULL,
    totp_secret text,
    totp_step bigint DEFAULT 0 NOT NULL,
    webauthn_handle text,
    oidc_subject text,
    email text,
    avatar text,
    kind text DEFAULT 'user'::text NOT NULL,
    kid bigint DEFAULT 0 NOT NULL,
    signup text DEFAULT ''::text NOT NULL,
    storage_quota_mb bigint,
    color text DEFAULT ''::text NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.users ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: video_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.video_comments (
    id bigint NOT NULL,
    review_id bigint NOT NULL,
    version_id bigint,
    org_id bigint,
    parent_id bigint,
    at_sec real,
    body text DEFAULT ''::text NOT NULL,
    author_id bigint,
    ext_name text,
    done bigint DEFAULT 0 NOT NULL,
    created_at text NOT NULL,
    deleted_at text
);

ALTER TABLE ONLY public.video_comments FORCE ROW LEVEL SECURITY;


--
-- Name: video_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.video_comments ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.video_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: video_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.video_reviews (
    id bigint NOT NULL,
    org_id bigint,
    owner_id bigint,
    task_id bigint,
    list_id bigint,
    client_id bigint,
    title text DEFAULT ''::text NOT NULL,
    state text DEFAULT 'open'::text NOT NULL,
    created_by bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    deleted_at text
);

ALTER TABLE ONLY public.video_reviews FORCE ROW LEVEL SECURITY;


--
-- Name: video_reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.video_reviews ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.video_reviews_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: video_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.video_versions (
    id bigint NOT NULL,
    review_id bigint NOT NULL,
    org_id bigint,
    n bigint DEFAULT 1 NOT NULL,
    url text NOT NULL,
    provider text DEFAULT 'link'::text NOT NULL,
    embed_id text DEFAULT ''::text NOT NULL,
    created_by bigint,
    created_at text NOT NULL
);

ALTER TABLE ONLY public.video_versions FORCE ROW LEVEL SECURITY;


--
-- Name: video_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.video_versions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.video_versions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: view_layout_offers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.view_layout_offers (
    id bigint NOT NULL,
    from_user bigint NOT NULL,
    to_user bigint NOT NULL,
    view_key text NOT NULL,
    name text NOT NULL,
    layout text DEFAULT ''::text NOT NULL,
    state text DEFAULT 'open'::text NOT NULL,
    created_at text NOT NULL,
    decided_at text
);


--
-- Name: view_layout_offers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.view_layout_offers ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.view_layout_offers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: view_layouts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.view_layouts (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    view_key text NOT NULL,
    name text NOT NULL,
    layout text DEFAULT ''::text NOT NULL,
    pos bigint DEFAULT 0 NOT NULL,
    source text DEFAULT ''::text NOT NULL,
    source_ref text,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    active bigint DEFAULT 0 NOT NULL
);


--
-- Name: view_layouts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.view_layouts ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.view_layouts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: wait_hidden; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wait_hidden (
    user_id bigint NOT NULL,
    note_key text NOT NULL,
    created_at text NOT NULL
);


--
-- Name: webauthn_creds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webauthn_creds (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    cred_id text NOT NULL,
    public_key bytea NOT NULL,
    sign_count bigint DEFAULT 0 NOT NULL,
    transports text DEFAULT ''::text NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    rp_id text DEFAULT ''::text NOT NULL,
    aaguid text DEFAULT ''::text NOT NULL,
    backed_up bigint DEFAULT 0 NOT NULL,
    discoverable bigint,
    created_at text NOT NULL,
    last_used_at text
);


--
-- Name: webauthn_creds_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.webauthn_creds ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.webauthn_creds_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: webhook_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_log (
    id bigint NOT NULL,
    webhook_id bigint NOT NULL,
    delivery text NOT NULL,
    event text NOT NULL,
    attempt bigint DEFAULT 1 NOT NULL,
    ok bigint DEFAULT 0 NOT NULL,
    status bigint,
    error text DEFAULT ''::text NOT NULL,
    ms bigint DEFAULT 0 NOT NULL,
    created_at text NOT NULL
);


--
-- Name: webhook_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.webhook_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.webhook_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: webhook_queue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_queue (
    id bigint NOT NULL,
    webhook_id bigint NOT NULL,
    delivery text NOT NULL,
    event text NOT NULL,
    payload text NOT NULL,
    attempt bigint DEFAULT 0 NOT NULL,
    next_at double precision NOT NULL,
    created_at text NOT NULL
);


--
-- Name: webhook_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.webhook_queue ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.webhook_queue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    url text NOT NULL,
    events text DEFAULT ''::text NOT NULL,
    secret text NOT NULL,
    enabled bigint DEFAULT 1 NOT NULL,
    disabled_reason text DEFAULT ''::text NOT NULL,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    agent bigint DEFAULT 0 NOT NULL
);


--
-- Name: webhooks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.webhooks ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.webhooks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: wiki_key_pending; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wiki_key_pending (
    space_id bigint NOT NULL,
    user_id bigint NOT NULL,
    since text NOT NULL
);


--
-- Name: wiki_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wiki_keys (
    space_id bigint NOT NULL,
    gen bigint NOT NULL,
    user_id bigint NOT NULL,
    wrapped text NOT NULL,
    wrapped_by bigint,
    wrapper_pub text NOT NULL,
    created_at text NOT NULL
);


--
-- Name: wiki_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wiki_links (
    from_id bigint NOT NULL,
    to_path text,
    to_task bigint,
    to_list bigint
);


--
-- Name: wiki_pages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wiki_pages (
    id bigint NOT NULL,
    org_id bigint,
    owner_id bigint,
    path text NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    attrs text DEFAULT '{}'::text NOT NULL,
    created_by bigint,
    updated_by bigint,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    deleted_at text
);

ALTER TABLE ONLY public.wiki_pages FORCE ROW LEVEL SECURITY;


--
-- Name: wiki_pages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.wiki_pages ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.wiki_pages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: wiki_spaces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wiki_spaces (
    id bigint NOT NULL,
    org_id bigint,
    owner_id bigint,
    e2e text,
    e2e_gen bigint DEFAULT 0 NOT NULL,
    e2e_rotate bigint DEFAULT 0 NOT NULL,
    e2e_reenc bigint DEFAULT 0 NOT NULL,
    e2e_by bigint,
    e2e_at text,
    CONSTRAINT wiki_spaces_check CHECK (((org_id IS NULL) <> (owner_id IS NULL)))
);

ALTER TABLE ONLY public.wiki_spaces FORCE ROW LEVEL SECURITY;


--
-- Name: wiki_spaces_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.wiki_spaces ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.wiki_spaces_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: activity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.activity (id, task_id, user_id, kind, data, created_at) FROM stdin;
1	1	1	created	{}	2026-10-23T06:08:27.933+00:00
2	1	1	repeat	{"rule": "FREQ=WEEKLY;BYDAY=MO"}	2026-10-23T06:08:27.948+00:00
3	2	1	created	{}	2026-10-23T06:08:27.959+00:00
4	1	1	subtask	{"id": 2, "title": "Rohschnitt"}	2026-10-23T06:08:27.964+00:00
5	3	1	created	{}	2026-10-23T06:08:27.974+00:00
6	1	1	subtask	{"id": 3, "title": "Farbkorrektur"}	2026-10-23T06:08:27.978+00:00
7	4	1	created	{}	2026-10-23T06:08:27.989+00:00
8	5	1	created	{}	2026-10-23T06:08:28.003+00:00
9	5	1	complete	{}	2026-10-23T06:08:28.016+00:00
10	6	1	created	{}	2026-10-23T06:08:28.026+00:00
11	7	1	created	{}	2026-10-23T06:08:28.035+00:00
12	1	1	attach	{"n": 1, "names": ["briefing.txt"]}	2026-10-23T06:08:28.071+00:00
13	8	3	created	{}	2026-10-23T06:08:28.088+00:00
\.


--
-- Data for Name: admin_alerts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_alerts (id, kind, key, message, tmpl, created_at, sent_at, delivered, state, repeats) FROM stdin;
\.


--
-- Data for Name: admin_login_ips; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_login_ips (user_id, ip_hash, first_at, last_at) FROM stdin;
1	6d7fe9fa43ba6e5a0797fe2999e33cfc2880e76890a7b6840684bdf38a605eb3	2026-10-23T06:08:27+00:00	2026-10-23T06:08:27+00:00
\.


--
-- Data for Name: agent_audit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_audit (id, agent_id, at, day, method, route, status, task_id, list_id, ms, scope) FROM stdin;
\.


--
-- Data for Name: agent_bridges; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_bridges (agent_id, list_a, list_b, by_id, at) FROM stdin;
\.


--
-- Data for Name: agent_chat; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_chat (id, agent_id, user_id, sender, body, task_id, created_at, read_at, delivered_at, choices, choice, job_id, job_parent, reply_to, offer_save, edited_at, edits, kind, job_msg, client_id, pinned_at, pinned_by) FROM stdin;
\.


--
-- Data for Name: agent_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_events (id, agent_id, uuid, event, payload, created_at) FROM stdin;
\.


--
-- Data for Name: agent_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_jobs (id, agent_id, task_id, user_id, title, state, log, action, action_by, action_at, created_at, updated_at, kind, input, proposal, prop_state, applied, list_id, approval, name, parent_id) FROM stdin;
\.


--
-- Data for Name: agent_list_access; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_list_access (agent_id, list_id, day, kind, n) FROM stdin;
\.


--
-- Data for Name: agent_schedules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_schedules (id, agent_id, user_id, title, prompt, freq, days, at_time, tz, list_id, enabled, next_at, last_at, last_state, last_seq, created_at, updated_at, list_check) FROM stdin;
\.


--
-- Data for Name: agent_setup_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_setup_codes (id, agent_id, code_hash, os, folder, created_by, created_at, expires_at, used_at, token_id) FROM stdin;
\.


--
-- Data for Name: agent_steps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_steps (id, agent_id, user_id, job_id, message_id, state, text, created_at) FROM stdin;
\.


--
-- Data for Name: agent_usage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_usage (id, agent_id, model, input_tokens, output_tokens, cache_read_tokens, cache_write_tokens, cost_usd, task_id, list_id, job_id, note, day, created_at) FROM stdin;
\.


--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agents (user_id, enabled, note, status, status_text, status_at, webhook_id, created_at, status_task, usage_limits, usage_alerted, proposals, runtime, reset_seq, last_poll_at, typing_user, typing_until, owner_id, admin_paused, scopes, allowed_ips, provider, org_id, list_ids, host_info, quota, stale_sent, office_drafts) FROM stdin;
4	1		idle		\N	\N	2026-10-23T06:08:28+00:00	\N			shared		0	\N	\N	0	1	0	read,tasks:write			1					0
\.


--
-- Data for Name: api_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_tokens (id, user_id, name, token_hash, prefix, scopes, expires_at, created_at, last_used_at, allowed_ips, list_ids, host, folder, os) FROM stdin;
1	4	Agent	dca3beec26f5eaedcf091f2cae8b673c61a80d4e8d82ffc0789650062a188944	abk_EenQ8aaK	read,tasks:write	\N	2026-10-23T06:08:28+00:00	\N					
\.


--
-- Data for Name: app_passwords; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_passwords (id, user_id, name, pw_hash, created_at, last_used_at, last_client, caps) FROM stdin;
\.


--
-- Data for Name: appt_bookings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.appt_bookings (id, user_id, type_id, start, "end", name, email, phone, message, lang, status, confirm_hash, cancel_hash, ip, event_id, contact_id, deal_id, cancel_reason, cancelled_by, created_at, confirmed_at, cancelled_at) FROM stdin;
\.


--
-- Data for Name: appt_pages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.appt_pages (user_id, slug, enabled, title, intro, cal_id, office_org_id, hours, tz, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: appt_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.appt_types (id, user_id, name, duration_min, buffer_min, notice_h, days_ahead, location, note, active, sort, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: assistant_access; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.assistant_access (user_id, list_id, created_at) FROM stdin;
\.


--
-- Data for Name: assistant_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.assistant_log (id, user_id, kind, task_id, list_id, job_id, status, ms, chars_in, chars_out, model, at, day) FROM stdin;
\.


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attachments (id, task_id, name, mime, size, path, created_at, comment_id, user_id, enc, enc_by, e2e_gen) FROM stdin;
1	1	briefing.txt	text/plain	190	1/a783ff7397d8-briefing.txt	2026-10-23T06:08:28+00:00	\N	1	0	\N	0
\.


--
-- Data for Name: book_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.book_members (book_id, user_id, role, added_at) FROM stdin;
\.


--
-- Data for Name: bookmarks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bookmarks (id, user_id, org_id, url, url_key, title, description, site, image, image_mime, image_url, tags, note, state, text, preview, preview_error, fetched_at, src, src_id, kk_arch, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: books; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.books (id, owner_id, name, color, src_id, occ_list_id, created_at, changed_at, org_id, owner_org_id, org_role) FROM stdin;
\.


--
-- Data for Name: budget_cats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.budget_cats (id, list_id, name, kind, lim, sort, sid, created_at) FROM stdin;
\.


--
-- Data for Name: budget_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.budget_entries (id, list_id, day, amount, kind, title, note, counterpart, cat_id, recurring_id, rmonth, source, dkey, sid, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: budget_files; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.budget_files (id, entry_id, list_id, name, mime, size, path, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: budget_meta; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.budget_meta (list_id, mappings, updated_at) FROM stdin;
\.


--
-- Data for Name: budget_recurring; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.budget_recurring (id, list_id, title, amount, kind, cat_id, per, start, until, contract_task_id, sid, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cal_dav_res; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cal_dav_res (sub_id, uid, href, etag, rec) FROM stdin;
\.


--
-- Data for Name: cal_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cal_events (id, sub_id, uid, title, location, description, all_day, start, "end", d0, d1) FROM stdin;
\.


--
-- Data for Name: cal_subs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cal_subs (id, user_id, kind, name, color, visible, "interval", url, url_hint, username, password, etag, last_modified, ctag, status, error, fails, events, truncated, digest, tried_at, synced_at, fetched_at, changed_at, created_at, dav_write, dav_can_write) FROM stdin;
\.


--
-- Data for Name: chat_files; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_files (id, message_id, name, mime, size, path, created_at) FROM stdin;
\.


--
-- Data for Name: chat_reactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_reactions (message_id, user_id, emoji, created_at) FROM stdin;
\.


--
-- Data for Name: chat_saves; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_saves (user_id, kind, msg_id, task_id, created_at) FROM stdin;
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clients (id, org_id, name, icon, color, contact, email, phone, address, note, rate, budget_h, budget_amount, archived, created_by, created_at, updated_at, street, zip, city, country, vat_id, customer_no, buyer_reference, email_invoice, payment_terms_days, import_run_id, display_name, address_extra) FROM stdin;
1	1	Beispielkunde AG								\N	\N	\N	0	1	2026-10-23T06:08:28+00:00	2026-10-23T06:08:28+00:00	Marktstraße 5	50667	Köln	DE					\N	\N		
2	\N	Kleinkunde GbR								\N	\N	\N	0	3	2026-10-23T06:08:28+00:00	2026-10-23T06:08:28+00:00			Berlin	DE					\N	\N		
\.


--
-- Data for Name: comment_reactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.comment_reactions (comment_id, user_id, emoji, created_at) FROM stdin;
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.comments (id, task_id, user_id, body, mentions, created_at, edited_at, deleted_at, suggestion, reply_to, choices, choice, ext_name, portal, rule_name) FROM stdin;
1	1	1	Erste Fassung bis Freitag		2026-10-23T06:08:28.044+00:00	\N	\N	\N	\N	\N	\N	\N	0	\N
2	1	2	Ton kommt am Donnerstag		2026-10-23T06:08:28.053+00:00	\N	\N	\N	\N	\N	\N	\N	0	\N
3	8	3	Entwurf liegt bei		2026-10-23T06:08:28.096+00:00	\N	\N	\N	\N	\N	\N	\N	0	\N
\.


--
-- Data for Name: conn_blocks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conn_blocks (user_id, blocked_id, created_at) FROM stdin;
\.


--
-- Data for Name: conn_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conn_links (a_id, b_id, created_at, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: conn_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conn_requests (id, from_id, to_id, status, created_at, decided_at) FROM stdin;
\.


--
-- Data for Name: contact_care; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contact_care (user_id, contact_id, every_days, last, note, updated_at) FROM stdin;
\.


--
-- Data for Name: contact_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contact_links (src_id, uid, kind, task_id, digest, book) FROM stdin;
\.


--
-- Data for Name: contact_occ; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contact_occ (contact_id, kind, task_id, digest) FROM stdin;
\.


--
-- Data for Name: contact_srcs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contact_srcs (id, user_id, name, url, url_hint, username, password, list_id, lead, status, error, fails, count, tried_at, synced_at, created_at) FROM stdin;
\.


--
-- Data for Name: contact_tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contact_tasks (contact_id, task_id, kind, added_by, added_at) FROM stdin;
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contacts (id, book_id, uid, href, kind, fn, given, family, middle, prefix, suffix, nickname, org, dept, title, emails, phones, addresses, urls, bday, anniversary, note, groups, photo, version, extra, src_digest, search, created_by, created_at, updated_at, nl_status, nl_at, nl_source) FROM stdin;
\.


--
-- Data for Name: ctr_notices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ctr_notices (task_id, due, agent_id, user_id, list_id, sent_at) FROM stdin;
\.


--
-- Data for Name: dav_meta; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dav_meta (task_id, uid, href, parent_uid, extra) FROM stdin;
\.


--
-- Data for Name: dav_sync; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dav_sync (user_id, list_id, token, state, created_at) FROM stdin;
\.


--
-- Data for Name: dav_sync2; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dav_sync2 (user_id, coll, token, state, created_at) FROM stdin;
\.


--
-- Data for Name: disc_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.disc_profiles (user_id, email, confirmed_at, created_at) FROM stdin;
\.


--
-- Data for Name: disc_quota; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.disc_quota (user_id, day, searches, checked) FROM stdin;
\.


--
-- Data for Name: disc_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.disc_tokens (token_hash, user_id, email, expires_at) FROM stdin;
\.


--
-- Data for Name: dl_changes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dl_changes (id, ver, task_id, list_id, user_id) FROM stdin;
1	2	\N	\N	\N
2	3	\N	\N	\N
3	5	\N	\N	\N
4	6	\N	\N	\N
5	9	\N	\N	\N
6	10	\N	\N	\N
7	11	\N	\N	\N
8	12	1	4	\N
9	13	1	4	\N
10	14	2	4	\N
11	15	3	4	\N
12	16	4	4	\N
13	17	5	4	\N
14	18	5	4	\N
15	19	6	5	\N
16	20	7	5	\N
17	21	1	\N	\N
18	21	1	\N	1
19	22	1	\N	\N
20	22	1	\N	2
21	23	1	\N	\N
22	23	1	4	\N
23	24	\N	\N	\N
24	25	8	6	\N
25	26	8	\N	\N
26	26	8	\N	3
27	35	1	\N	\N
28	36	1	\N	\N
29	39	\N	\N	\N
30	40	\N	\N	\N
\.


--
-- Data for Name: doc_cfg; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.doc_cfg (ws, org_id, data, updated_at) FROM stdin;
\.


--
-- Data for Name: doc_mail; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.doc_mail (token, user_id, org_id, created_at) FROM stdin;
\.


--
-- Data for Name: doc_meta; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.doc_meta (node_id, org_id, ws, state, error, method, pages, tries, text, doc_date, due_date, amount, currency, sender_id, type_id, auto, suggest, trained, review, source, ext_id, thumb, version, task_id, created_by, created_at, updated_at, done_at, asn, taken_at) FROM stdin;
\.


--
-- Data for Name: doc_models; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.doc_models (id, org_id, ws, feature, data, updated_at) FROM stdin;
\.


--
-- Data for Name: doc_node_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.doc_node_tags (node_id, tag_id, auto) FROM stdin;
\.


--
-- Data for Name: doc_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.doc_rules (id, org_id, ws, pos, data, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: doc_senders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.doc_senders (id, org_id, ws, name, created_at) FROM stdin;
\.


--
-- Data for Name: doc_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.doc_tags (id, org_id, ws, name, created_at) FROM stdin;
\.


--
-- Data for Name: doc_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.doc_types (id, org_id, ws, name, created_at) FROM stdin;
\.


--
-- Data for Name: doc_words; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.doc_words (node_id, h) FROM stdin;
\.


--
-- Data for Name: e2e_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.e2e_keys (user_id, pub, bundle_pass, bundle_rec, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: env_deploys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.env_deploys (id, env_id, list_id, milestone_id, version, at, by_id, source) FROM stdin;
\.


--
-- Data for Name: ev_cal_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ev_cal_members (cal_id, user_id, role, hidden, added_at) FROM stdin;
\.


--
-- Data for Name: ev_cals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ev_cals (id, owner_id, name, color, description, sort, created_at, changed_at, org_id) FROM stdin;
\.


--
-- Data for Name: ev_reminded; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ev_reminded (event_id, user_id, k, at) FROM stdin;
\.


--
-- Data for Name: event_attendees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_attendees (id, event_id, user_id, contact_id, email, name, partstat, role) FROM stdin;
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.events (id, cal_id, uid, href, title, location, description, all_day, start, "end", tz, rrule, exdates, overrides, reminders, status, busy, url, task_id, extra, seq, created_by, created_at, updated_at, deleted_at, first_day, last_day) FROM stdin;
\.


--
-- Data for Name: file_text; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_text (id, kind, ref_id, att_id, list_file_id, node_id, org_id, ws, state, error, method, text, pages, truncated, tries, sha256, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: file_words; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_words (ft_id, h) FROM stdin;
\.


--
-- Data for Name: filters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.filters (id, name, rules, sort, created_at, user_id) FROM stdin;
\.


--
-- Data for Name: folder_agents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.folder_agents (owner_id, folder, agent_id, pos, listen, created_at) FROM stdin;
\.


--
-- Data for Name: folder_heads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.folder_heads (owner_id, folder, style, updated_at) FROM stdin;
\.


--
-- Data for Name: folder_notif; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.folder_notif (owner_id, folder, user_id, tpl, custom, updated_at) FROM stdin;
\.


--
-- Data for Name: folder_people; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.folder_people (owner_id, folder, user_id, role, created_at) FROM stdin;
\.


--
-- Data for Name: folder_props; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.folder_props (owner_id, folder, props, updated_at) FROM stdin;
\.


--
-- Data for Name: forms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.forms (id, list_id, token, token_hash, title, intro, access, section_id, ask_email, enabled, count, last_at, created_by, created_at, ttype, files, portal) FROM stdin;
\.


--
-- Data for Name: fs_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fs_log (id, node_id, user_id, agent, action, detail, at) FROM stdin;
\.


--
-- Data for Name: fs_nodes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fs_nodes (id, parent_id, kind, name, owner_id, org_id, agent_id, mime, size, cur_version, ref_kind, ref_id, org_access, created_by, created_at, updated_at, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: fs_shares; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fs_shares (id, node_id, user_id, group_id, agent_id, role, expires_at, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: fs_versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fs_versions (id, node_id, no, path, size, mime, sha256, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: git_closes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.git_closes (task_id, conn_id, kind, ref, undo, created_at, undone_at) FROM stdin;
\.


--
-- Data for Name: git_commits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.git_commits (conn_id, sha, message, author, url, branch, at) FROM stdin;
\.


--
-- Data for Name: git_conns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.git_conns (id, list_id, provider, base_url, owner, repo, token, hook_secret, default_branch, etags, polled_at, next_at, fails, last_error, created_by, created_at, tags_at) FROM stdin;
\.


--
-- Data for Name: git_folders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.git_folders (conn_id, owner_id, folder, created_at) FROM stdin;
\.


--
-- Data for Name: git_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.git_links (task_id, conn_id, kind, ref, created_at) FROM stdin;
\.


--
-- Data for Name: git_prs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.git_prs (conn_id, number, title, state, author, url, head_ref, head_sha, ci, ci_sha, updated_at, merged_at) FROM stdin;
\.


--
-- Data for Name: git_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.git_tags (conn_id, name, seen_at) FROM stdin;
\.


--
-- Data for Name: group_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.group_members (group_id, user_id, added_at) FROM stdin;
\.


--
-- Data for Name: group_shares; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.group_shares (id, group_id, list_id, owner_id, folder, role, added_by, added_at) FROM stdin;
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.groups (id, name, oidc_group, created_at, created_by, avatar) FROM stdin;
\.


--
-- Data for Name: habit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.habit_logs (habit_id, day, count, note) FROM stdin;
\.


--
-- Data for Name: habits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.habits (id, name, color, goal, days, remind_at, reminded_on, sort, archived, created_at, per_week, user_id) FROM stdin;
\.


--
-- Data for Name: hub_absences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hub_absences (id, org_id, user_id, kind, start_date, end_date, half_day, note, created_by, created_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: hub_bookings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hub_bookings (id, org_id, job, title, start, "end", resource_kind, resource_id, res_label, status, note, list_id, event_id, created_by, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: hub_mails; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hub_mails (id, org_id, owner_id, client_id, list_id, ws, message_id, from_addr, from_name, to_addrs, subject, sent_at, body, files, eml_id, note, folder_id, created_at, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: hub_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hub_tokens (token, kind, user_id, org_id, client_id, list_id, created_at) FROM stdin;
\.


--
-- Data for Name: hub_words; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hub_words (mail_id, h) FROM stdin;
\.


--
-- Data for Name: imports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.imports (id, user_id, source, file_name, created, report, created_at, undone_at) FROM stdin;
\.


--
-- Data for Name: issue_hooks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.issue_hooks (list_id, token_hash, created_by, created_at, last_at, received) FROM stdin;
\.


--
-- Data for Name: issue_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.issue_reports (list_id, fp, task_id, count, first_at, last_at) FROM stdin;
\.


--
-- Data for Name: journal; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.journal (user_id, day, text, mood, updated_at) FROM stdin;
\.


--
-- Data for Name: kalmido_meta; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kalmido_meta (key, value) FROM stdin;
fe_office_rules	1
schema_version	2
\.


--
-- Data for Name: kid_parents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kid_parents (kid_id, parent_id) FROM stdin;
\.


--
-- Data for Name: kid_pin_open; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kid_pin_open (token_hash, kid_id, until) FROM stdin;
\.


--
-- Data for Name: kid_pins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kid_pins (kid_id, pin_hash, fails, lock_until, set_by, set_at) FROM stdin;
\.


--
-- Data for Name: kid_rewards; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kid_rewards (id, kid_id, title, emoji, cost, once, state, requested_at, decided_by, decided_at, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: kid_stars; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kid_stars (id, kid_id, delta, kind, task_id, reward_id, title, by_id, at, created_at) FROM stdin;
\.


--
-- Data for Name: kk_conns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kk_conns (user_id, url, token, list_id, source, archive, synced_at, error, created_at) FROM stdin;
\.


--
-- Data for Name: list_activity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.list_activity (id, list_id, user_id, kind, data, created_at) FROM stdin;
\.


--
-- Data for Name: list_bell; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.list_bell (user_id, list_id, mode, custom) FROM stdin;
\.


--
-- Data for Name: list_envs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.list_envs (id, list_id, name, sort, token_hash, auto_close, created_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: list_fields; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.list_fields (id, list_id, name, type, options, pinned, sort, created_at) FROM stdin;
\.


--
-- Data for Name: list_files; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.list_files (id, list_id, name, mime, size, path, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: list_key_pending; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.list_key_pending (list_id, user_id, since) FROM stdin;
\.


--
-- Data for Name: list_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.list_keys (list_id, gen, user_id, wrapped, wrapped_by, wrapper_pub, created_at) FROM stdin;
\.


--
-- Data for Name: list_layouts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.list_layouts (list_id, user_id, layout, updated_at) FROM stdin;
\.


--
-- Data for Name: list_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.list_links (id, list_id, title, url, sort, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: list_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.list_members (list_id, user_id, role, folder, sort, view, added_at, id, own_role, grole) FROM stdin;
4	2	edit		1	\N	2026-10-23T06:08:27+00:00	1	edit	\N
4	4	edit		1	\N	2026-10-23T06:08:28+00:00	2	edit	\N
\.


--
-- Data for Name: list_milestones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.list_milestones (id, list_id, name, day, done, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: list_mine_hide; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.list_mine_hide (user_id, list_id, created_at) FROM stdin;
\.


--
-- Data for Name: list_notepads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.list_notepads (id, list_id, title, body, created_by, created_at, updated_by, updated_at, agent_id, agent_key) FROM stdin;
\.


--
-- Data for Name: list_notif; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.list_notif (list_id, user_id, tpl, custom, updated_at) FROM stdin;
\.


--
-- Data for Name: list_paperless; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.list_paperless (id, list_id, conn_id, doc_id, title, correspondent, created, added_by, added_at) FROM stdin;
\.


--
-- Data for Name: list_rule_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.list_rule_runs (rule_id, task_id, key, at) FROM stdin;
\.


--
-- Data for Name: list_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.list_rules (id, list_id, org_id, name, trig, trig_val, act, act_val, target_list_id, active, paused_reason, created_by, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: list_status; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.list_status (id, list_id, user_id, status, note, created_at) FROM stdin;
\.


--
-- Data for Name: list_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.list_tags (id, list_id, name, color, sort, created_at) FROM stdin;
\.


--
-- Data for Name: lists; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lists (id, name, color, folder, sort, view, is_inbox, archived, created_at, owner_id, rate, status, status_note, status_by, status_at, checklist, dep_shift, kind, archived_at, agent_tidy, icon, tickets, ticket_tpl, tidy_agent, nag, day_hours, description, agent_listen, col_cfg, ptype, family, life, trip, client_id, agent_members, agent_peers, sort_mode, org_id, folder_own, page_layout, page_style, git_folder_off, stale_days, agent_followup, done_in_section, time_tracking, tb_sums, fx_kpis, org_visibility, org_edit, tap_done, sprint_cfg, points_on, review_cfg, e2e, e2e_gen, e2e_rotate, e2e_by, e2e_at, e2e_reenc, header_style, header_file) FROM stdin;
1	Basket			-1	list	1	0	2026-10-23T06:08:27+00:00	1	\N			\N	\N	0	0	list	\N	off	\N	0		\N		\N		\N	\N					\N	0	0		\N	[]			0	\N	0	\N	0	\N	\N		0	0		0		\N	0	0	\N	\N	0		
2	Basket			-1	list	1	0	2026-10-23T06:08:27+00:00	2	\N			\N	\N	0	0	list	\N	off	\N	0		\N		\N		\N	\N					\N	0	0		\N	[]			0	\N	0	\N	0	\N	\N		0	0		0		\N	0	0	\N	\N	0		
3	Basket			-1	list	1	0	2026-10-23T06:08:27+00:00	3	\N			\N	\N	0	0	list	\N	off	\N	0		\N		\N		\N	\N					\N	0	0		\N	[]			0	\N	0	\N	0	\N	\N		0	0		0		\N	0	0	\N	\N	0		
4	Nordwind Projekte			1	list	0	0	2026-10-23T06:08:27+00:00	1	\N			\N	\N	0	1	project	\N	off	\N	0		\N		\N		\N	\N					\N	0	0		1	[]			0	\N	0	\N	1	\N	\N		0	0		0		\N	0	0	\N	\N	0		
5	Alice privat			2	list	0	0	2026-10-23T06:08:27+00:00	1	\N			\N	\N	0	0	list	\N	off	\N	0		\N		\N		\N	\N					\N	0	0		\N	[]			0	\N	0	\N	0	\N	\N		0	0		0		\N	0	0	\N	\N	0		
6	Frida Kunden			1	list	0	0	2026-10-23T06:08:28+00:00	3	\N			\N	\N	0	1	project	\N	off	\N	0		\N		\N		\N	\N					\N	0	0		\N	[]			0	\N	0	\N	1	\N	\N		0	0		0		\N	0	0	\N	\N	0		
7	Basket			-1	list	1	0	2026-10-23T06:08:28+00:00	4	\N			\N	\N	0	0	list	\N	off	\N	0		\N		\N		\N	\N					\N	0	0		\N	[]			0	\N	0	\N	0	\N	\N		0	0		0		\N	0	0	\N	\N	0		
\.


--
-- Data for Name: login_ips; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.login_ips (ip, user_id, at) FROM stdin;
172.17.0.1	1	2026-10-23T06:08:27+00:00
172.17.0.1	2	2026-10-23T06:08:27+00:00
172.17.0.1	3	2026-10-23T06:08:27+00:00
\.


--
-- Data for Name: mail_counts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mail_counts (k, day, n) FROM stdin;
\.


--
-- Data for Name: mail_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mail_tokens (token, user_id, list_id, created_at) FROM stdin;
\.


--
-- Data for Name: merge_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.merge_runs (id, kind, target_id, org_id, book_id, user_id, merged_ids, snapshot, summary, created_at, undone_at, undone_by) FROM stdin;
\.


--
-- Data for Name: msv_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.msv_links (id, user_id, name, short, color, base_url, token_enc, remote_me, default_inbox, "position", last_ok, last_err, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: nl_conns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nl_conns (id, org_id, owner_id, ws, kind, url, secret, hint, mode, auto, synced_at, error, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nl_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nl_members (seg_id, org_id, email, remote_ref, state, synced_at) FROM stdin;
\.


--
-- Data for Name: nl_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nl_runs (id, conn_id, org_id, kind, by_id, state, started_at, ended_at, counts, errors) FROM stdin;
\.


--
-- Data for Name: nl_segments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nl_segments (id, conn_id, org_id, name, rule, remote_id, remote_name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notes (id, list_id, title, body, tags, pinned, created_by, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, user_id, kind, task_id, list_id, actor_id, comment_id, data, created_at, read_at) FROM stdin;
1	2	share	\N	4	1	\N	{"name": "Nordwind Projekte", "role": "edit"}	2026-10-23T06:08:27.917+00:00	\N
2	1	comment	1	\N	2	2	{"reply": 1}	2026-10-23T06:08:28.058+00:00	\N
3	2	agentjoin	\N	4	1	\N	{"name": "Nordwind Projekte", "agent": "Nordwind Bot", "agent_id": 4, "provider": ""}	2026-10-23T06:08:28.326+00:00	\N
\.


--
-- Data for Name: office_agreements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_agreements (id, org_id, kind, name, provider, number, cost, per, vat_pct, start, ends, notice, notice_unit, renew_months, lead_days, doc_node_id, task_id, cashflow, note, archived, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: office_archive; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_archive (id, org_id, run_id, kind, number, project_no, project, client_id, client_name, date, amount, currency, paid, file_name, file, sha256, bytes, created_by, created_at, tax_lines, copy_of) FROM stdin;
\.


--
-- Data for Name: office_archive_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_archive_log (id, org_id, archive_id, at, user_id, field, old, new, role) FROM stdin;
\.


--
-- Data for Name: office_bank_imports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_bank_imports (id, org_id, filename, fmt, count, dup_count, created_by, created_at, undone_at) FROM stdin;
\.


--
-- Data for Name: office_bank_tx; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_bank_tx (id, org_id, import_id, day, amount, currency, counterpart, purpose, iban, ref, hash, match_kind, match_id, payment_id, matched_by, matched_at, created_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: office_client_contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_client_contacts (id, org_id, client_id, name, role, email, phone, is_default, sort, import_run_id, created_at, updated_at, contact_id) FROM stdin;
\.


--
-- Data for Name: office_company; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_company (org_id, name, street, zip, city, country, email, phone, tax_number, vat_id, iban, bic, bank_name, register_court, register_no, managing_directors, updated_at, md_label) FROM stdin;
1	Nordwind Studio GmbH	Hafenweg 1	20457	Hamburg	DE			12/345/67890		DE02120300000000202051	BYLADEM1001					2026-10-23T06:08:28+00:00	
\.


--
-- Data for Name: office_contracts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_contracts (id, org_id, name, client_id, date, raw_included, rights_time_id, rights_territory_id, rights_media_id, rights_note_de, rights_note_en, closing_de, closing_en, rates, note, archived, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: office_deals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_deals (id, org_id, title, client_id, contact, value, stage, probability, expected_date, offer_id, list_id, lost_reason, note, sort, created_by, created_at, updated_at, deleted_at, source, next_step, follow_up, email, phone, company, lead_client_id) FROM stdin;
\.


--
-- Data for Name: office_doc_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_doc_items (id, doc_id, sort, kind, service_id, title, detail, qty, unit, rate, tax, raw_fee, producing, intext, cost, discountable, org_id, tax_pct, net, tax_amount, cost_enc, part_id, ref_part_id, agent_flag) FROM stdin;
1	1	0	service	\N	Drehtag		2.0000	day	900.0000	standard	0	0	intern	0.0000	1	1	\N	\N	\N	\N	\N	\N	
2	1	1	service	\N	Schnitt		3.0000	day	650.0000	standard	0	0	intern	0.0000	1	1	\N	\N	\N	\N	\N	\N	
3	2	0	service	\N	Drehtag		2.0000	day	900.0000	standard	0	0	intern	0.0000	1	1	19	1800.00	342.00	\N	\N	\N	
4	2	1	service	\N	Schnitt		3.0000	day	650.0000	standard	0	0	intern	0.0000	1	1	19	1950.00	370.50	\N	\N	\N	
5	3	0	service	\N	Text		4.0000	day	120.0000	standard	0	0	intern	0.0000	1	2	\N	\N	\N	\N	\N	\N	
\.


--
-- Data for Name: office_doc_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_doc_log (id, org_id, doc_id, user_id, at, action, target, detail) FROM stdin;
1	1	\N	1	2026-10-23T06:08:28+00:00	update	company	{"before": {"name": "", "street": "", "zip": "", "city": "", "country": "", "tax_number": "", "iban": "", "bic": ""}, "after": {"name": "Nordwind Studio GmbH", "street": "Hafenweg 1", "zip": "20457", "city": "Hamburg", "country": "DE", "tax_number": "12/345/67890", "iban": "DE02120300000000202051", "bic": "BYLADEM1001"}}
2	1	1	1	2026-10-23T06:08:28+00:00	create	doc	{"number": "KVA-2026-001", "items": 0}
3	1	1	1	2026-10-23T06:08:28+00:00	items	doc	{"before": [], "after": [{"kind": "service", "service_id": null, "title": "Drehtag", "detail": "", "qty": 2.0, "unit": "day", "rate": 900.0, "tax": "standard", "raw_fee": 0, "producing": 0, "discountable": 1, "cost": 0.0}, {"kind": "service", "service_id": null, "title": "Schnitt", "detail": "", "qty": 3.0, "unit": "day", "rate": 650.0, "tax": "standard", "raw_fee": 0, "producing": 0, "discountable": 1, "cost": 0.0}]}
4	1	2	1	2026-10-23T06:08:28+00:00	create	doc	{"kind": "invoice", "from_id": 1, "from_number": "KVA-2026-001"}
5	1	2	1	2026-10-23T06:08:28+00:00	finalize	doc	{"number": "RE-2026-001", "net": "3750.00", "gross": "4462.50", "pack_version": "1", "logo_sha256": ""}
6	1	2	1	2026-10-23T06:08:28+00:00	store	doc	{"pdf_sha256": "ac5f0b8f8c13603a9dbd9c0f4dff9845ac5ff171e442b16e970b25eeadac803f", "xml_sha256": "1839c3e00b5bb9255aaa81eb16db1dcb80c70526e7321b4deb0f005b4125e44d", "format": "zugferd", "pdf_bytes": 440115, "xml_bytes": 6098}
7	2	3	3	2026-10-23T06:08:28+00:00	create	doc	{"number": "KVA-2026-001", "items": 0}
8	2	3	3	2026-10-23T06:08:28+00:00	items	doc	{"before": [], "after": [{"kind": "service", "service_id": null, "title": "Text", "detail": "", "qty": 4.0, "unit": "day", "rate": 120.0, "tax": "standard", "raw_fee": 0, "producing": 0, "discountable": 1, "cost": 0.0}]}
9	1	1	1	2026-10-23T06:08:28+00:00	open	doc	{}
10	1	2	1	2026-10-23T06:08:28+00:00	open	doc	{}
11	2	3	3	2026-10-23T06:08:28+00:00	open	doc	{}
\.


--
-- Data for Name: office_doc_parts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_doc_parts (id, org_id, doc_id, sort, kind, title, print, settings, sheet, totals, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: office_doc_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_doc_templates (id, org_id, kind, name, lang, body, sign, archived, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: office_docs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_docs (id, org_id, kind, number, status, lang, currency, fx_rate, vat_mode, client_id, recipient, project_title, project_ref, date, valid_until, contract_id, raw_mode, raw_factor, prod_quotient, producing_rate, discount_pct, intro, closing, rights, fields, totals, created_by, created_at, updated_at, sent_at, locked_at, locked_by, sender, recipient_snapshot, tax_snapshot, pack_version, service_from, service_to, order_ref, due_date, payment_days, cancels_id, ref_doc_ids, reminder_level, reminder_fee, reminder_deadline_days, paid_at, source_doc_id, einvoice_format, pdf_sha256, xml_sha256, datev_sent_at, vat_note, contact_id, reminder_fee_state, producing_on, agent_id, list_id, version_of, cashflow, series_id, series_period) FROM stdin;
1	1	offer	KVA-2026-001	draft	de	EUR	1.0900	vat	1	{"name": "Beispielkunde AG", "lines": ["Beispielkunde AG", "Marktstraße 5", "50667 Köln"], "street": "Marktstraße 5", "extra": "", "zip": "50667", "city": "Köln", "country": "DE"}	Imagefilm		2026-10-23	2026-11-22	\N	none	0.2500	3.0000	600.0000	0.0000	Sehr geehrte Damen und Herren,\nvielen Dank für Ihre Anfrage. Gerne unterbreiten wir Ihnen folgendes Angebot:	Wir freuen uns auf die Zusammenarbeit und stehen für Rückfragen gerne zur Verfügung.	{"time": {"id": null, "text": ""}, "territory": {"id": null, "text": ""}, "media": {"id": null, "text": ""}, "exceptions": "", "exclusive": 0, "note": "Im Übrigen gelten unsere AGB."}	[]	{"lang": "de", "currency": "EUR", "fx_rate": null, "fx_note": "", "vat_mode": "vat", "raw_mode": "none", "producing_on": 0, "items_net": 3750, "producing_qty": 0, "producing_days": 0, "producing_rate": 600, "producing_total": 0, "raw_base": 0, "raw_factor": 0.25, "raw_amount": 0, "discount_pct": 0, "discount": 0, "net": 3750, "tax_lines": [{"rate_key": "standard", "pct": 19, "base": 3750, "amount": 712.5, "label": "MwSt. 19 %"}], "tax_total": 712.5, "gross": 4462.5, "net_incl_raw": null, "net_excl_raw": null, "costs": 0, "margin": 3750, "vat_note": "Alle Preise zuzüglich 7 % bzw. 19 % MwSt.", "lines": [{"kind": "item", "pos": 1, "id": 1, "service_id": null, "title": "Drehtag", "detail": "", "qty": 2, "qty_text": "2", "unit": "day", "unit_text": "Tage", "rate": 900, "tax": "standard", "tax_pct": 19, "total": 1800, "raw_fee": 0, "producing": 0, "intext": "intern", "discountable": 1}, {"kind": "item", "pos": 2, "id": 2, "service_id": null, "title": "Schnitt", "detail": "", "qty": 3, "qty_text": "3", "unit": "day", "unit_text": "Tage", "rate": 650, "tax": "standard", "tax_pct": 19, "total": 1950, "raw_fee": 0, "producing": 0, "intext": "intern", "discountable": 1}], "labels": {"net": "Summe Netto", "net_incl_raw": "inklusive Rohdaten", "net_excl_raw": "ohne Rohdaten", "gross": "Summe Brutto", "producing": "Producing", "discount": "Rabatt"}}	1	2026-10-23T06:08:28+00:00	2026-10-23T06:08:28+00:00	\N	\N	\N	\N	\N	\N	\N	2026-02-01	2026-02-28	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N		0	\N	\N	\N	auto	\N	
3	2	offer	KVA-2026-001	draft	de	EUR	1.0900	vat	2	{"name": "Kleinkunde GbR", "lines": ["Kleinkunde GbR", "Berlin"], "street": "", "extra": "", "zip": "", "city": "Berlin", "country": "DE"}	Texte		2026-10-23	2026-11-22	\N	none	0.2500	3.0000	600.0000	0.0000	Sehr geehrte Damen und Herren,\nvielen Dank für Ihre Anfrage. Gerne unterbreiten wir Ihnen folgendes Angebot:	Wir freuen uns auf die Zusammenarbeit und stehen für Rückfragen gerne zur Verfügung.	{"time": {"id": null, "text": ""}, "territory": {"id": null, "text": ""}, "media": {"id": null, "text": ""}, "exceptions": "", "exclusive": 0, "note": "Im Übrigen gelten unsere AGB."}	[]	{"lang": "de", "currency": "EUR", "fx_rate": null, "fx_note": "", "vat_mode": "vat", "raw_mode": "none", "producing_on": 0, "items_net": 480, "producing_qty": 0, "producing_days": 0, "producing_rate": 600, "producing_total": 0, "raw_base": 0, "raw_factor": 0.25, "raw_amount": 0, "discount_pct": 0, "discount": 0, "net": 480, "tax_lines": [{"rate_key": "standard", "pct": 19, "base": 480, "amount": 91.2, "label": "MwSt. 19 %"}], "tax_total": 91.2, "gross": 571.2, "net_incl_raw": null, "net_excl_raw": null, "costs": 0, "margin": 480, "vat_note": "Alle Preise zuzüglich 7 % bzw. 19 % MwSt.", "lines": [{"kind": "item", "pos": 1, "id": 5, "service_id": null, "title": "Text", "detail": "", "qty": 4, "qty_text": "4", "unit": "day", "unit_text": "Tage", "rate": 120, "tax": "standard", "tax_pct": 19, "total": 480, "raw_fee": 0, "producing": 0, "intext": "intern", "discountable": 1}], "labels": {"net": "Summe Netto", "net_incl_raw": "inklusive Rohdaten", "net_excl_raw": "ohne Rohdaten", "gross": "Summe Brutto", "producing": "Producing", "discount": "Rabatt"}}	3	2026-10-23T06:08:28+00:00	2026-10-23T06:08:28+00:00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N		0	\N	\N	\N	auto	\N	
2	1	invoice	RE-2026-001	issued	de	EUR	1.0900	vat	1	{"name": "Beispielkunde AG", "lines": ["Beispielkunde AG", "Marktstraße 5", "50667 Köln"], "street": "Marktstraße 5", "extra": "", "zip": "50667", "city": "Köln", "country": "DE"}	Imagefilm		2026-10-23		\N	none	0.0000	3.0000	0.0000	0.0000	Sehr geehrte Damen und Herren,\nfür das oben genannte Projekt erlauben wir uns, Ihnen folgende Leistungen in Rechnung zu stellen:	Bitte überweisen Sie den Gesamtbetrag unter Angabe der Rechnungsnummer auf unser angegebenes Bankkonto. Es gelten unsere allgemeinen Geschäftsbedingungen.	{"time": {"id": null, "text": ""}, "territory": {"id": null, "text": ""}, "media": {"id": null, "text": ""}, "exceptions": "", "exclusive": 0, "note": "Im Übrigen gelten unsere AGB."}	[]	{"lang": "de", "currency": "EUR", "fx_rate": null, "fx_note": "", "vat_mode": "vat", "raw_mode": "none", "net": "3750.00", "net_text": "3.750,00 €", "tax_lines": [{"rate_key": "standard", "pct": "19", "base": "3750.00", "amount": "712.50", "base_text": "3.750,00 €", "amount_text": "712,50 €", "label": "MwSt. 19 %"}], "tax": "712.50", "tax_total": "712.50", "tax_text": "712,50 €", "gross": "4462.50", "gross_text": "4.462,50 €", "costs": "0.00", "margin": "3750.00", "items_net": "3750.00", "discount": "0.00", "raw_amount": "0.00", "producing_days": 0, "vat_note": "", "lines": [{"kind": "item", "pos": 1, "id": 3, "service_id": null, "title": "Drehtag", "detail": "", "qty": 2, "qty_text": "2", "unit": "day", "unit_text": "Tage", "rate": 900, "rate_text": "900,00 €", "tax": "standard", "tax_pct": 19, "total": 1800, "total_text": "1.800,00 €", "net": "1800.00", "intext": "intern"}, {"kind": "item", "pos": 2, "id": 4, "service_id": null, "title": "Schnitt", "detail": "", "qty": 3, "qty_text": "3", "unit": "day", "unit_text": "Tage", "rate": 650, "rate_text": "650,00 €", "tax": "standard", "tax_pct": 19, "total": 1950, "total_text": "1.950,00 €", "net": "1950.00", "intext": "intern"}], "labels": {"net": "Summe Netto", "gross": "Summe Brutto", "discount": "Rabatt"}}	1	2026-10-23T06:08:28+00:00	2026-10-23T06:08:28+00:00	\N	2026-10-23T06:08:28+00:00	1	{"company": {"name": "Nordwind Studio GmbH", "lines": ["Hafenweg 1", "20457 Hamburg"], "contact_lines": [], "register_lines": [], "bank_lines": ["IBAN DE02 1203 0000 0000 2020 51", "BIC BYLADEM1001", "Steuernummer 12/345/67890"], "sender_line": "Nordwind Studio GmbH · Hafenweg 1 · 20457 Hamburg"}, "fields": {"name": "Nordwind Studio GmbH", "street": "Hafenweg 1", "zip": "20457", "city": "Hamburg", "country": "DE", "email": "", "phone": "", "tax_number": "12/345/67890", "vat_id": "", "iban": "DE02120300000000202051", "bic": "BYLADEM1001", "bank_name": "", "register_court": "", "register_no": "", "managing_directors": "", "md_label": ""}, "color": "", "logo": "", "logo_sha256": "", "pack": "DE"}	{"name": "Beispielkunde AG", "lines": ["Beispielkunde AG", "Marktstraße 5", "50667 Köln"], "street": "Marktstraße 5", "zip": "50667", "city": "Köln", "country": "DE", "vat_id": "", "customer_no": "", "buyer_reference": "", "email_invoice": "", "payment_terms_days": null, "extra": "", "contact": null}	{"pack": "DE", "version": "1", "rates": {"standard": 19, "reduced": 7, "exempt": 0}, "tax": {"standard": 19, "reduced": 7, "exempt": 0, "labels": {"de": {"standard": "19 % MwSt.", "reduced": "7 % MwSt.", "exempt": "steuerfrei"}, "en": {"standard": "19 % VAT", "reduced": "7 % VAT", "exempt": "tax exempt"}}, "exempt_note": {"de": "Nicht im Inland steuerbar - Reverse-Charge-Verfahren (Steuerschuldnerschaft des Leistungsempfängers).", "en": "Not taxable in Germany - reverse-charge procedure (VAT to be accounted for by the recipient)."}}, "formats": {"date": "dd.mm.yyyy", "decimal": ",", "thousands": ".", "currency_pos": "after"}, "labels": {"de": {"offer": "Kostenvoranschlag", "offer_no": "Angebot Nr.", "invoice": "Rechnung", "invoice_no": "Rechnung Nr.", "project": "Projekttitel", "ref": "Ref./PO-Nr.", "client": "Kunde", "date": "Datum", "valid_until": "Gültig bis", "pos": "Pos.", "title": "Leistung", "qty": "Menge", "unit_price": "Preis", "vat": "MwSt.", "total": "Gesamt", "net_total": "Summe Netto", "gross_total": "Summe Brutto", "incl_raw": "inklusive Rohdaten", "excl_raw": "ohne Rohdaten", "raw_optional": "Optional: Bereitstellung der Rohdaten", "raw_included": "Bereitstellung der Rohdaten", "producing": "Producing", "discount": "Rabatt", "rights": "Rechteübertragung", "rights_time": "Zeitliche Auswertung", "rights_territory": "Räumliche Auswertung", "rights_media": "Mediale Auswertung", "rights_exceptions": "Ausnahmen", "rights_exclusive": "Exklusiv", "page_of": "Seite {x} von {y}", "signature": "Mit freundlichen Grüßen", "order": "Auftragserteilung", "order_hint": "Ort, Datum, Unterschrift", "units": {"day": "Tage", "hour": "Std.", "piece": "Stk.", "minute": "Min.", "flat": "pauschal"}, "units_one": {"day": "Tag", "hour": "Std.", "piece": "Stk.", "minute": "Min.", "flat": "pauschal"}, "unit_one": {"day": "Tag", "hour": "Std.", "piece": "Stk.", "minute": "Min.", "flat": "pauschal"}, "credit": "Gutschrift", "credit_no": "Gutschrift Nr.", "reminder_1": "Zahlungserinnerung", "reminder_2": "Mahnung", "reminder_3": "Letzte Mahnung", "reminder_no": "Mahnung Nr.", "to_invoice": "zu Rechnung Nr.", "customer_no": "Kunden-Nr.", "service_period": "Leistungszeitraum", "due": "Fällig am", "fx": "Wechselkurs 1 €", "subtotal": "Zwischensumme", "invoice_total": "Rechnungsbetrag", "reminder_total": "Gesamtbetrag", "credit_total": "Gutschriftsbetrag", "paid": "Bereits bezahlt", "open": "Offener Betrag", "open_total": "Offener Betrag", "reminder_fee": "Mahngebühr", "col_invoice": "Rechnung", "amount": "Betrag", "payment": "Zahlung", "col_due": "Fällig"}}, "texts": {"intro": {"de": "vielen Dank für Ihre Anfrage. Gerne unterbreiten wir Ihnen folgendes Angebot:"}, "salutation": {"de": "Sehr geehrte Damen und Herren,"}, "closing": {"de": "Wir freuen uns auf die Zusammenarbeit und stehen für Rückfragen gerne zur Verfügung."}, "vat_note": {"de": "Alle Preise zuzüglich 7 % bzw. 19 % MwSt."}, "vat_note_novat": {"de": "Alle Preise netto, ohne MwSt."}, "rights_note": {"de": "Im Übrigen gelten unsere AGB."}, "valid_note": {"de": "Dieses Angebot ist gültig bis {date}."}, "invoice_intro": {"de": "für das oben genannte Projekt erlauben wir uns, Ihnen folgende Leistungen in Rechnung zu stellen:"}, "invoice_closing": {"de": "Bitte überweisen Sie den Gesamtbetrag unter Angabe der Rechnungsnummer auf unser angegebenes Bankkonto. Es gelten unsere allgemeinen Geschäftsbedingungen."}, "credit_intro": {"de": "zu der unten genannten Rechnung erteilen wir Ihnen folgende Gutschrift:"}, "credit_closing": {"de": "Den Gutschriftsbetrag erstatten wir Ihnen oder verrechnen ihn mit offenen Rechnungen. Bei Fragen stehen wir Ihnen gerne zur Verfügung."}, "reminder_intro": {"de": "sicher ist Ihrer Aufmerksamkeit entgangen, dass folgende Rechnungen noch nicht beglichen sind:"}, "reminder_closing": {"de": "Wir bitten Sie darum, den kompletten Rechnungsbetrag innerhalb von {days} Werktagen auf unser oben genanntes Bankkonto zu überweisen."}, "reminder_intro_2": {"de": "leider konnten wir trotz unserer Zahlungserinnerung bis heute keinen Zahlungseingang für folgende Rechnungen feststellen:"}, "reminder_closing_2": {"de": "Wir bitten Sie, den offenen Gesamtbetrag innerhalb von {days} Werktagen auf unser oben genanntes Bankkonto zu überweisen. Sollten Sie die Zahlung inzwischen veranlasst haben, betrachten Sie dieses Schreiben bitte als gegenstandslos."}, "reminder_intro_3": {"de": "trotz unserer Zahlungserinnerung und Mahnung sind folgende Rechnungen weiterhin unbezahlt:"}, "reminder_closing_3": {"de": "Wir fordern Sie hiermit letztmalig auf, den offenen Gesamtbetrag innerhalb von {days} Werktagen auf unser oben genanntes Bankkonto zu überweisen. Geht die Zahlung bis dahin nicht ein, werden wir ohne weitere Ankündigung rechtliche Schritte einleiten; die dadurch entstehenden Kosten gehen zu Ihren Lasten."}, "payment_note": {"de": "Zahlbar bis {date} ohne Abzug."}, "fx_tax_note": {"de": "Steuerbetrag entspricht {tax} EUR, Kurs 1 EUR = {rate} USD"}, "vat_note_reverse": {"de": "Steuerschuldnerschaft des Leistungsempfängers (Reverse-Charge-Verfahren, § 13b UStG)."}, "vat_note_abroad": {"de": "Nicht im Inland steuerbar."}, "vat_note_small": {"de": "Gemäß § 19 UStG wird keine Umsatzsteuer berechnet."}}, "pack_sha256": "11aa38adbf87835e38a050a79019f90b378774eae95325f8a8191c9484f704d2", "pack_source": "builtin"}	1	2026-02-01	2026-02-28		2026-11-06	14	\N	\N	\N	\N	\N	\N	1	zugferd	ac5f0b8f8c13603a9dbd9c0f4dff9845ac5ff171e442b16e970b25eeadac803f	1839c3e00b5bb9255aaa81eb16db1dcb80c70526e7321b4deb0f005b4125e44d	\N		\N		\N	\N	\N	\N	auto	\N	
\.


--
-- Data for Name: office_drive_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_drive_log (id, org_id, drive_id, action, prev, by_user, at) FROM stdin;
\.


--
-- Data for Name: office_drives; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_drives (id, org_id, vehicle_id, user_id, day, start_place, dest, purpose, km, odo_start, odo_end, kind, client_id, project, trip_id, created_by, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: office_equipment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_equipment (id, org_id, name, category, daily_rate, name_en, archived, created_at, updated_at, import_run_id, purchase_date, purchase_net, new_value, current_value, serial_no, vendor, receipt_node_id, life_months, agreement_id) FROM stdin;
\.


--
-- Data for Name: office_fixed_costs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_fixed_costs (id, org_id, label, amount, start, until, repeat, created_by, created_at, updated_at, category, vat_rate, sub, notice_days, seats, low_use, remind_days, remind_user, url) FROM stdin;
\.


--
-- Data for Name: office_gen_docs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_gen_docs (id, org_id, template_id, kind, title, body, body_hash, client_id, list_id, doc_id, node_id, signed_node_id, status, archived, created_by, created_at, updated_at, sign, lang, final_at) FROM stdin;
\.


--
-- Data for Name: office_import_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_import_runs (id, org_id, kind, counts, detail, created_by, created_at, undone_at, undone_by) FROM stdin;
\.


--
-- Data for Name: office_inv_series; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_inv_series (id, org_id, template_id, title, every, start, until, next_date, auto_send, active, created_by, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: office_numbers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_numbers (org_id, kind, period, last) FROM stdin;
1	offer	2026	1
1	invoice	2026	1
2	offer	2026	1
\.


--
-- Data for Name: office_pack_installs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_pack_installs (id, org_id, kind, code, version, sha256, data, meta, badge, source, installed_at, installed_by, removed_at) FROM stdin;
\.


--
-- Data for Name: office_pay_props; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_pay_props (id, org_id, doc_id, agent_id, requested_by, date, amount, reference, confidence, note, state, payment_id, decided_by, decided_at, created_at) FROM stdin;
\.


--
-- Data for Name: office_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_payments (id, org_id, doc_id, date, amount, method, note, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: office_purchases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_purchases (id, org_id, doc_id, date, accepted_at, amount, currency, label, source, ref, created_at) FROM stdin;
\.


--
-- Data for Name: office_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_roles (id, org_id, kind, name_de, name_en, costs, rate_day, intext, markup_pct, sort, archived, import_run_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: office_services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_services (id, org_id, name_de, name_en, category, sort, unit, daily_rate, hourly_rate, raw_fee, producing, intext, role, tax, archived, created_at, updated_at, import_run_id, role_id) FROM stdin;
\.


--
-- Data for Name: office_sets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_sets (id, org_id, name, discount_pct, items, archived, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: office_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_settings (org_id, data, updated_at) FROM stdin;
1	{"pack": "DE", "company": {"name": "", "lines": [], "contact_lines": [], "register_lines": [], "bank_lines": []}, "logo": "", "color": "", "lang": "de", "currency": "EUR", "fx_usd": 1.09, "offer_scheme": "KVA-{yyyy}-{seq:03}", "prod_quotient": 3, "raw_factor": 0.25, "producing_service_id": null, "producing_rate": 600, "offer_valid_days": 30, "intro_text_id": {"de": null, "en": null}, "closing_text_id": {"de": null, "en": null}, "rights_default": {"time_id": null, "territory_id": null, "media_id": null}, "offer_number_at": "create", "invoice_scheme": "RE-{yyyy}-{seq:03}", "credit_scheme": "GS-{yyyy}-{seq:03}", "reminder_scheme": "MA-{yyyy}-{seq:03}", "payment_days": 14, "reminder_fee": 0, "reminder_deadline_days": 10, "einvoice_format": "zugferd", "datev_email": "", "datev_auto": 0, "invoice_closing_de": "", "invoice_closing_en": "", "reminder_text_de": "", "reminder_text_en": "", "producing_on": 0, "raw_on": 0, "small_business": 0, "industry_packs": [], "parts_invoice_mode": "full", "parts_summary_title_de": "Filmherstellung", "parts_summary_title_en": "Film production", "datev_extf": {}, "agents_read": 0, "cf_check": 0, "cf_check_user": null, "cf_check_task": null, "tax_reserve_pct": 0, "vat_basis": "ist", "tax_dates": {}, "km_rate": "0.30", "km_rates": {}}	2026-10-23T06:08:28+00:00
\.


--
-- Data for Name: office_signoffs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_signoffs (id, org_id, kind, doc_id, list_id, section_id, task_id, title, token_hash, token, expires_at, revoked_at, state, signer_name, signer_email, reason, signed_at, ip, user_agent, doc_hash, created_by, created_at, gen_doc_id, video_id) FROM stdin;
\.


--
-- Data for Name: office_sub_reminders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_sub_reminders (id, org_id, fixed_id, due, task_id, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: office_texts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_texts (id, org_id, kind, key, text_de, text_en, sort, archived) FROM stdin;
1	1	rights_time	unlimited	unbegrenzt	in perpetuity	0	0
2	1	rights_time	1y	1 Jahr ab Erstveröffentlichung	1 year from first publication	1	0
3	1	rights_time	2y	2 Jahre ab Erstveröffentlichung	2 years from first publication	2	0
4	1	rights_territory	world	weltweit	worldwide	0	0
5	1	rights_territory	dach	DACH	Germany, Austria, Switzerland	1	0
6	1	rights_territory	de	Deutschland	Germany	2	0
7	1	rights_territory	world_ex_music	weltweit außer Musik auf Messe/Event (DE)	worldwide except music on trade shows / live events (DE)	3	0
8	1	rights_media	internal	intern	internal use	0	0
9	1	rights_media	internal_web_unpaid	intern, web, unpaid media	internal use, web, unpaid media	1	0
10	1	rights_media	all	alle Medien	all media	2	0
11	1	rights_media	web_social_paid	web, social media, paid media	web, social media, paid media	3	0
12	1	intro	default	vielen Dank für Ihre Anfrage. Gerne unterbreiten wir Ihnen folgendes Angebot:	thank you for your enquiry. We are pleased to submit the following quotation:	0	0
13	1	closing	default	Wir freuen uns auf die Zusammenarbeit und stehen für Rückfragen gerne zur Verfügung.	We look forward to working with you and are happy to answer any questions.	0	0
14	1	note	rights_note	Im Übrigen gelten unsere AGB.	Our general terms and conditions apply.	0	0
15	2	rights_time	unlimited	unbegrenzt	in perpetuity	0	0
16	2	rights_time	1y	1 Jahr ab Erstveröffentlichung	1 year from first publication	1	0
17	2	rights_time	2y	2 Jahre ab Erstveröffentlichung	2 years from first publication	2	0
18	2	rights_territory	world	weltweit	worldwide	0	0
19	2	rights_territory	dach	DACH	Germany, Austria, Switzerland	1	0
20	2	rights_territory	de	Deutschland	Germany	2	0
21	2	rights_territory	world_ex_music	weltweit außer Musik auf Messe/Event (DE)	worldwide except music on trade shows / live events (DE)	3	0
22	2	rights_media	internal	intern	internal use	0	0
23	2	rights_media	internal_web_unpaid	intern, web, unpaid media	internal use, web, unpaid media	1	0
24	2	rights_media	all	alle Medien	all media	2	0
25	2	rights_media	web_social_paid	web, social media, paid media	web, social media, paid media	3	0
26	2	intro	default	vielen Dank für Ihre Anfrage. Gerne unterbreiten wir Ihnen folgendes Angebot:	thank you for your enquiry. We are pleased to submit the following quotation:	0	0
27	2	closing	default	Wir freuen uns auf die Zusammenarbeit und stehen für Rückfragen gerne zur Verfügung.	We look forward to working with you and are happy to answer any questions.	0	0
28	2	note	rights_note	Im Übrigen gelten unsere AGB.	Our general terms and conditions apply.	0	0
\.


--
-- Data for Name: office_trip_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_trip_items (id, org_id, trip_id, date, category, amount, currency, fx_rate, amount_home, text, datev, datev_no, billed_doc_id, billed_at, sort, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: office_trips; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_trips (id, org_id, date_from, date_to, dest, overnight, people, purpose, client_id, project, km, note, created_by, created_at, updated_at, country, place, t_start, t_end, vma_days, vma_off) FROM stdin;
\.


--
-- Data for Name: office_vehicles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_vehicles (id, org_id, name, plate, kind, odo_start, archived, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: org_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.org_keys (org_id, wrapped, kek_check, created_at, migrated_at, recovery_shown_at, wrapped_prev, kek_check_prev) FROM stdin;
\.


--
-- Data for Name: org_list_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.org_list_log (id, org_id, list_id, list_name, action, by_id, owner_id, to_id, created_at, detail) FROM stdin;
\.


--
-- Data for Name: org_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.org_members (org_id, user_id, role) FROM stdin;
1	1	admin
1	2	member
1	4	member
\.


--
-- Data for Name: orgs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orgs (id, name, icon, created_at, domains, personal_of, hub_holiday_state, color, photo_meta_strip) FROM stdin;
1	Nordwind Studio		2026-10-23T06:08:27+00:00		\N			1
2	private-3		2026-10-23T06:08:28+00:00		3			1
\.


--
-- Data for Name: paperless_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.paperless_links (id, task_id, doc_id, title, correspondent, created, status, message, ptask, att_id, added_at, conn_id, added_by) FROM stdin;
\.


--
-- Data for Name: pl_conn_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pl_conn_users (conn_id, user_id) FROM stdin;
\.


--
-- Data for Name: pl_conns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pl_conns (id, kind, owner_id, name, url, created_at) FROM stdin;
\.


--
-- Data for Name: pl_imported; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pl_imported (ws, src, pl_id, org_id, node_id, sha256, asn, dup, created_at) FROM stdin;
\.


--
-- Data for Name: pl_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pl_rules (ws, src, kind, pl_id, org_id, rule_id, created_at) FROM stdin;
\.


--
-- Data for Name: pl_sources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pl_sources (id, org_id, ws, url, token, mapping, follow, every_min, run_state, run_kind, run_by, run_total, run_done, run_new, run_skip, run_fail, run_beat, run_error, synced_at, error, created_by, created_at, updated_at, run_learn, run_ws) FROM stdin;
\.


--
-- Data for Name: pl_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pl_tokens (conn_id, user_id, token, updated_at) FROM stdin;
\.


--
-- Data for Name: pl_uploads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pl_uploads (id, org_id, ws, created_by, state, name, size, got, parts, chunk, info, mapping, error, run_state, run_by, run_total, run_done, run_new, run_skip, run_fail, run_beat, run_error, run_learn, created_at, updated_at, src, run_ws) FROM stdin;
\.


--
-- Data for Name: playbook_proposals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.playbook_proposals (id, list_id, agent_id, body, note, base_version, state, created_at, decided_by, decided_at) FROM stdin;
\.


--
-- Data for Name: playbooks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.playbooks (id, list_id, owner_id, folder, version, body, source, author_id, created_at) FROM stdin;
\.


--
-- Data for Name: pomos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pomos (id, task_id, kind, minutes, start, paused_at, paused_s, "end", done, notified, user_id) FROM stdin;
\.


--
-- Data for Name: portal_logins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.portal_logins (id, email_hash, org_id, owner_id, token_hash, created_at, expires_at, used_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: portal_tickets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.portal_tickets (id, task_id, list_id, org_id, owner_id, form_id, client_id, name, email, email_hash, token, token_hash, notify, created_at, last_seen_at, last_mail_at, mailed_status, lang) FROM stdin;
\.


--
-- Data for Name: public_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.public_links (id, list_id, token_hash, token, mode, notes, password_hash, pw_rev, expires_at, created_by, created_at, last_used_at, views, cv_show) FROM stdin;
\.


--
-- Data for Name: push_subs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.push_subs (id, user_id, endpoint, p256dh, auth, label, created_at, last_ok, fails, backoff_until, dismiss_at, dismiss_day, dismiss_n) FROM stdin;
\.


--
-- Data for Name: push_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.push_tags (sub_id, tag, sent_at, handled_at) FROM stdin;
\.


--
-- Data for Name: rc_receipts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rc_receipts (node_id, org_id, ws, list_id, category, set_by, set_at, vat_pct, paid_at) FROM stdin;
\.


--
-- Data for Name: rc_suggest; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rc_suggest (id, node_id, org_id, ws, agent_id, list_id, category, note, state, decided_by, decided_at, prev_list_id, prev_category, created_at) FROM stdin;
\.


--
-- Data for Name: recovery_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recovery_codes (id, user_id, code_hash, created_at, used_at) FROM stdin;
\.


--
-- Data for Name: rss_feeds; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rss_feeds (id, user_id, url, title, site_url, etag, last_modified, last_fetch, last_ok, last_error, fails, created_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: rss_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rss_items (id, feed_id, user_id, guid, url, title, summary, published, fetched_at, read_at, saved_task_id) FROM stdin;
\.


--
-- Data for Name: sample_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sample_items (user_id, kind, item_id) FROM stdin;
\.


--
-- Data for Name: sections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sections (id, list_id, name, sort, wip_limit) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (token_hash, user_id, created_at, expires_at, via) FROM stdin;
5070eb3e7b17a5bd49a6bb86ea26e233ecd2f05f417f36cbb7943bd3b6aa4c11	1	2026-10-23T06:08:27+00:00	2026-11-22T06:08:27+00:00	password
c2a0ae34fab1abb66d2c82310d8a991d9ac6074df58ff79057346556fc2426aa	1	2026-10-23T06:08:27+00:00	2026-11-22T06:08:27+00:00	password
6add0e3adc00da36a7815c64faea68c1697e2e98c799b230131d7e3045a3afec	2	2026-10-23T06:08:27+00:00	2026-11-22T06:08:27+00:00	password
2a955bb88b32e3bdfa823262025a71935d78b8365c0c19e9cb66eb4877757acb	3	2026-10-23T06:08:27+00:00	2026-11-22T06:08:27+00:00	password
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.settings (key, value) FROM stdin;
dl_floor	1
update_check	1
update_info	
ntfy_inbox_since	
aa_on	1
aa_topic	
aa_prio	4
aa_kinds	update,webpush,watchdog,integration,security,storage
aa_mode	instant
aa_digest_time	08:00
aa_cooldown_h	6
aa_max_hour	10
aa_disk_pct	5
aa_disk_mb	1024
aa_integ_min	15
aa_update_notified	
aa_digest_sent	
cal_allow_hosts	
twofa_required	0
passkey_login	1
storage_quota_mb	
storage_pool	user
support_email	
mail_day_limit	
announce	
signup_mode	off
signup_domains	
oidc_autocreate	0
bk_time	03:30
bk_keep_daily	14
bk_keep_weekly	8
bk_encrypt	0
bk_pass	
bk_last_ok	
bk_last_name	
bk_last_error	
bk_last_error_at	
public_links	1
org_encrypt	1
migr_att_user	1
migr_kind	1
migr_kind272	1
migr_time241	1
migr_feat8	1
migr_feat9	1
migr_feat10	1
migr_feat11	1
migr_orgs2220	1
migr_om2460	1
migr_ws2280	1
migr_ws2300	1
migr_listen2300	1
migr_folders2220	1
migr_folder931	1
migr_order988	1
migr_notiftpl2330	1
migr_scopes215	1
cal_secret	79c51d86f0572cf5f6c636a7bdef8a799835c28d9354954e20870f195b100318
auth_secret	85b876dffc3be9f2f3b45a92030886c99dcc8a2eeecf745fdab3dad1280d5076
undo_key	3962b3d3cbe03e38fe5e8849b69e38764f22c73c60480c3d5f070a67148d1f17
vapid_private	siGzvlQa8kUatjvGWfcXlxR3jDiDsBJi5UfuVyweMMo
migr_completed_by	1
migr_folder_path	1
migr_tidy_agent	1
migr_auditfix	1
msg_fts_v	2
migr_ev221	1
bk_on	1
bk_enabled_at	2026-10-23T06:08:27+00:00
bk_last_day	2026-10-23
tenant_check	{"day":"2026-10-23","at":"2026-10-23T06:08:27+00:00","n":0,"kinds":{},"sig":"","alerted":""}
collab_all	1
time_all	1
default_features	cal,habits,pomo,collab,stats,time,deps,fields
default_lang	en
setup_step2	done
docs_thumb_fill	{"done": 1}
user_agents	1
version:other	12
version	40
version:tasks	16
ts_backfill	{"done":["att","fs","list"]}
version:comments	3
version:office	8
\.


--
-- Data for Name: sev_known; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sev_known (kind, ref, at) FROM stdin;
admin	*	2026-10-23T06:08:27+00:00
org_admin	*	2026-10-23T06:08:27+00:00
agent	*	2026-10-23T06:08:27+00:00
agent_token	*	2026-10-23T06:08:27+00:00
admin	1	2026-10-23T06:08:28+00:00
agent	4	2026-10-23T06:08:28+00:00
agent_token	dca3beec26f5eaedcf091f2cae8b673c	2026-10-23T06:08:28+00:00
\.


--
-- Data for Name: sheet_cells; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sheet_cells (id, sheet_id, row_id, col_id, raw, name, frozen, frozen_value, updated_by, updated_at, agent_id, agent_batch) FROM stdin;
\.


--
-- Data for Name: sheet_changes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sheet_changes (id, sheet_id, batch, agent_id, cell_id, row_id, col_id, kind, old_raw, new_raw, created_at, undone_at) FROM stdin;
\.


--
-- Data for Name: sheet_columns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sheet_columns (id, sheet_id, pos, title, kind, options, color_mode, width, deleted_at) FROM stdin;
\.


--
-- Data for Name: sheet_lastvals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sheet_lastvals (cell_id, user_id, value, at) FROM stdin;
\.


--
-- Data for Name: sheet_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sheet_links (id, sheet_id, row_id, kind, target_id, list_id, batch, created_by, created_at, undone_at) FROM stdin;
\.


--
-- Data for Name: sheet_rows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sheet_rows (id, sheet_id, pos, deleted_at) FROM stdin;
\.


--
-- Data for Name: sheets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sheets (id, org_id, owner_id, title, list_id, created_by, created_at, updated_at, updated_by, deleted_at, agent_id, agent_batch, rev) FROM stdin;
\.


--
-- Data for Name: shop_memory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop_memory (list_id, item, section_id, at) FROM stdin;
\.


--
-- Data for Name: space_moves; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.space_moves (id, kind, obj_id, from_org, to_org, by_id, at, detail) FROM stdin;
\.


--
-- Data for Name: sprints; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sprints (id, list_id, num, name, start, end_day, goal, state, review, closed_at, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: task_bell; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.task_bell (task_id, user_id, org_id, level, until, set_by, created_at, updated_at, prev, act, act_by) FROM stdin;
\.


--
-- Data for Name: task_deps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.task_deps (task_id, blocker_id, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: task_enc_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.task_enc_notes (task_id, user_id, body, updated_at) FROM stdin;
\.


--
-- Data for Name: task_field_values; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.task_field_values (task_id, field_id, value) FROM stdin;
\.


--
-- Data for Name: task_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.task_links (task_id, list_id, section_id, sort, org_id, added_by, created_at) FROM stdin;
\.


--
-- Data for Name: task_list_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.task_list_tags (task_id, tag_id) FROM stdin;
\.


--
-- Data for Name: task_note_locks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.task_note_locks (task_id, user_id, body, updated_at) FROM stdin;
\.


--
-- Data for Name: task_people; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.task_people (task_id, user_id) FROM stdin;
\.


--
-- Data for Name: task_push; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.task_push (user_id, task_id, sent_at, pending, events, mentioned) FROM stdin;
1	1	1792735708.058896	0	0	0
\.


--
-- Data for Name: task_seen; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.task_seen (user_id, task_id, seen_id) FROM stdin;
1	1	1
2	1	2
3	8	3
\.


--
-- Data for Name: task_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.task_tags (task_id, user_id, tag) FROM stdin;
\.


--
-- Data for Name: task_vectors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.task_vectors (task_id, org_id, list_id, model, dim, vec, text_hash, updated_at) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tasks (id, list_id, section_id, parent_id, title, content, priority, status, due, due_time, reminders, reminded, repeat, repeat_from, sort, created_at, updated_at, completed_at, deleted_at, tt_id, pinned, start, duration, created_by, assignee_id, url, assigned_by, completed_by, waiting_at, wait_note, wait_until, wait_by, wait_fired, ttype, deadline, nag, nag_at, assignee_group_id, plan_start, ms, milestone_id, fam, rotation, stars, approval, approver_id, snippets, locked, sprint_id, sprint_at, points, reviewer_id, review, review_at, review_by, review_sec) FROM stdin;
2	4	\N	1	Rohschnitt		0	0	\N	\N				due	1	2026-10-23T06:08:27+00:00	2026-10-23T06:08:27+00:00	\N	\N	\N	0	\N	\N	1	\N	\N	\N	\N	\N		\N	\N			0			\N	\N	0	\N			\N		\N	\N	0	\N	\N	\N	\N		\N	\N	\N
3	4	\N	1	Farbkorrektur		0	0	\N	\N				due	2	2026-10-23T06:08:27+00:00	2026-10-23T06:08:27+00:00	\N	\N	\N	0	\N	\N	1	\N	\N	\N	\N	\N		\N	\N			0			\N	\N	0	\N			\N		\N	\N	0	\N	\N	\N	\N		\N	\N	\N
4	4	\N	\N	Musik lizenzieren		0	0	2026-04-01	\N				due	-2	2026-10-23T06:08:27+00:00	2026-10-23T06:08:27+00:00	\N	\N	\N	0	\N	\N	1	\N	\N	\N	\N	\N		\N	\N			0			\N	\N	0	\N			\N		\N	\N	0	\N	\N	\N	\N		\N	\N	\N
5	4	\N	\N	Angebot schicken		0	2	\N	\N				due	-3	2026-10-23T06:08:28+00:00	2026-10-23T06:08:28+00:00	2026-10-23T06:08:28+00:00	\N	\N	0	\N	\N	1	\N	\N	\N	1	\N		\N	\N			0			\N	\N	0	\N			\N		\N	\N	0	\N	\N	\N	\N		\N	\N	\N
6	5	\N	\N	Steuerunterlagen sortieren		0	0	\N	\N			FREQ=MONTHLY	due	-1	2026-10-23T06:08:28+00:00	2026-10-23T06:08:28+00:00	\N	\N	\N	0	\N	\N	1	\N	\N	\N	\N	\N		\N	\N			0			\N	\N	0	\N			\N		\N	\N	0	\N	\N	\N	\N		\N	\N	\N
7	5	\N	\N	Zahnarzt anrufen		0	0	\N	\N				due	-2	2026-10-23T06:08:28+00:00	2026-10-23T06:08:28+00:00	\N	\N	\N	0	\N	\N	1	\N	\N	\N	\N	\N		\N	\N			0			\N	\N	0	\N			\N		\N	\N	0	\N	\N	\N	\N		\N	\N	\N
1	4	\N	\N	Imagefilm schneiden		0	0	2026-03-04	18:30			FREQ=WEEKLY;BYDAY=MO	due	-1	2026-10-23T06:08:27+00:00	2026-10-23T06:08:28+00:00	\N	\N	\N	0	\N	\N	1	\N	\N	\N	\N	\N		\N	\N			0			\N	\N	0	\N			\N		\N	\N	0	\N	\N	\N	\N		\N	\N	\N
8	6	\N	\N	Website-Texte		0	0	2026-05-15	\N				due	-1	2026-10-23T06:08:28+00:00	2026-10-23T06:08:28+00:00	\N	\N	\N	0	\N	\N	3	\N	\N	\N	\N	\N		\N	\N			0			\N	\N	0	\N			\N		\N	\N	0	\N	\N	\N	\N		\N	\N	\N
\.


--
-- Data for Name: tchat_msgs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tchat_msgs (id, room_id, user_id, body, task_id, created_at, edited_at, deleted_at, reply_to, enc, client_id, pinned_at, pinned_by) FROM stdin;
\.


--
-- Data for Name: tchat_reads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tchat_reads (room_id, user_id, last_id, muted) FROM stdin;
\.


--
-- Data for Name: tchat_rooms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tchat_rooms (id, kind, list_id, a, b, created_at, last_at, e2e) FROM stdin;
\.


--
-- Data for Name: tchat_rx; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tchat_rx (message_id, user_id, emoji, created_at) FROM stdin;
\.


--
-- Data for Name: templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.templates (id, user_id, kind, name, data, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tidy_pending; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tidy_pending (task_id, actor_id, created_at, sent_at) FROM stdin;
\.


--
-- Data for Name: time_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.time_entries (id, user_id, task_id, list_id, task_title, start, "end", seconds, note, source, pomo_id, client_id, reminded, auto_stopped, created_at, updated_at) FROM stdin;
1	1	1	4	Imagefilm schneiden	2026-02-10T08:00:00+00:00	2026-02-10T09:30:00+00:00	5400	Sichtung	manual	\N	\N	0	0	2026-10-23T06:08:28+00:00	2026-10-23T06:08:28+00:00
2	2	1	4	Imagefilm schneiden	2026-02-11T09:00:00+00:00	2026-02-11T09:45:00+00:00	2700		manual	\N	\N	0	0	2026-10-23T06:08:28+00:00	2026-10-23T06:08:28+00:00
3	3	\N	6		2026-02-12T07:00:00+00:00	2026-02-12T07:30:00+00:00	1800		manual	\N	\N	0	0	2026-10-23T06:08:28+00:00	2026-10-23T06:08:28+00:00
\.


--
-- Data for Name: upload_scan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.upload_scan (id, kind, ref_id, ver, org_id, state, sig, why, tries, next_at, created_at, checked_at) FROM stdin;
\.


--
-- Data for Name: user_invites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_invites (user_id, token_hash, kind, created_by, created_at, expires_at, sent_at, used_at) FROM stdin;
\.


--
-- Data for Name: user_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_keys (user_id, wrapped, kek_check, created_at, migrated_at, wrapped_prev, kek_check_prev) FROM stdin;
\.


--
-- Data for Name: user_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_settings (user_id, key, value) FROM stdin;
1	allday_time	09:00
1	default_reminder	0
1	digest_time	
1	digest_sent	
1	digest_mail	0
1	digest_mail_sent	
1	mail_trim_fwd	0
1	mail_trim_eml	1
1	mail_from_me	0
1	dashboard	
1	view_today	
1	view_time	
1	view_agents	
1	view_projects	
1	view_review	
1	view_stats	
1	view_clients	
1	view_family	
1	sidebar	
1	work_start	09:00
1	work_end	17:00
1	review_time	
1	review_sent	
1	brief_time	
1	brief_sent	
1	brief_read	
1	care_sent	
1	today_inbox	0
1	pomo_focus	25
1	pomo_short	5
1	pomo_long	15
1	pomo_long_every	4
1	ntfy_topic	kalmido-b5x12lvefobs
1	push_priority	4
1	push_channel	webpush
1	wgstd_hide	{}
1	mods_all	1
1	show_done_new	1
1	show_done_default	0
1	group_order	{}
1	nav_order	tasks,cal,matrix,habits,pomo
1	folders	[]
1	folders_closed	[]
1	comment_order	old
1	detail_split	60
1	detail_cm_fold	0
1	agent_steps_live	1
1	agent_steps_always	0
1	agent_share	{}
1	features_rev	11
1	ical_scope	all
1	ical_alarms	1
1	time_rounding	0
1	time_remind_h	4
1	time_autostop_h	12
1	time_focus	1
1	time_currency	€
1	time_target	0
1	capacity_h	
1	hide_blocked_today	0
1	progress_subtasks	0
1	hide_progress	
1	show_progress	
1	fav_lists	
1	fav_only	0
1	fav_views	
1	fav_quiet	0
1	fav_suggest	1
1	fav_asked	
1	mine_view	own
1	date_confirm	0
1	quiet_from	22:00
1	quiet_to	07:00
1	agents_hidden	
1	roadmap	
1	evcals_hidden	[]
1	purpose	
1	celebrate	1
1	list_emoji	1
1	side_icons	line
1	prio_bg	
1	person_colors	1
1	list_color_dot	0
1	folder_colors	{}
1	side_progress	1
1	row_icons	key
1	row_icons_custom	
1	side_count	1
1	side_dots	1
1	side_share	1
1	cal_today	1
1	cal_tasks	1
1	cal_lists_hidden	[]
1	today_cals_hidden	[]
1	plan_cals_off	[]
1	onboard	done
1	sample_ask	1
1	news_kinds	mention,assign,comment,unblock,share,status
1	notify	
1	agent_push	0
1	tbl_accept	1
1	ws_colors	{}
1	fav_items	[]
1	photo_meta_strip	1
1	agent_comments	all
1	assistant_on	0
1	show_done_views	{"l:4":0,"l:5":0}
1	lang	en
1	features	cal,timeline,matrix,habits,pomo,kanban,collab,stats,time,progress,deps,fields,comments,events,contacts,files,docs,clients,office,workload,forms,wiki
1	tour	done
1	workspace	org:1
2	allday_time	09:00
2	default_reminder	0
2	digest_time	
2	digest_sent	
2	digest_mail	0
2	digest_mail_sent	
2	mail_trim_fwd	0
2	mail_trim_eml	1
2	mail_from_me	0
2	dashboard	
2	view_today	
2	view_time	
2	view_agents	
2	view_projects	
2	view_review	
2	view_stats	
2	view_clients	
2	view_family	
2	sidebar	{"order": [], "hidden": ["e:tomorrow", "e:week", "e:doable"]}
2	work_start	09:00
2	work_end	17:00
2	review_time	
2	review_sent	
2	brief_time	
2	brief_sent	
2	brief_read	
2	care_sent	
2	today_inbox	0
2	pomo_focus	25
2	pomo_short	5
2	pomo_long	15
2	pomo_long_every	4
2	ntfy_topic	kalmido-zeqj6e8ixh8y
2	push_priority	4
2	push_channel	webpush
2	show_done_views	{}
2	wgstd_hide	{}
2	mods_all	1
2	show_done_new	1
2	show_done_default	0
2	group_order	{}
2	nav_order	tasks,cal,matrix,habits,pomo
2	folders	[]
2	folders_closed	[]
2	comment_order	old
2	detail_split	60
2	detail_cm_fold	0
2	agent_steps_live	1
2	agent_steps_always	0
2	agent_share	{}
2	features_rev	11
2	ical_scope	all
2	ical_alarms	1
2	time_rounding	0
2	time_remind_h	4
2	time_autostop_h	12
2	time_focus	1
2	time_currency	€
2	time_target	0
2	capacity_h	
2	hide_blocked_today	0
2	progress_subtasks	0
2	hide_progress	
2	show_progress	
2	fav_lists	
2	fav_only	0
2	fav_views	
2	fav_quiet	0
2	fav_suggest	1
2	fav_asked	
2	mine_view	own
2	date_confirm	0
2	quiet_from	22:00
2	quiet_to	07:00
2	agents_hidden	
2	roadmap	
2	evcals_hidden	[]
2	purpose	
2	celebrate	1
2	list_emoji	1
2	side_icons	line
2	prio_bg	
2	person_colors	1
2	list_color_dot	0
2	folder_colors	{}
2	side_progress	1
2	row_icons	key
2	row_icons_custom	
2	side_count	1
2	side_dots	1
2	side_share	1
2	cal_today	1
2	cal_tasks	1
2	cal_lists_hidden	[]
2	today_cals_hidden	[]
2	plan_cals_off	[]
2	onboard	done
2	sample_ask	1
2	news_kinds	mention,assign,comment,unblock,share,status
2	notify	
2	workspace	all
2	agent_push	0
2	tbl_accept	1
2	ws_colors	{}
2	fav_items	[]
2	photo_meta_strip	1
2	agent_comments	all
2	assistant_on	0
3	lang	en
3	show_done_views	{"l:6":0}
3	allday_time	09:00
3	default_reminder	0
3	digest_time	
3	digest_sent	
3	digest_mail	0
3	digest_mail_sent	
3	mail_trim_fwd	0
3	mail_trim_eml	1
3	mail_from_me	0
3	dashboard	
3	view_today	
3	view_time	
3	view_agents	
3	view_projects	
3	view_review	
3	view_stats	
3	view_clients	
3	view_family	
3	sidebar	{"order": [], "hidden": ["e:tomorrow", "e:week", "e:doable"]}
3	work_start	09:00
3	work_end	17:00
3	review_time	
3	review_sent	
3	brief_time	
3	brief_sent	
3	brief_read	
3	care_sent	
3	today_inbox	0
3	pomo_focus	25
3	pomo_short	5
3	pomo_long	15
3	pomo_long_every	4
3	ntfy_topic	kalmido-vqn2r9rl4nl
3	push_priority	4
3	push_channel	webpush
3	wgstd_hide	{}
3	mods_all	1
3	show_done_new	1
3	show_done_default	0
3	group_order	{}
3	nav_order	tasks,cal,matrix,habits,pomo
3	folders	[]
3	folders_closed	[]
3	comment_order	old
3	detail_split	60
3	detail_cm_fold	0
3	agent_steps_live	1
3	agent_steps_always	0
3	agent_share	{}
3	features_rev	11
3	ical_scope	all
3	ical_alarms	1
3	time_rounding	0
3	time_remind_h	4
3	time_autostop_h	12
3	time_focus	1
3	time_currency	€
2	lang	en
2	tour	done
3	time_target	0
3	capacity_h	
3	hide_blocked_today	0
3	progress_subtasks	0
3	hide_progress	
3	show_progress	
3	fav_lists	
3	fav_only	0
3	fav_views	
3	fav_quiet	0
3	fav_suggest	1
3	fav_asked	
3	mine_view	own
3	date_confirm	0
3	quiet_from	22:00
3	quiet_to	07:00
3	agents_hidden	
3	roadmap	
3	evcals_hidden	[]
3	purpose	
3	celebrate	1
3	list_emoji	1
3	side_icons	line
3	prio_bg	
3	person_colors	1
3	list_color_dot	0
3	folder_colors	{}
3	side_progress	1
3	row_icons	key
3	row_icons_custom	
3	side_count	1
3	side_dots	1
3	side_share	1
3	cal_today	1
3	cal_tasks	1
3	cal_lists_hidden	[]
3	today_cals_hidden	[]
3	plan_cals_off	[]
3	onboard	done
3	sample_ask	1
3	news_kinds	mention,assign,comment,unblock,share,status
3	notify	
3	workspace	all
3	agent_push	0
3	tbl_accept	1
3	ws_colors	{}
3	fav_items	[]
3	photo_meta_strip	1
3	agent_comments	all
3	assistant_on	0
2	features	cal,timeline,matrix,habits,pomo,kanban,collab,stats,time,progress,deps,fields,comments,events,contacts,files,docs,clients,office,workload,forms,wiki
3	features	cal,timeline,matrix,habits,pomo,kanban,collab,stats,time,progress,deps,fields,comments,events,contacts,files,docs,clients,office,workload,forms,wiki
3	tour	done
4	allday_time	09:00
4	default_reminder	0
4	digest_time	
4	digest_sent	
4	digest_mail	0
4	digest_mail_sent	
4	mail_trim_fwd	0
4	mail_trim_eml	1
4	mail_from_me	0
4	dashboard	
4	view_today	
4	view_time	
4	view_agents	
4	view_projects	
4	view_review	
4	view_stats	
4	view_clients	
4	view_family	
4	sidebar	
4	work_start	09:00
4	work_end	17:00
4	review_time	
4	review_sent	
4	brief_time	
4	brief_sent	
4	brief_read	
4	care_sent	
4	today_inbox	0
4	pomo_focus	25
4	pomo_short	5
4	pomo_long	15
4	pomo_long_every	4
4	ntfy_topic	kalmido-absmtpmqvnr
4	push_priority	4
4	push_channel	webpush
4	show_done_views	{}
4	wgstd_hide	{}
4	mods_all	1
4	show_done_new	1
4	show_done_default	0
4	group_order	{}
4	features	cal,habits,pomo,collab,stats,time,deps,fields
4	nav_order	tasks,cal,matrix,habits,pomo
4	folders	[]
4	folders_closed	[]
4	comment_order	old
4	detail_split	60
4	detail_cm_fold	0
4	agent_steps_live	1
4	agent_steps_always	0
4	agent_share	{}
4	features_rev	11
4	ical_scope	all
4	ical_alarms	1
4	time_rounding	0
4	time_remind_h	4
4	time_autostop_h	12
4	time_focus	1
4	time_currency	€
4	time_target	0
4	capacity_h	
4	hide_blocked_today	0
4	progress_subtasks	0
4	hide_progress	
4	show_progress	
4	fav_lists	
4	fav_only	0
4	fav_views	
4	fav_quiet	0
4	fav_suggest	1
4	fav_asked	
4	mine_view	own
4	date_confirm	0
4	quiet_from	22:00
4	quiet_to	07:00
4	agents_hidden	
4	roadmap	
4	evcals_hidden	[]
4	purpose	
4	celebrate	1
4	list_emoji	1
4	side_icons	line
4	prio_bg	
4	person_colors	1
4	list_color_dot	0
4	folder_colors	{}
4	side_progress	1
4	lang	en
4	row_icons	key
4	row_icons_custom	
4	side_count	1
4	side_dots	1
4	side_share	1
4	cal_today	1
4	cal_tasks	1
4	cal_lists_hidden	[]
4	today_cals_hidden	[]
4	plan_cals_off	[]
4	tour	done
4	onboard	done
4	sample_ask	1
4	news_kinds	mention,assign,comment,unblock,share,status
4	notify	
4	workspace	all
4	agent_push	0
4	tbl_accept	1
4	ws_colors	{}
4	fav_items	[]
4	photo_meta_strip	1
4	agent_comments	all
4	assistant_on	0
\.


--
-- Data for Name: user_task_order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_task_order (user_id, task_id, pos) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, display_name, password_hash, proxy_login, is_admin, drop_token, created_at, disabled, ical_token, paperless_access, totp_secret, totp_step, webauthn_handle, oidc_subject, email, avatar, kind, kid, signup, storage_quota_mb, color) FROM stdin;
1	alice	Alice Admin	scrypt:32768:8:1$G8gj2k5zMjOw5K8T$495a94a41bd006961e8926f7dccdcd4ecfaec3cd402feeb5b6382ed2fbe9f85f85f7d773aeca3ec92c5908e405cbbd804e62b4cb8b3e5fbc7ec7730954d7017c	\N	1	CmtpQZ-Im9k3qt1ffJry43h8mjqbegPI	2026-10-23T06:08:27+00:00	0	\N	1	\N	0	\N	\N	\N	\N	user	0		\N	#3e63dd
4	nordbot	Nordwind Bot	\N	\N	0	_wPokVgbTSfVv-EUoBu37HWp2mlUI5U4	2026-10-23T06:08:28+00:00	0	\N	0	\N	0	\N	\N	\N	p:robot	agent	0		\N	#f76b15
2	bob	Bob Beispiel	scrypt:32768:8:1$jLn6u4U8ixtIClfI$824d5d418e4876f31d7d2439da51dad8289c68a064fa88f034ace61d60f1eb16440781da8584e36b7b4d358b4b6962f7c3c0766b2e4667230a68764817fd3d50	\N	0	B4W_cXVm83C602641QQ0dDySdxZmqr8b	2026-10-23T06:08:27+00:00	0	\N	0	\N	0	\N	\N	bob@example.com	\N	user	0		\N	#30a46c
3	frida	Frida Frei	scrypt:32768:8:1$w4iApburquzBLAq5$56665fb19ff78743532c986f9894ad64bd1058a478c222d00975491e8cf798a7618f7a2613d3ae4de986f45bf63e43688228bcf925480d4f4b05ad91b424dc28	\N	0	pHzj-faOSo8xYFCkmjqsBs9jBa2T_TkT	2026-10-23T06:08:27+00:00	0	\N	0	\N	0	\N	\N	frida@example.com	\N	user	0		\N	#3e63dd
\.


--
-- Data for Name: video_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.video_comments (id, review_id, version_id, org_id, parent_id, at_sec, body, author_id, ext_name, done, created_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: video_reviews; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.video_reviews (id, org_id, owner_id, task_id, list_id, client_id, title, state, created_by, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: video_versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.video_versions (id, review_id, org_id, n, url, provider, embed_id, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: view_layout_offers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.view_layout_offers (id, from_user, to_user, view_key, name, layout, state, created_at, decided_at) FROM stdin;
\.


--
-- Data for Name: view_layouts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.view_layouts (id, user_id, view_key, name, layout, pos, source, source_ref, created_at, updated_at, active) FROM stdin;
\.


--
-- Data for Name: wait_hidden; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wait_hidden (user_id, note_key, created_at) FROM stdin;
\.


--
-- Data for Name: webauthn_creds; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webauthn_creds (id, user_id, cred_id, public_key, sign_count, transports, name, rp_id, aaguid, backed_up, discoverable, created_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: webhook_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhook_log (id, webhook_id, delivery, event, attempt, ok, status, error, ms, created_at) FROM stdin;
\.


--
-- Data for Name: webhook_queue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhook_queue (id, webhook_id, delivery, event, payload, attempt, next_at, created_at) FROM stdin;
\.


--
-- Data for Name: webhooks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhooks (id, user_id, name, url, events, secret, enabled, disabled_reason, created_at, updated_at, agent) FROM stdin;
\.


--
-- Data for Name: wiki_key_pending; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wiki_key_pending (space_id, user_id, since) FROM stdin;
\.


--
-- Data for Name: wiki_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wiki_keys (space_id, gen, user_id, wrapped, wrapped_by, wrapper_pub, created_at) FROM stdin;
\.


--
-- Data for Name: wiki_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wiki_links (from_id, to_path, to_task, to_list) FROM stdin;
\.


--
-- Data for Name: wiki_pages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wiki_pages (id, org_id, owner_id, path, body, attrs, created_by, updated_by, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: wiki_spaces; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wiki_spaces (id, org_id, owner_id, e2e, e2e_gen, e2e_rotate, e2e_reenc, e2e_by, e2e_at) FROM stdin;
\.


--
-- Name: activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.activity_id_seq', 13, true);


--
-- Name: admin_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.admin_alerts_id_seq', 1, false);


--
-- Name: agent_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agent_audit_id_seq', 1, false);


--
-- Name: agent_chat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agent_chat_id_seq', 1, false);


--
-- Name: agent_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agent_events_id_seq', 1, false);


--
-- Name: agent_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agent_jobs_id_seq', 1, false);


--
-- Name: agent_schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agent_schedules_id_seq', 1, false);


--
-- Name: agent_setup_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agent_setup_codes_id_seq', 1, false);


--
-- Name: agent_steps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agent_steps_id_seq', 1, false);


--
-- Name: agent_usage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agent_usage_id_seq', 1, false);


--
-- Name: api_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.api_tokens_id_seq', 1, true);


--
-- Name: app_passwords_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.app_passwords_id_seq', 1, false);


--
-- Name: appt_bookings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.appt_bookings_id_seq', 1, false);


--
-- Name: appt_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.appt_types_id_seq', 1, false);


--
-- Name: assistant_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.assistant_log_id_seq', 1, false);


--
-- Name: attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attachments_id_seq', 1, true);


--
-- Name: bookmarks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bookmarks_id_seq', 1, false);


--
-- Name: books_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.books_id_seq', 1, false);


--
-- Name: budget_cats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.budget_cats_id_seq', 1, false);


--
-- Name: budget_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.budget_entries_id_seq', 1, false);


--
-- Name: budget_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.budget_files_id_seq', 1, false);


--
-- Name: budget_recurring_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.budget_recurring_id_seq', 1, false);


--
-- Name: cal_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cal_events_id_seq', 1, false);


--
-- Name: cal_subs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cal_subs_id_seq', 1, false);


--
-- Name: chat_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.chat_files_id_seq', 1, false);


--
-- Name: clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clients_id_seq', 2, true);


--
-- Name: comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.comments_id_seq', 3, true);


--
-- Name: conn_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.conn_requests_id_seq', 1, false);


--
-- Name: contact_srcs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contact_srcs_id_seq', 1, false);


--
-- Name: contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contacts_id_seq', 1, false);


--
-- Name: dl_changes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dl_changes_id_seq', 30, true);


--
-- Name: doc_models_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.doc_models_id_seq', 1, false);


--
-- Name: doc_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.doc_rules_id_seq', 1, false);


--
-- Name: doc_senders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.doc_senders_id_seq', 1, false);


--
-- Name: doc_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.doc_tags_id_seq', 1, false);


--
-- Name: doc_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.doc_types_id_seq', 1, false);


--
-- Name: env_deploys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.env_deploys_id_seq', 1, false);


--
-- Name: ev_cals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ev_cals_id_seq', 1, false);


--
-- Name: event_attendees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.event_attendees_id_seq', 1, false);


--
-- Name: events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.events_id_seq', 1, false);


--
-- Name: file_text_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.file_text_id_seq', 1, false);


--
-- Name: filters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.filters_id_seq', 1, false);


--
-- Name: forms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.forms_id_seq', 1, false);


--
-- Name: fs_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fs_log_id_seq', 1, false);


--
-- Name: fs_nodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fs_nodes_id_seq', 1, false);


--
-- Name: fs_shares_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fs_shares_id_seq', 1, false);


--
-- Name: fs_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fs_versions_id_seq', 1, false);


--
-- Name: git_conns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.git_conns_id_seq', 1, false);


--
-- Name: group_shares_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.group_shares_id_seq', 1, false);


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.groups_id_seq', 1, false);


--
-- Name: habits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.habits_id_seq', 1, false);


--
-- Name: hub_absences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hub_absences_id_seq', 1, false);


--
-- Name: hub_bookings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hub_bookings_id_seq', 1, false);


--
-- Name: hub_mails_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hub_mails_id_seq', 1, false);


--
-- Name: imports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.imports_id_seq', 1, false);


--
-- Name: kid_rewards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kid_rewards_id_seq', 1, false);


--
-- Name: kid_stars_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kid_stars_id_seq', 1, false);


--
-- Name: list_activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.list_activity_id_seq', 1, false);


--
-- Name: list_envs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.list_envs_id_seq', 1, false);


--
-- Name: list_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.list_fields_id_seq', 1, false);


--
-- Name: list_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.list_files_id_seq', 1, false);


--
-- Name: list_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.list_links_id_seq', 1, false);


--
-- Name: list_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.list_members_id_seq', 2, true);


--
-- Name: list_milestones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.list_milestones_id_seq', 1, false);


--
-- Name: list_notepads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.list_notepads_id_seq', 1, false);


--
-- Name: list_paperless_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.list_paperless_id_seq', 1, false);


--
-- Name: list_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.list_rules_id_seq', 1, false);


--
-- Name: list_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.list_status_id_seq', 1, false);


--
-- Name: list_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.list_tags_id_seq', 1, false);


--
-- Name: lists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.lists_id_seq', 7, true);


--
-- Name: merge_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.merge_runs_id_seq', 1, false);


--
-- Name: msv_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.msv_links_id_seq', 1, false);


--
-- Name: nl_conns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.nl_conns_id_seq', 1, false);


--
-- Name: nl_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.nl_runs_id_seq', 1, false);


--
-- Name: nl_segments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.nl_segments_id_seq', 1, false);


--
-- Name: notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notes_id_seq', 1, false);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notifications_id_seq', 3, true);


--
-- Name: office_agreements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_agreements_id_seq', 1, false);


--
-- Name: office_archive_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_archive_id_seq', 1, false);


--
-- Name: office_archive_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_archive_log_id_seq', 1, false);


--
-- Name: office_bank_imports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_bank_imports_id_seq', 1, false);


--
-- Name: office_bank_tx_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_bank_tx_id_seq', 1, false);


--
-- Name: office_client_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_client_contacts_id_seq', 1, false);


--
-- Name: office_contracts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_contracts_id_seq', 1, false);


--
-- Name: office_deals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_deals_id_seq', 1, false);


--
-- Name: office_doc_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_doc_items_id_seq', 5, true);


--
-- Name: office_doc_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_doc_log_id_seq', 11, true);


--
-- Name: office_doc_parts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_doc_parts_id_seq', 1, false);


--
-- Name: office_doc_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_doc_templates_id_seq', 1, false);


--
-- Name: office_docs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_docs_id_seq', 3, true);


--
-- Name: office_drive_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_drive_log_id_seq', 1, false);


--
-- Name: office_drives_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_drives_id_seq', 1, false);


--
-- Name: office_equipment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_equipment_id_seq', 1, false);


--
-- Name: office_fixed_costs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_fixed_costs_id_seq', 1, false);


--
-- Name: office_gen_docs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_gen_docs_id_seq', 1, false);


--
-- Name: office_import_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_import_runs_id_seq', 1, false);


--
-- Name: office_inv_series_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_inv_series_id_seq', 1, false);


--
-- Name: office_pack_installs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_pack_installs_id_seq', 1, false);


--
-- Name: office_pay_props_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_pay_props_id_seq', 1, false);


--
-- Name: office_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_payments_id_seq', 1, false);


--
-- Name: office_purchases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_purchases_id_seq', 1, false);


--
-- Name: office_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_roles_id_seq', 1, false);


--
-- Name: office_services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_services_id_seq', 1, false);


--
-- Name: office_sets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_sets_id_seq', 1, false);


--
-- Name: office_signoffs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_signoffs_id_seq', 1, false);


--
-- Name: office_sub_reminders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_sub_reminders_id_seq', 1, false);


--
-- Name: office_texts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_texts_id_seq', 28, true);


--
-- Name: office_trip_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_trip_items_id_seq', 1, false);


--
-- Name: office_trips_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_trips_id_seq', 1, false);


--
-- Name: office_vehicles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_vehicles_id_seq', 1, false);


--
-- Name: org_list_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.org_list_log_id_seq', 1, false);


--
-- Name: orgs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.orgs_id_seq', 2, true);


--
-- Name: paperless_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.paperless_links_id_seq', 1, false);


--
-- Name: pl_conns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pl_conns_id_seq', 1, false);


--
-- Name: pl_sources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pl_sources_id_seq', 1, false);


--
-- Name: pl_uploads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pl_uploads_id_seq', 1, false);


--
-- Name: playbook_proposals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.playbook_proposals_id_seq', 1, false);


--
-- Name: playbooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.playbooks_id_seq', 1, false);


--
-- Name: pomos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pomos_id_seq', 1, false);


--
-- Name: portal_logins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.portal_logins_id_seq', 1, false);


--
-- Name: portal_tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.portal_tickets_id_seq', 1, false);


--
-- Name: public_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.public_links_id_seq', 1, false);


--
-- Name: push_subs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.push_subs_id_seq', 1, false);


--
-- Name: rc_suggest_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rc_suggest_id_seq', 1, false);


--
-- Name: recovery_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.recovery_codes_id_seq', 1, false);


--
-- Name: rss_feeds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rss_feeds_id_seq', 1, false);


--
-- Name: rss_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rss_items_id_seq', 1, false);


--
-- Name: sections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sections_id_seq', 1, false);


--
-- Name: sheet_cells_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sheet_cells_id_seq', 1, false);


--
-- Name: sheet_changes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sheet_changes_id_seq', 1, false);


--
-- Name: sheet_columns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sheet_columns_id_seq', 1, false);


--
-- Name: sheet_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sheet_links_id_seq', 1, false);


--
-- Name: sheet_rows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sheet_rows_id_seq', 1, false);


--
-- Name: sheets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sheets_id_seq', 1, false);


--
-- Name: space_moves_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.space_moves_id_seq', 1, false);


--
-- Name: sprints_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sprints_id_seq', 1, false);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tasks_id_seq', 8, true);


--
-- Name: tchat_msgs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tchat_msgs_id_seq', 1, false);


--
-- Name: tchat_rooms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tchat_rooms_id_seq', 3, true);


--
-- Name: templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.templates_id_seq', 1, false);


--
-- Name: time_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.time_entries_id_seq', 3, true);


--
-- Name: upload_scan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.upload_scan_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: video_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.video_comments_id_seq', 1, false);


--
-- Name: video_reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.video_reviews_id_seq', 1, false);


--
-- Name: video_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.video_versions_id_seq', 1, false);


--
-- Name: view_layout_offers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.view_layout_offers_id_seq', 1, false);


--
-- Name: view_layouts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.view_layouts_id_seq', 1, false);


--
-- Name: webauthn_creds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.webauthn_creds_id_seq', 1, false);


--
-- Name: webhook_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.webhook_log_id_seq', 1, false);


--
-- Name: webhook_queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.webhook_queue_id_seq', 1, false);


--
-- Name: webhooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.webhooks_id_seq', 1, false);


--
-- Name: wiki_pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wiki_pages_id_seq', 1, false);


--
-- Name: wiki_spaces_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wiki_spaces_id_seq', 1, false);


--
-- Name: activity activity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity
    ADD CONSTRAINT activity_pkey PRIMARY KEY (id);


--
-- Name: admin_alerts admin_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_alerts
    ADD CONSTRAINT admin_alerts_pkey PRIMARY KEY (id);


--
-- Name: admin_login_ips admin_login_ips_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_login_ips
    ADD CONSTRAINT admin_login_ips_pkey PRIMARY KEY (user_id, ip_hash);


--
-- Name: agent_audit agent_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_audit
    ADD CONSTRAINT agent_audit_pkey PRIMARY KEY (id);


--
-- Name: agent_bridges agent_bridges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_bridges
    ADD CONSTRAINT agent_bridges_pkey PRIMARY KEY (agent_id, list_a, list_b);


--
-- Name: agent_chat agent_chat_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_chat
    ADD CONSTRAINT agent_chat_pkey PRIMARY KEY (id);


--
-- Name: agent_events agent_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_events
    ADD CONSTRAINT agent_events_pkey PRIMARY KEY (id);


--
-- Name: agent_jobs agent_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_jobs
    ADD CONSTRAINT agent_jobs_pkey PRIMARY KEY (id);


--
-- Name: agent_list_access agent_list_access_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_list_access
    ADD CONSTRAINT agent_list_access_pkey PRIMARY KEY (list_id, day, agent_id, kind);


--
-- Name: agent_schedules agent_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_schedules
    ADD CONSTRAINT agent_schedules_pkey PRIMARY KEY (id);


--
-- Name: agent_setup_codes agent_setup_codes_code_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_setup_codes
    ADD CONSTRAINT agent_setup_codes_code_hash_key UNIQUE (code_hash);


--
-- Name: agent_setup_codes agent_setup_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_setup_codes
    ADD CONSTRAINT agent_setup_codes_pkey PRIMARY KEY (id);


--
-- Name: agent_steps agent_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_steps
    ADD CONSTRAINT agent_steps_pkey PRIMARY KEY (id);


--
-- Name: agent_usage agent_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_usage
    ADD CONSTRAINT agent_usage_pkey PRIMARY KEY (id);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (user_id);


--
-- Name: api_tokens api_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_tokens
    ADD CONSTRAINT api_tokens_pkey PRIMARY KEY (id);


--
-- Name: api_tokens api_tokens_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_tokens
    ADD CONSTRAINT api_tokens_token_hash_key UNIQUE (token_hash);


--
-- Name: app_passwords app_passwords_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_passwords
    ADD CONSTRAINT app_passwords_pkey PRIMARY KEY (id);


--
-- Name: appt_bookings appt_bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appt_bookings
    ADD CONSTRAINT appt_bookings_pkey PRIMARY KEY (id);


--
-- Name: appt_pages appt_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appt_pages
    ADD CONSTRAINT appt_pages_pkey PRIMARY KEY (user_id);


--
-- Name: appt_pages appt_pages_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appt_pages
    ADD CONSTRAINT appt_pages_slug_key UNIQUE (slug);


--
-- Name: appt_types appt_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appt_types
    ADD CONSTRAINT appt_types_pkey PRIMARY KEY (id);


--
-- Name: assistant_access assistant_access_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_access
    ADD CONSTRAINT assistant_access_pkey PRIMARY KEY (user_id, list_id);


--
-- Name: assistant_log assistant_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_log
    ADD CONSTRAINT assistant_log_pkey PRIMARY KEY (id);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: book_members book_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.book_members
    ADD CONSTRAINT book_members_pkey PRIMARY KEY (book_id, user_id);


--
-- Name: bookmarks bookmarks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookmarks
    ADD CONSTRAINT bookmarks_pkey PRIMARY KEY (id);


--
-- Name: books books_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT books_pkey PRIMARY KEY (id);


--
-- Name: budget_cats budget_cats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_cats
    ADD CONSTRAINT budget_cats_pkey PRIMARY KEY (id);


--
-- Name: budget_entries budget_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_entries
    ADD CONSTRAINT budget_entries_pkey PRIMARY KEY (id);


--
-- Name: budget_files budget_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_files
    ADD CONSTRAINT budget_files_pkey PRIMARY KEY (id);


--
-- Name: budget_meta budget_meta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_meta
    ADD CONSTRAINT budget_meta_pkey PRIMARY KEY (list_id);


--
-- Name: budget_recurring budget_recurring_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_recurring
    ADD CONSTRAINT budget_recurring_pkey PRIMARY KEY (id);


--
-- Name: cal_dav_res cal_dav_res_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cal_dav_res
    ADD CONSTRAINT cal_dav_res_pkey PRIMARY KEY (sub_id, uid);


--
-- Name: cal_events cal_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cal_events
    ADD CONSTRAINT cal_events_pkey PRIMARY KEY (id);


--
-- Name: cal_subs cal_subs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cal_subs
    ADD CONSTRAINT cal_subs_pkey PRIMARY KEY (id);


--
-- Name: chat_files chat_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_files
    ADD CONSTRAINT chat_files_pkey PRIMARY KEY (id);


--
-- Name: chat_reactions chat_reactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_reactions
    ADD CONSTRAINT chat_reactions_pkey PRIMARY KEY (message_id, user_id, emoji);


--
-- Name: chat_saves chat_saves_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_saves
    ADD CONSTRAINT chat_saves_pkey PRIMARY KEY (user_id, kind, msg_id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: comment_reactions comment_reactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_reactions
    ADD CONSTRAINT comment_reactions_pkey PRIMARY KEY (comment_id, user_id, emoji);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: conn_blocks conn_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conn_blocks
    ADD CONSTRAINT conn_blocks_pkey PRIMARY KEY (user_id, blocked_id);


--
-- Name: conn_links conn_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conn_links
    ADD CONSTRAINT conn_links_pkey PRIMARY KEY (a_id, b_id);


--
-- Name: conn_requests conn_requests_from_id_to_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conn_requests
    ADD CONSTRAINT conn_requests_from_id_to_id_key UNIQUE (from_id, to_id);


--
-- Name: conn_requests conn_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conn_requests
    ADD CONSTRAINT conn_requests_pkey PRIMARY KEY (id);


--
-- Name: contact_care contact_care_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_care
    ADD CONSTRAINT contact_care_pkey PRIMARY KEY (user_id, contact_id);


--
-- Name: contact_links contact_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_links
    ADD CONSTRAINT contact_links_pkey PRIMARY KEY (src_id, uid, kind);


--
-- Name: contact_occ contact_occ_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_occ
    ADD CONSTRAINT contact_occ_pkey PRIMARY KEY (contact_id, kind);


--
-- Name: contact_srcs contact_srcs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_srcs
    ADD CONSTRAINT contact_srcs_pkey PRIMARY KEY (id);


--
-- Name: contact_tasks contact_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_tasks
    ADD CONSTRAINT contact_tasks_pkey PRIMARY KEY (contact_id, task_id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: ctr_notices ctr_notices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ctr_notices
    ADD CONSTRAINT ctr_notices_pkey PRIMARY KEY (task_id, due, agent_id);


--
-- Name: dav_meta dav_meta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dav_meta
    ADD CONSTRAINT dav_meta_pkey PRIMARY KEY (task_id);


--
-- Name: dav_sync2 dav_sync2_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dav_sync2
    ADD CONSTRAINT dav_sync2_pkey PRIMARY KEY (user_id, coll, token);


--
-- Name: dav_sync dav_sync_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dav_sync
    ADD CONSTRAINT dav_sync_pkey PRIMARY KEY (user_id, list_id, token);


--
-- Name: disc_profiles disc_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disc_profiles
    ADD CONSTRAINT disc_profiles_pkey PRIMARY KEY (user_id);


--
-- Name: disc_quota disc_quota_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disc_quota
    ADD CONSTRAINT disc_quota_pkey PRIMARY KEY (user_id, day);


--
-- Name: disc_tokens disc_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disc_tokens
    ADD CONSTRAINT disc_tokens_pkey PRIMARY KEY (token_hash);


--
-- Name: dl_changes dl_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dl_changes
    ADD CONSTRAINT dl_changes_pkey PRIMARY KEY (id);


--
-- Name: doc_cfg doc_cfg_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_cfg
    ADD CONSTRAINT doc_cfg_pkey PRIMARY KEY (ws);


--
-- Name: doc_mail doc_mail_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_mail
    ADD CONSTRAINT doc_mail_pkey PRIMARY KEY (token);


--
-- Name: doc_meta doc_meta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_meta
    ADD CONSTRAINT doc_meta_pkey PRIMARY KEY (node_id);


--
-- Name: doc_models doc_models_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_models
    ADD CONSTRAINT doc_models_pkey PRIMARY KEY (id);


--
-- Name: doc_models doc_models_ws_feature_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_models
    ADD CONSTRAINT doc_models_ws_feature_key UNIQUE (ws, feature);


--
-- Name: doc_node_tags doc_node_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_node_tags
    ADD CONSTRAINT doc_node_tags_pkey PRIMARY KEY (node_id, tag_id);


--
-- Name: doc_rules doc_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_rules
    ADD CONSTRAINT doc_rules_pkey PRIMARY KEY (id);


--
-- Name: doc_senders doc_senders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_senders
    ADD CONSTRAINT doc_senders_pkey PRIMARY KEY (id);


--
-- Name: doc_tags doc_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_tags
    ADD CONSTRAINT doc_tags_pkey PRIMARY KEY (id);


--
-- Name: doc_types doc_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_types
    ADD CONSTRAINT doc_types_pkey PRIMARY KEY (id);


--
-- Name: doc_words doc_words_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_words
    ADD CONSTRAINT doc_words_pkey PRIMARY KEY (node_id, h);


--
-- Name: e2e_keys e2e_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.e2e_keys
    ADD CONSTRAINT e2e_keys_pkey PRIMARY KEY (user_id);


--
-- Name: env_deploys env_deploys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.env_deploys
    ADD CONSTRAINT env_deploys_pkey PRIMARY KEY (id);


--
-- Name: ev_cal_members ev_cal_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ev_cal_members
    ADD CONSTRAINT ev_cal_members_pkey PRIMARY KEY (cal_id, user_id);


--
-- Name: ev_cals ev_cals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ev_cals
    ADD CONSTRAINT ev_cals_pkey PRIMARY KEY (id);


--
-- Name: ev_reminded ev_reminded_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ev_reminded
    ADD CONSTRAINT ev_reminded_pkey PRIMARY KEY (event_id, user_id, k);


--
-- Name: event_attendees event_attendees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_attendees
    ADD CONSTRAINT event_attendees_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: file_text file_text_kind_ref_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_text
    ADD CONSTRAINT file_text_kind_ref_id_key UNIQUE (kind, ref_id);


--
-- Name: file_text file_text_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_text
    ADD CONSTRAINT file_text_pkey PRIMARY KEY (id);


--
-- Name: file_words file_words_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_words
    ADD CONSTRAINT file_words_pkey PRIMARY KEY (ft_id, h);


--
-- Name: filters filters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filters
    ADD CONSTRAINT filters_pkey PRIMARY KEY (id);


--
-- Name: folder_agents folder_agents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folder_agents
    ADD CONSTRAINT folder_agents_pkey PRIMARY KEY (owner_id, folder, agent_id);


--
-- Name: folder_heads folder_heads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folder_heads
    ADD CONSTRAINT folder_heads_pkey PRIMARY KEY (owner_id, folder);


--
-- Name: folder_notif folder_notif_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folder_notif
    ADD CONSTRAINT folder_notif_pkey PRIMARY KEY (owner_id, folder, user_id);


--
-- Name: folder_people folder_people_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folder_people
    ADD CONSTRAINT folder_people_pkey PRIMARY KEY (owner_id, folder, user_id);


--
-- Name: folder_props folder_props_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folder_props
    ADD CONSTRAINT folder_props_pkey PRIMARY KEY (owner_id, folder);


--
-- Name: forms forms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forms
    ADD CONSTRAINT forms_pkey PRIMARY KEY (id);


--
-- Name: forms forms_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forms
    ADD CONSTRAINT forms_token_hash_key UNIQUE (token_hash);


--
-- Name: fs_log fs_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fs_log
    ADD CONSTRAINT fs_log_pkey PRIMARY KEY (id);


--
-- Name: fs_nodes fs_nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fs_nodes
    ADD CONSTRAINT fs_nodes_pkey PRIMARY KEY (id);


--
-- Name: fs_shares fs_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fs_shares
    ADD CONSTRAINT fs_shares_pkey PRIMARY KEY (id);


--
-- Name: fs_versions fs_versions_node_id_no_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fs_versions
    ADD CONSTRAINT fs_versions_node_id_no_key UNIQUE (node_id, no);


--
-- Name: fs_versions fs_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fs_versions
    ADD CONSTRAINT fs_versions_pkey PRIMARY KEY (id);


--
-- Name: git_closes git_closes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.git_closes
    ADD CONSTRAINT git_closes_pkey PRIMARY KEY (task_id);


--
-- Name: git_commits git_commits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.git_commits
    ADD CONSTRAINT git_commits_pkey PRIMARY KEY (conn_id, sha);


--
-- Name: git_conns git_conns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.git_conns
    ADD CONSTRAINT git_conns_pkey PRIMARY KEY (id);


--
-- Name: git_folders git_folders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.git_folders
    ADD CONSTRAINT git_folders_pkey PRIMARY KEY (conn_id);


--
-- Name: git_links git_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.git_links
    ADD CONSTRAINT git_links_pkey PRIMARY KEY (task_id, conn_id, kind, ref);


--
-- Name: git_prs git_prs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.git_prs
    ADD CONSTRAINT git_prs_pkey PRIMARY KEY (conn_id, number);


--
-- Name: git_tags git_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.git_tags
    ADD CONSTRAINT git_tags_pkey PRIMARY KEY (conn_id, name);


--
-- Name: group_members group_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_pkey PRIMARY KEY (group_id, user_id);


--
-- Name: group_shares group_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_shares
    ADD CONSTRAINT group_shares_pkey PRIMARY KEY (id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: habit_logs habit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.habit_logs
    ADD CONSTRAINT habit_logs_pkey PRIMARY KEY (habit_id, day);


--
-- Name: habits habits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.habits
    ADD CONSTRAINT habits_pkey PRIMARY KEY (id);


--
-- Name: hub_absences hub_absences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hub_absences
    ADD CONSTRAINT hub_absences_pkey PRIMARY KEY (id);


--
-- Name: hub_bookings hub_bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hub_bookings
    ADD CONSTRAINT hub_bookings_pkey PRIMARY KEY (id);


--
-- Name: hub_mails hub_mails_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hub_mails
    ADD CONSTRAINT hub_mails_pkey PRIMARY KEY (id);


--
-- Name: hub_tokens hub_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hub_tokens
    ADD CONSTRAINT hub_tokens_pkey PRIMARY KEY (token);


--
-- Name: hub_words hub_words_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hub_words
    ADD CONSTRAINT hub_words_pkey PRIMARY KEY (mail_id, h);


--
-- Name: imports imports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imports
    ADD CONSTRAINT imports_pkey PRIMARY KEY (id);


--
-- Name: issue_hooks issue_hooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_hooks
    ADD CONSTRAINT issue_hooks_pkey PRIMARY KEY (list_id);


--
-- Name: issue_reports issue_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_reports
    ADD CONSTRAINT issue_reports_pkey PRIMARY KEY (list_id, fp);


--
-- Name: journal journal_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal
    ADD CONSTRAINT journal_pkey PRIMARY KEY (user_id, day);


--
-- Name: kalmido_meta kalmido_meta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kalmido_meta
    ADD CONSTRAINT kalmido_meta_pkey PRIMARY KEY (key);


--
-- Name: kid_parents kid_parents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kid_parents
    ADD CONSTRAINT kid_parents_pkey PRIMARY KEY (kid_id, parent_id);


--
-- Name: kid_pin_open kid_pin_open_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kid_pin_open
    ADD CONSTRAINT kid_pin_open_pkey PRIMARY KEY (token_hash);


--
-- Name: kid_pins kid_pins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kid_pins
    ADD CONSTRAINT kid_pins_pkey PRIMARY KEY (kid_id);


--
-- Name: kid_rewards kid_rewards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kid_rewards
    ADD CONSTRAINT kid_rewards_pkey PRIMARY KEY (id);


--
-- Name: kid_stars kid_stars_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kid_stars
    ADD CONSTRAINT kid_stars_pkey PRIMARY KEY (id);


--
-- Name: kk_conns kk_conns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kk_conns
    ADD CONSTRAINT kk_conns_pkey PRIMARY KEY (user_id);


--
-- Name: list_activity list_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_activity
    ADD CONSTRAINT list_activity_pkey PRIMARY KEY (id);


--
-- Name: list_bell list_bell_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_bell
    ADD CONSTRAINT list_bell_pkey PRIMARY KEY (user_id, list_id);


--
-- Name: list_envs list_envs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_envs
    ADD CONSTRAINT list_envs_pkey PRIMARY KEY (id);


--
-- Name: list_fields list_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_fields
    ADD CONSTRAINT list_fields_pkey PRIMARY KEY (id);


--
-- Name: list_files list_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_files
    ADD CONSTRAINT list_files_pkey PRIMARY KEY (id);


--
-- Name: list_key_pending list_key_pending_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_key_pending
    ADD CONSTRAINT list_key_pending_pkey PRIMARY KEY (list_id, user_id);


--
-- Name: list_keys list_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_keys
    ADD CONSTRAINT list_keys_pkey PRIMARY KEY (list_id, gen, user_id);


--
-- Name: list_layouts list_layouts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_layouts
    ADD CONSTRAINT list_layouts_pkey PRIMARY KEY (list_id, user_id);


--
-- Name: list_links list_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_links
    ADD CONSTRAINT list_links_pkey PRIMARY KEY (id);


--
-- Name: list_members list_members_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_members
    ADD CONSTRAINT list_members_id_key UNIQUE (id);


--
-- Name: list_members list_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_members
    ADD CONSTRAINT list_members_pkey PRIMARY KEY (list_id, user_id);


--
-- Name: list_milestones list_milestones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_milestones
    ADD CONSTRAINT list_milestones_pkey PRIMARY KEY (id);


--
-- Name: list_mine_hide list_mine_hide_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_mine_hide
    ADD CONSTRAINT list_mine_hide_pkey PRIMARY KEY (user_id, list_id);


--
-- Name: list_notepads list_notepads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_notepads
    ADD CONSTRAINT list_notepads_pkey PRIMARY KEY (id);


--
-- Name: list_notif list_notif_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_notif
    ADD CONSTRAINT list_notif_pkey PRIMARY KEY (list_id, user_id);


--
-- Name: list_paperless list_paperless_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_paperless
    ADD CONSTRAINT list_paperless_pkey PRIMARY KEY (id);


--
-- Name: list_rule_runs list_rule_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_rule_runs
    ADD CONSTRAINT list_rule_runs_pkey PRIMARY KEY (rule_id, task_id, key);


--
-- Name: list_rules list_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_rules
    ADD CONSTRAINT list_rules_pkey PRIMARY KEY (id);


--
-- Name: list_status list_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_status
    ADD CONSTRAINT list_status_pkey PRIMARY KEY (id);


--
-- Name: list_tags list_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_tags
    ADD CONSTRAINT list_tags_pkey PRIMARY KEY (id);


--
-- Name: lists lists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lists
    ADD CONSTRAINT lists_pkey PRIMARY KEY (id);


--
-- Name: login_ips login_ips_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_ips
    ADD CONSTRAINT login_ips_pkey PRIMARY KEY (ip, user_id);


--
-- Name: mail_counts mail_counts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mail_counts
    ADD CONSTRAINT mail_counts_pkey PRIMARY KEY (k);


--
-- Name: mail_tokens mail_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mail_tokens
    ADD CONSTRAINT mail_tokens_pkey PRIMARY KEY (token);


--
-- Name: merge_runs merge_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.merge_runs
    ADD CONSTRAINT merge_runs_pkey PRIMARY KEY (id);


--
-- Name: msv_links msv_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.msv_links
    ADD CONSTRAINT msv_links_pkey PRIMARY KEY (id);


--
-- Name: nl_conns nl_conns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nl_conns
    ADD CONSTRAINT nl_conns_pkey PRIMARY KEY (id);


--
-- Name: nl_conns nl_conns_ws_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nl_conns
    ADD CONSTRAINT nl_conns_ws_key UNIQUE (ws);


--
-- Name: nl_members nl_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nl_members
    ADD CONSTRAINT nl_members_pkey PRIMARY KEY (seg_id, email);


--
-- Name: nl_runs nl_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nl_runs
    ADD CONSTRAINT nl_runs_pkey PRIMARY KEY (id);


--
-- Name: nl_segments nl_segments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nl_segments
    ADD CONSTRAINT nl_segments_pkey PRIMARY KEY (id);


--
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: office_agreements office_agreements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_agreements
    ADD CONSTRAINT office_agreements_pkey PRIMARY KEY (id);


--
-- Name: office_archive_log office_archive_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_archive_log
    ADD CONSTRAINT office_archive_log_pkey PRIMARY KEY (id);


--
-- Name: office_archive office_archive_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_archive
    ADD CONSTRAINT office_archive_pkey PRIMARY KEY (id);


--
-- Name: office_bank_imports office_bank_imports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_bank_imports
    ADD CONSTRAINT office_bank_imports_pkey PRIMARY KEY (id);


--
-- Name: office_bank_tx office_bank_tx_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_bank_tx
    ADD CONSTRAINT office_bank_tx_pkey PRIMARY KEY (id);


--
-- Name: office_client_contacts office_client_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_client_contacts
    ADD CONSTRAINT office_client_contacts_pkey PRIMARY KEY (id);


--
-- Name: office_company office_company_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_company
    ADD CONSTRAINT office_company_pkey PRIMARY KEY (org_id);


--
-- Name: office_contracts office_contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_contracts
    ADD CONSTRAINT office_contracts_pkey PRIMARY KEY (id);


--
-- Name: office_deals office_deals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_deals
    ADD CONSTRAINT office_deals_pkey PRIMARY KEY (id);


--
-- Name: office_doc_items office_doc_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_doc_items
    ADD CONSTRAINT office_doc_items_pkey PRIMARY KEY (id);


--
-- Name: office_doc_log office_doc_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_doc_log
    ADD CONSTRAINT office_doc_log_pkey PRIMARY KEY (id);


--
-- Name: office_doc_parts office_doc_parts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_doc_parts
    ADD CONSTRAINT office_doc_parts_pkey PRIMARY KEY (id);


--
-- Name: office_doc_templates office_doc_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_doc_templates
    ADD CONSTRAINT office_doc_templates_pkey PRIMARY KEY (id);


--
-- Name: office_docs office_docs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_docs
    ADD CONSTRAINT office_docs_pkey PRIMARY KEY (id);


--
-- Name: office_drive_log office_drive_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_drive_log
    ADD CONSTRAINT office_drive_log_pkey PRIMARY KEY (id);


--
-- Name: office_drives office_drives_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_drives
    ADD CONSTRAINT office_drives_pkey PRIMARY KEY (id);


--
-- Name: office_equipment office_equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_equipment
    ADD CONSTRAINT office_equipment_pkey PRIMARY KEY (id);


--
-- Name: office_fixed_costs office_fixed_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_fixed_costs
    ADD CONSTRAINT office_fixed_costs_pkey PRIMARY KEY (id);


--
-- Name: office_gen_docs office_gen_docs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_gen_docs
    ADD CONSTRAINT office_gen_docs_pkey PRIMARY KEY (id);


--
-- Name: office_import_runs office_import_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_import_runs
    ADD CONSTRAINT office_import_runs_pkey PRIMARY KEY (id);


--
-- Name: office_inv_series office_inv_series_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_inv_series
    ADD CONSTRAINT office_inv_series_pkey PRIMARY KEY (id);


--
-- Name: office_numbers office_numbers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_numbers
    ADD CONSTRAINT office_numbers_pkey PRIMARY KEY (org_id, kind, period);


--
-- Name: office_pack_installs office_pack_installs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_pack_installs
    ADD CONSTRAINT office_pack_installs_pkey PRIMARY KEY (id);


--
-- Name: office_pay_props office_pay_props_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_pay_props
    ADD CONSTRAINT office_pay_props_pkey PRIMARY KEY (id);


--
-- Name: office_payments office_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_payments
    ADD CONSTRAINT office_payments_pkey PRIMARY KEY (id);


--
-- Name: office_purchases office_purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_purchases
    ADD CONSTRAINT office_purchases_pkey PRIMARY KEY (id);


--
-- Name: office_roles office_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_roles
    ADD CONSTRAINT office_roles_pkey PRIMARY KEY (id);


--
-- Name: office_services office_services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_services
    ADD CONSTRAINT office_services_pkey PRIMARY KEY (id);


--
-- Name: office_sets office_sets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_sets
    ADD CONSTRAINT office_sets_pkey PRIMARY KEY (id);


--
-- Name: office_settings office_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_settings
    ADD CONSTRAINT office_settings_pkey PRIMARY KEY (org_id);


--
-- Name: office_signoffs office_signoffs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_signoffs
    ADD CONSTRAINT office_signoffs_pkey PRIMARY KEY (id);


--
-- Name: office_signoffs office_signoffs_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_signoffs
    ADD CONSTRAINT office_signoffs_token_hash_key UNIQUE (token_hash);


--
-- Name: office_sub_reminders office_sub_reminders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_sub_reminders
    ADD CONSTRAINT office_sub_reminders_pkey PRIMARY KEY (id);


--
-- Name: office_texts office_texts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_texts
    ADD CONSTRAINT office_texts_pkey PRIMARY KEY (id);


--
-- Name: office_trip_items office_trip_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_trip_items
    ADD CONSTRAINT office_trip_items_pkey PRIMARY KEY (id);


--
-- Name: office_trips office_trips_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_trips
    ADD CONSTRAINT office_trips_pkey PRIMARY KEY (id);


--
-- Name: office_vehicles office_vehicles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_vehicles
    ADD CONSTRAINT office_vehicles_pkey PRIMARY KEY (id);


--
-- Name: org_keys org_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_keys
    ADD CONSTRAINT org_keys_pkey PRIMARY KEY (org_id);


--
-- Name: org_list_log org_list_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_list_log
    ADD CONSTRAINT org_list_log_pkey PRIMARY KEY (id);


--
-- Name: org_members org_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_pkey PRIMARY KEY (org_id, user_id);


--
-- Name: orgs orgs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgs
    ADD CONSTRAINT orgs_pkey PRIMARY KEY (id);


--
-- Name: paperless_links paperless_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paperless_links
    ADD CONSTRAINT paperless_links_pkey PRIMARY KEY (id);


--
-- Name: pl_conn_users pl_conn_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pl_conn_users
    ADD CONSTRAINT pl_conn_users_pkey PRIMARY KEY (conn_id, user_id);


--
-- Name: pl_conns pl_conns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pl_conns
    ADD CONSTRAINT pl_conns_pkey PRIMARY KEY (id);


--
-- Name: pl_imported pl_imported_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pl_imported
    ADD CONSTRAINT pl_imported_pkey PRIMARY KEY (ws, src, pl_id);


--
-- Name: pl_rules pl_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pl_rules
    ADD CONSTRAINT pl_rules_pkey PRIMARY KEY (ws, src, kind, pl_id);


--
-- Name: pl_sources pl_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pl_sources
    ADD CONSTRAINT pl_sources_pkey PRIMARY KEY (id);


--
-- Name: pl_sources pl_sources_ws_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pl_sources
    ADD CONSTRAINT pl_sources_ws_key UNIQUE (ws);


--
-- Name: pl_tokens pl_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pl_tokens
    ADD CONSTRAINT pl_tokens_pkey PRIMARY KEY (conn_id, user_id);


--
-- Name: pl_uploads pl_uploads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pl_uploads
    ADD CONSTRAINT pl_uploads_pkey PRIMARY KEY (id);


--
-- Name: playbook_proposals playbook_proposals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playbook_proposals
    ADD CONSTRAINT playbook_proposals_pkey PRIMARY KEY (id);


--
-- Name: playbooks playbooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playbooks
    ADD CONSTRAINT playbooks_pkey PRIMARY KEY (id);


--
-- Name: pomos pomos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pomos
    ADD CONSTRAINT pomos_pkey PRIMARY KEY (id);


--
-- Name: portal_logins portal_logins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_logins
    ADD CONSTRAINT portal_logins_pkey PRIMARY KEY (id);


--
-- Name: portal_logins portal_logins_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_logins
    ADD CONSTRAINT portal_logins_token_hash_key UNIQUE (token_hash);


--
-- Name: portal_tickets portal_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_tickets
    ADD CONSTRAINT portal_tickets_pkey PRIMARY KEY (id);


--
-- Name: portal_tickets portal_tickets_task_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_tickets
    ADD CONSTRAINT portal_tickets_task_id_key UNIQUE (task_id);


--
-- Name: portal_tickets portal_tickets_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_tickets
    ADD CONSTRAINT portal_tickets_token_hash_key UNIQUE (token_hash);


--
-- Name: public_links public_links_list_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.public_links
    ADD CONSTRAINT public_links_list_id_key UNIQUE (list_id);


--
-- Name: public_links public_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.public_links
    ADD CONSTRAINT public_links_pkey PRIMARY KEY (id);


--
-- Name: public_links public_links_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.public_links
    ADD CONSTRAINT public_links_token_hash_key UNIQUE (token_hash);


--
-- Name: push_subs push_subs_endpoint_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subs
    ADD CONSTRAINT push_subs_endpoint_key UNIQUE (endpoint);


--
-- Name: push_subs push_subs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subs
    ADD CONSTRAINT push_subs_pkey PRIMARY KEY (id);


--
-- Name: push_tags push_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_tags
    ADD CONSTRAINT push_tags_pkey PRIMARY KEY (sub_id, tag);


--
-- Name: rc_receipts rc_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rc_receipts
    ADD CONSTRAINT rc_receipts_pkey PRIMARY KEY (node_id);


--
-- Name: rc_suggest rc_suggest_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rc_suggest
    ADD CONSTRAINT rc_suggest_pkey PRIMARY KEY (id);


--
-- Name: recovery_codes recovery_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recovery_codes
    ADD CONSTRAINT recovery_codes_pkey PRIMARY KEY (id);


--
-- Name: rss_feeds rss_feeds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rss_feeds
    ADD CONSTRAINT rss_feeds_pkey PRIMARY KEY (id);


--
-- Name: rss_items rss_items_feed_id_guid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rss_items
    ADD CONSTRAINT rss_items_feed_id_guid_key UNIQUE (feed_id, guid);


--
-- Name: rss_items rss_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rss_items
    ADD CONSTRAINT rss_items_pkey PRIMARY KEY (id);


--
-- Name: sample_items sample_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sample_items
    ADD CONSTRAINT sample_items_pkey PRIMARY KEY (kind, item_id);


--
-- Name: sections sections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sections
    ADD CONSTRAINT sections_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (token_hash);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (key);


--
-- Name: sev_known sev_known_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sev_known
    ADD CONSTRAINT sev_known_pkey PRIMARY KEY (kind, ref);


--
-- Name: sheet_cells sheet_cells_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheet_cells
    ADD CONSTRAINT sheet_cells_pkey PRIMARY KEY (id);


--
-- Name: sheet_cells sheet_cells_row_id_col_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheet_cells
    ADD CONSTRAINT sheet_cells_row_id_col_id_key UNIQUE (row_id, col_id);


--
-- Name: sheet_changes sheet_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheet_changes
    ADD CONSTRAINT sheet_changes_pkey PRIMARY KEY (id);


--
-- Name: sheet_columns sheet_columns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheet_columns
    ADD CONSTRAINT sheet_columns_pkey PRIMARY KEY (id);


--
-- Name: sheet_lastvals sheet_lastvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheet_lastvals
    ADD CONSTRAINT sheet_lastvals_pkey PRIMARY KEY (cell_id, user_id);


--
-- Name: sheet_links sheet_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheet_links
    ADD CONSTRAINT sheet_links_pkey PRIMARY KEY (id);


--
-- Name: sheet_rows sheet_rows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheet_rows
    ADD CONSTRAINT sheet_rows_pkey PRIMARY KEY (id);


--
-- Name: sheets sheets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheets
    ADD CONSTRAINT sheets_pkey PRIMARY KEY (id);


--
-- Name: shop_memory shop_memory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_memory
    ADD CONSTRAINT shop_memory_pkey PRIMARY KEY (list_id, item);


--
-- Name: space_moves space_moves_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.space_moves
    ADD CONSTRAINT space_moves_pkey PRIMARY KEY (id);


--
-- Name: sprints sprints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sprints
    ADD CONSTRAINT sprints_pkey PRIMARY KEY (id);


--
-- Name: task_bell task_bell_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_bell
    ADD CONSTRAINT task_bell_pkey PRIMARY KEY (task_id, user_id);


--
-- Name: task_deps task_deps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_deps
    ADD CONSTRAINT task_deps_pkey PRIMARY KEY (task_id, blocker_id);


--
-- Name: task_enc_notes task_enc_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_enc_notes
    ADD CONSTRAINT task_enc_notes_pkey PRIMARY KEY (task_id, user_id);


--
-- Name: task_field_values task_field_values_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_field_values
    ADD CONSTRAINT task_field_values_pkey PRIMARY KEY (task_id, field_id);


--
-- Name: task_links task_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_links
    ADD CONSTRAINT task_links_pkey PRIMARY KEY (task_id, list_id);


--
-- Name: task_list_tags task_list_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_list_tags
    ADD CONSTRAINT task_list_tags_pkey PRIMARY KEY (task_id, tag_id);


--
-- Name: task_note_locks task_note_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_note_locks
    ADD CONSTRAINT task_note_locks_pkey PRIMARY KEY (task_id);


--
-- Name: task_people task_people_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_people
    ADD CONSTRAINT task_people_pkey PRIMARY KEY (task_id, user_id);


--
-- Name: task_push task_push_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_push
    ADD CONSTRAINT task_push_pkey PRIMARY KEY (user_id, task_id);


--
-- Name: task_seen task_seen_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_seen
    ADD CONSTRAINT task_seen_pkey PRIMARY KEY (user_id, task_id);


--
-- Name: task_tags task_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_tags
    ADD CONSTRAINT task_tags_pkey PRIMARY KEY (task_id, user_id, tag);


--
-- Name: task_vectors task_vectors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_vectors
    ADD CONSTRAINT task_vectors_pkey PRIMARY KEY (task_id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: tchat_msgs tchat_msgs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tchat_msgs
    ADD CONSTRAINT tchat_msgs_pkey PRIMARY KEY (id);


--
-- Name: tchat_reads tchat_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tchat_reads
    ADD CONSTRAINT tchat_reads_pkey PRIMARY KEY (room_id, user_id);


--
-- Name: tchat_rooms tchat_rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tchat_rooms
    ADD CONSTRAINT tchat_rooms_pkey PRIMARY KEY (id);


--
-- Name: tchat_rx tchat_rx_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tchat_rx
    ADD CONSTRAINT tchat_rx_pkey PRIMARY KEY (message_id, user_id, emoji);


--
-- Name: templates templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT templates_pkey PRIMARY KEY (id);


--
-- Name: tidy_pending tidy_pending_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tidy_pending
    ADD CONSTRAINT tidy_pending_pkey PRIMARY KEY (task_id);


--
-- Name: time_entries time_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_pkey PRIMARY KEY (id);


--
-- Name: upload_scan upload_scan_kind_ref_id_ver_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.upload_scan
    ADD CONSTRAINT upload_scan_kind_ref_id_ver_key UNIQUE (kind, ref_id, ver);


--
-- Name: upload_scan upload_scan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.upload_scan
    ADD CONSTRAINT upload_scan_pkey PRIMARY KEY (id);


--
-- Name: user_invites user_invites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_invites
    ADD CONSTRAINT user_invites_pkey PRIMARY KEY (user_id);


--
-- Name: user_invites user_invites_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_invites
    ADD CONSTRAINT user_invites_token_hash_key UNIQUE (token_hash);


--
-- Name: user_keys user_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_keys
    ADD CONSTRAINT user_keys_pkey PRIMARY KEY (user_id);


--
-- Name: user_settings user_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_settings
    ADD CONSTRAINT user_settings_pkey PRIMARY KEY (user_id, key);


--
-- Name: user_task_order user_task_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_task_order
    ADD CONSTRAINT user_task_order_pkey PRIMARY KEY (user_id, task_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_proxy_login_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_proxy_login_key UNIQUE (proxy_login);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: video_comments video_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.video_comments
    ADD CONSTRAINT video_comments_pkey PRIMARY KEY (id);


--
-- Name: video_reviews video_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.video_reviews
    ADD CONSTRAINT video_reviews_pkey PRIMARY KEY (id);


--
-- Name: video_versions video_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.video_versions
    ADD CONSTRAINT video_versions_pkey PRIMARY KEY (id);


--
-- Name: view_layout_offers view_layout_offers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.view_layout_offers
    ADD CONSTRAINT view_layout_offers_pkey PRIMARY KEY (id);


--
-- Name: view_layouts view_layouts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.view_layouts
    ADD CONSTRAINT view_layouts_pkey PRIMARY KEY (id);


--
-- Name: wait_hidden wait_hidden_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wait_hidden
    ADD CONSTRAINT wait_hidden_pkey PRIMARY KEY (user_id, note_key);


--
-- Name: webauthn_creds webauthn_creds_cred_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webauthn_creds
    ADD CONSTRAINT webauthn_creds_cred_id_key UNIQUE (cred_id);


--
-- Name: webauthn_creds webauthn_creds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webauthn_creds
    ADD CONSTRAINT webauthn_creds_pkey PRIMARY KEY (id);


--
-- Name: webhook_log webhook_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_log
    ADD CONSTRAINT webhook_log_pkey PRIMARY KEY (id);


--
-- Name: webhook_queue webhook_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_queue
    ADD CONSTRAINT webhook_queue_pkey PRIMARY KEY (id);


--
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (id);


--
-- Name: wiki_key_pending wiki_key_pending_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_key_pending
    ADD CONSTRAINT wiki_key_pending_pkey PRIMARY KEY (space_id, user_id);


--
-- Name: wiki_keys wiki_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_keys
    ADD CONSTRAINT wiki_keys_pkey PRIMARY KEY (space_id, gen, user_id);


--
-- Name: wiki_pages wiki_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_pages
    ADD CONSTRAINT wiki_pages_pkey PRIMARY KEY (id);


--
-- Name: wiki_spaces wiki_spaces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_spaces
    ADD CONSTRAINT wiki_spaces_pkey PRIMARY KEY (id);


--
-- Name: activity_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX activity_created ON public.activity USING btree (created_at);


--
-- Name: activity_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX activity_task ON public.activity USING btree (task_id, id);


--
-- Name: activity_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX activity_user ON public.activity USING btree (user_id, created_at);


--
-- Name: admin_alerts_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_alerts_key ON public.admin_alerts USING btree (kind, key, created_at);


--
-- Name: agent_audit_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_audit_agent ON public.agent_audit USING btree (agent_id, id);


--
-- Name: agent_audit_day; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_audit_day ON public.agent_audit USING btree (day);


--
-- Name: agent_chat_pair; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_chat_pair ON public.agent_chat USING btree (agent_id, user_id, id);


--
-- Name: agent_chat_pinned; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_chat_pinned ON public.agent_chat USING btree (agent_id, user_id) WHERE (pinned_at IS NOT NULL);


--
-- Name: agent_events_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_events_agent ON public.agent_events USING btree (agent_id, id);


--
-- Name: agent_jobs_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_jobs_agent ON public.agent_jobs USING btree (agent_id, state);


--
-- Name: agent_jobs_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_jobs_task ON public.agent_jobs USING btree (task_id);


--
-- Name: agent_schedules_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_schedules_due ON public.agent_schedules USING btree (next_at) WHERE (enabled = 1);


--
-- Name: agent_schedules_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_schedules_list ON public.agent_schedules USING btree (list_id) WHERE (list_id IS NOT NULL);


--
-- Name: agent_schedules_pair; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_schedules_pair ON public.agent_schedules USING btree (agent_id, user_id);


--
-- Name: agent_setup_codes_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_setup_codes_agent ON public.agent_setup_codes USING btree (agent_id);


--
-- Name: agent_steps_job; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_steps_job ON public.agent_steps USING btree (job_id) WHERE (job_id IS NOT NULL);


--
-- Name: agent_steps_msg; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_steps_msg ON public.agent_steps USING btree (message_id) WHERE (message_id IS NOT NULL);


--
-- Name: agent_steps_pair; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_steps_pair ON public.agent_steps USING btree (agent_id, user_id, id);


--
-- Name: agent_steps_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_steps_user ON public.agent_steps USING btree (user_id, id);


--
-- Name: agent_usage_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_usage_agent ON public.agent_usage USING btree (agent_id, day);


--
-- Name: agent_usage_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_usage_task ON public.agent_usage USING btree (task_id) WHERE (task_id IS NOT NULL);


--
-- Name: api_tokens_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX api_tokens_user ON public.api_tokens USING btree (user_id);


--
-- Name: app_passwords_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX app_passwords_user ON public.app_passwords USING btree (user_id);


--
-- Name: appt_bookings_cancel; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX appt_bookings_cancel ON public.appt_bookings USING btree (cancel_hash) WHERE (cancel_hash IS NOT NULL);


--
-- Name: appt_bookings_confirm; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX appt_bookings_confirm ON public.appt_bookings USING btree (confirm_hash) WHERE (confirm_hash IS NOT NULL);


--
-- Name: appt_bookings_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX appt_bookings_user ON public.appt_bookings USING btree (user_id, start);


--
-- Name: appt_types_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX appt_types_user ON public.appt_types USING btree (user_id);


--
-- Name: assistant_log_day; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assistant_log_day ON public.assistant_log USING btree (day);


--
-- Name: assistant_log_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assistant_log_user ON public.assistant_log USING btree (user_id, id);


--
-- Name: attachments_comment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX attachments_comment ON public.attachments USING btree (comment_id) WHERE (comment_id IS NOT NULL);


--
-- Name: attachments_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX attachments_task ON public.attachments USING btree (task_id);


--
-- Name: book_members_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX book_members_user ON public.book_members USING btree (user_id);


--
-- Name: bookmarks_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bookmarks_org ON public.bookmarks USING btree (org_id);


--
-- Name: bookmarks_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bookmarks_owner ON public.bookmarks USING btree (user_id, org_id);


--
-- Name: bookmarks_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bookmarks_pending ON public.bookmarks USING btree (preview) WHERE (preview = ANY (ARRAY['pending'::text, 'image'::text]));


--
-- Name: books_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX books_owner ON public.books USING btree (owner_id);


--
-- Name: books_owner_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX books_owner_org ON public.books USING btree (owner_org_id) WHERE (owner_org_id IS NOT NULL);


--
-- Name: budget_cats_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX budget_cats_list ON public.budget_cats USING btree (list_id, sort);


--
-- Name: budget_entries_booked; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX budget_entries_booked ON public.budget_entries USING btree (recurring_id, rmonth) WHERE ((recurring_id IS NOT NULL) AND (rmonth <> ''::text));


--
-- Name: budget_entries_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX budget_entries_list ON public.budget_entries USING btree (list_id, day);


--
-- Name: budget_files_entry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX budget_files_entry ON public.budget_files USING btree (entry_id);


--
-- Name: budget_files_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX budget_files_list ON public.budget_files USING btree (list_id);


--
-- Name: budget_recurring_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX budget_recurring_list ON public.budget_recurring USING btree (list_id);


--
-- Name: cal_events_sub; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cal_events_sub ON public.cal_events USING btree (sub_id, d0);


--
-- Name: cal_subs_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cal_subs_user ON public.cal_subs USING btree (user_id);


--
-- Name: chat_files_msg; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_files_msg ON public.chat_files USING btree (message_id);


--
-- Name: clients_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clients_org ON public.clients USING btree (org_id);


--
-- Name: comments_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX comments_created ON public.comments USING btree (created_at);


--
-- Name: comments_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX comments_task ON public.comments USING btree (task_id);


--
-- Name: comments_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX comments_user ON public.comments USING btree (user_id, created_at);


--
-- Name: conn_links_b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conn_links_b ON public.conn_links USING btree (b_id);


--
-- Name: conn_requests_to; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conn_requests_to ON public.conn_requests USING btree (to_id);


--
-- Name: contact_tasks_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX contact_tasks_task ON public.contact_tasks USING btree (task_id);


--
-- Name: contacts_book; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX contacts_book ON public.contacts USING btree (book_id);


--
-- Name: contacts_uid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX contacts_uid ON public.contacts USING btree (uid);


--
-- Name: ctr_notices_sent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ctr_notices_sent ON public.ctr_notices USING btree (sent_at);


--
-- Name: dav_meta_href; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dav_meta_href ON public.dav_meta USING btree (href);


--
-- Name: dav_meta_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dav_meta_parent ON public.dav_meta USING btree (parent_uid) WHERE (parent_uid IS NOT NULL);


--
-- Name: dav_meta_uid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dav_meta_uid ON public.dav_meta USING btree (uid);


--
-- Name: disc_profiles_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX disc_profiles_email ON public.disc_profiles USING btree (email) WHERE (confirmed_at IS NOT NULL);


--
-- Name: dl_changes_ver; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dl_changes_ver ON public.dl_changes USING btree (ver);


--
-- Name: doc_mail_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX doc_mail_user ON public.doc_mail USING btree (user_id);


--
-- Name: doc_meta_asn; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX doc_meta_asn ON public.doc_meta USING btree (ws, asn) WHERE (asn IS NOT NULL);


--
-- Name: doc_meta_ext; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX doc_meta_ext ON public.doc_meta USING btree (ws, ext_id) WHERE (ext_id IS NOT NULL);


--
-- Name: doc_meta_todo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX doc_meta_todo ON public.doc_meta USING btree (state) WHERE (state = ANY (ARRAY['wait'::text, 'run'::text]));


--
-- Name: doc_meta_ws; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX doc_meta_ws ON public.doc_meta USING btree (ws, doc_date);


--
-- Name: doc_node_tags_tag; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX doc_node_tags_tag ON public.doc_node_tags USING btree (tag_id);


--
-- Name: doc_rules_ws; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX doc_rules_ws ON public.doc_rules USING btree (ws, pos);


--
-- Name: doc_senders_ws; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX doc_senders_ws ON public.doc_senders USING btree (ws);


--
-- Name: doc_tags_ws; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX doc_tags_ws ON public.doc_tags USING btree (ws);


--
-- Name: doc_types_ws; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX doc_types_ws ON public.doc_types USING btree (ws);


--
-- Name: doc_words_h; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX doc_words_h ON public.doc_words USING btree (h);


--
-- Name: env_deploys_env; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX env_deploys_env ON public.env_deploys USING btree (env_id, id);


--
-- Name: env_deploys_ms; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX env_deploys_ms ON public.env_deploys USING btree (milestone_id);


--
-- Name: ev_cal_members_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ev_cal_members_user ON public.ev_cal_members USING btree (user_id);


--
-- Name: ev_cals_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ev_cals_owner ON public.ev_cals USING btree (owner_id);


--
-- Name: event_attendees_contact; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX event_attendees_contact ON public.event_attendees USING btree (contact_id) WHERE (contact_id IS NOT NULL);


--
-- Name: event_attendees_event; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX event_attendees_event ON public.event_attendees USING btree (event_id);


--
-- Name: event_attendees_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX event_attendees_user ON public.event_attendees USING btree (user_id) WHERE (user_id IS NOT NULL);


--
-- Name: events_cal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX events_cal ON public.events USING btree (cal_id, deleted_at);


--
-- Name: events_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX events_task ON public.events USING btree (task_id) WHERE (task_id IS NOT NULL);


--
-- Name: events_uid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX events_uid ON public.events USING btree (uid);


--
-- Name: file_text_att; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_text_att ON public.file_text USING btree (att_id) WHERE (att_id IS NOT NULL);


--
-- Name: file_text_lf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_text_lf ON public.file_text USING btree (list_file_id) WHERE (list_file_id IS NOT NULL);


--
-- Name: file_text_node; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_text_node ON public.file_text USING btree (node_id) WHERE (node_id IS NOT NULL);


--
-- Name: file_text_sha; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_text_sha ON public.file_text USING btree (ws, sha256) WHERE (sha256 <> ''::text);


--
-- Name: file_text_todo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_text_todo ON public.file_text USING btree (state) WHERE (state = ANY (ARRAY['wait'::text, 'run'::text]));


--
-- Name: file_words_h; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_words_h ON public.file_words USING btree (h);


--
-- Name: filters_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filters_user ON public.filters USING btree (user_id);


--
-- Name: forms_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX forms_list ON public.forms USING btree (list_id);


--
-- Name: fs_log_node; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fs_log_node ON public.fs_log USING btree (node_id, id);


--
-- Name: fs_nodes_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fs_nodes_agent ON public.fs_nodes USING btree (agent_id) WHERE (agent_id IS NOT NULL);


--
-- Name: fs_nodes_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fs_nodes_org ON public.fs_nodes USING btree (org_id) WHERE (org_id IS NOT NULL);


--
-- Name: fs_nodes_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fs_nodes_owner ON public.fs_nodes USING btree (owner_id) WHERE (parent_id IS NULL);


--
-- Name: fs_nodes_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fs_nodes_parent ON public.fs_nodes USING btree (parent_id);


--
-- Name: fs_shares_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fs_shares_agent ON public.fs_shares USING btree (agent_id) WHERE (agent_id IS NOT NULL);


--
-- Name: fs_shares_node; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fs_shares_node ON public.fs_shares USING btree (node_id);


--
-- Name: fs_shares_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fs_shares_user ON public.fs_shares USING btree (user_id) WHERE (user_id IS NOT NULL);


--
-- Name: fs_versions_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fs_versions_by ON public.fs_versions USING btree (created_by);


--
-- Name: git_conns_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX git_conns_list ON public.git_conns USING btree (list_id);


--
-- Name: git_folders_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX git_folders_owner ON public.git_folders USING btree (owner_id, folder);


--
-- Name: git_links_conn; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX git_links_conn ON public.git_links USING btree (conn_id, kind, ref);


--
-- Name: group_members_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX group_members_user ON public.group_members USING btree (user_id);


--
-- Name: group_shares_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX group_shares_list ON public.group_shares USING btree (list_id);


--
-- Name: group_shares_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX group_shares_owner ON public.group_shares USING btree (owner_id);


--
-- Name: habits_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX habits_user ON public.habits USING btree (user_id);


--
-- Name: hub_absences_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hub_absences_org ON public.hub_absences USING btree (org_id, start_date);


--
-- Name: hub_absences_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hub_absences_user ON public.hub_absences USING btree (user_id, start_date);


--
-- Name: hub_bookings_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hub_bookings_org ON public.hub_bookings USING btree (org_id, start);


--
-- Name: hub_bookings_res; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hub_bookings_res ON public.hub_bookings USING btree (resource_kind, resource_id, start);


--
-- Name: hub_mails_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hub_mails_client ON public.hub_mails USING btree (client_id) WHERE (client_id IS NOT NULL);


--
-- Name: hub_mails_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hub_mails_list ON public.hub_mails USING btree (list_id) WHERE (list_id IS NOT NULL);


--
-- Name: hub_mails_msg; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX hub_mails_msg ON public.hub_mails USING btree (ws, message_id);


--
-- Name: hub_mails_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hub_mails_owner ON public.hub_mails USING btree (owner_id);


--
-- Name: hub_tokens_client; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX hub_tokens_client ON public.hub_tokens USING btree (client_id) WHERE (kind = 'client'::text);


--
-- Name: hub_tokens_inbox; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX hub_tokens_inbox ON public.hub_tokens USING btree (user_id, COALESCE(org_id, (0)::bigint)) WHERE (kind = 'inbox'::text);


--
-- Name: hub_tokens_list; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX hub_tokens_list ON public.hub_tokens USING btree (list_id) WHERE (kind = 'list'::text);


--
-- Name: hub_words_h; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hub_words_h ON public.hub_words USING btree (h);


--
-- Name: imports_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX imports_user ON public.imports USING btree (user_id, id);


--
-- Name: issue_reports_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_reports_task ON public.issue_reports USING btree (task_id);


--
-- Name: kid_rewards_kid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kid_rewards_kid ON public.kid_rewards USING btree (kid_id);


--
-- Name: kid_stars_kid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kid_stars_kid ON public.kid_stars USING btree (kid_id, id);


--
-- Name: list_activity_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX list_activity_list ON public.list_activity USING btree (list_id);


--
-- Name: list_envs_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX list_envs_list ON public.list_envs USING btree (list_id, sort);


--
-- Name: list_fields_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX list_fields_list ON public.list_fields USING btree (list_id);


--
-- Name: list_files_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX list_files_list ON public.list_files USING btree (list_id);


--
-- Name: list_keys_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX list_keys_user ON public.list_keys USING btree (user_id);


--
-- Name: list_links_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX list_links_list ON public.list_links USING btree (list_id, sort);


--
-- Name: list_members_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX list_members_user ON public.list_members USING btree (user_id);


--
-- Name: list_milestones_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX list_milestones_list ON public.list_milestones USING btree (list_id, day);


--
-- Name: list_notepads_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX list_notepads_list ON public.list_notepads USING btree (list_id, id);


--
-- Name: list_paperless_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX list_paperless_list ON public.list_paperless USING btree (list_id);


--
-- Name: list_rules_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX list_rules_due ON public.list_rules USING btree (trig) WHERE ((trig = 'due'::text) AND (active = 1) AND (deleted_at IS NULL));


--
-- Name: list_rules_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX list_rules_list ON public.list_rules USING btree (list_id) WHERE (deleted_at IS NULL);


--
-- Name: list_status_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX list_status_list ON public.list_status USING btree (list_id, id);


--
-- Name: list_tags_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX list_tags_name ON public.list_tags USING btree (list_id, lower(name));


--
-- Name: lists_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lists_org ON public.lists USING btree (org_id) WHERE (org_id IS NOT NULL);


--
-- Name: lists_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lists_owner ON public.lists USING btree (owner_id);


--
-- Name: mail_tokens_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mail_tokens_user ON public.mail_tokens USING btree (user_id);


--
-- Name: merge_runs_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX merge_runs_target ON public.merge_runs USING btree (kind, target_id);


--
-- Name: msg_trgm_agent_chat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX msg_trgm_agent_chat ON public.agent_chat USING gin (public.kalmido_fold(body) public.gin_trgm_ops);


--
-- Name: msg_trgm_comments; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX msg_trgm_comments ON public.comments USING gin (public.kalmido_fold(body) public.gin_trgm_ops);


--
-- Name: msg_trgm_tchat_msgs; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX msg_trgm_tchat_msgs ON public.tchat_msgs USING gin (public.kalmido_fold(body) public.gin_trgm_ops);


--
-- Name: msv_links_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX msv_links_user ON public.msv_links USING btree (user_id, "position");


--
-- Name: nl_runs_conn; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nl_runs_conn ON public.nl_runs USING btree (conn_id, id);


--
-- Name: notes_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notes_list ON public.notes USING btree (list_id, updated_at);


--
-- Name: notifications_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_task ON public.notifications USING btree (task_id);


--
-- Name: notifications_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_user ON public.notifications USING btree (user_id, id);


--
-- Name: office_agreements_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_agreements_org ON public.office_agreements USING btree (org_id);


--
-- Name: office_archive_log_entry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_archive_log_entry ON public.office_archive_log USING btree (archive_id, id);


--
-- Name: office_archive_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX office_archive_number ON public.office_archive USING btree (org_id, number) WHERE (number <> ''::text);


--
-- Name: office_archive_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_archive_org ON public.office_archive USING btree (org_id, kind);


--
-- Name: office_bank_imports_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_bank_imports_org ON public.office_bank_imports USING btree (org_id);


--
-- Name: office_bank_tx_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_bank_tx_hash ON public.office_bank_tx USING btree (org_id, hash);


--
-- Name: office_bank_tx_import; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_bank_tx_import ON public.office_bank_tx USING btree (import_id);


--
-- Name: office_bank_tx_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_bank_tx_org ON public.office_bank_tx USING btree (org_id, day);


--
-- Name: office_client_contacts_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_client_contacts_client ON public.office_client_contacts USING btree (client_id, sort, id);


--
-- Name: office_client_contacts_contact; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_client_contacts_contact ON public.office_client_contacts USING btree (contact_id) WHERE (contact_id IS NOT NULL);


--
-- Name: office_contracts_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_contracts_org ON public.office_contracts USING btree (org_id);


--
-- Name: office_deals_offer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_deals_offer ON public.office_deals USING btree (offer_id) WHERE (offer_id IS NOT NULL);


--
-- Name: office_deals_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_deals_org ON public.office_deals USING btree (org_id, stage);


--
-- Name: office_doc_items_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_doc_items_doc ON public.office_doc_items USING btree (doc_id);


--
-- Name: office_doc_items_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_doc_items_org ON public.office_doc_items USING btree (org_id, doc_id);


--
-- Name: office_doc_log_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_doc_log_action ON public.office_doc_log USING btree (org_id, action, at);


--
-- Name: office_doc_log_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_doc_log_doc ON public.office_doc_log USING btree (doc_id);


--
-- Name: office_doc_log_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_doc_log_org ON public.office_doc_log USING btree (org_id, id);


--
-- Name: office_doc_parts_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_doc_parts_doc ON public.office_doc_parts USING btree (doc_id, sort);


--
-- Name: office_doc_templates_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_doc_templates_org ON public.office_doc_templates USING btree (org_id);


--
-- Name: office_docs_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX office_docs_number ON public.office_docs USING btree (org_id, number) WHERE (number <> ''::text);


--
-- Name: office_docs_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_docs_org ON public.office_docs USING btree (org_id, kind);


--
-- Name: office_docs_series; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX office_docs_series ON public.office_docs USING btree (series_id, series_period) WHERE (series_id IS NOT NULL);


--
-- Name: office_drive_log_drive; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_drive_log_drive ON public.office_drive_log USING btree (drive_id);


--
-- Name: office_drives_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_drives_org ON public.office_drives USING btree (org_id, day);


--
-- Name: office_drives_vehicle; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_drives_vehicle ON public.office_drives USING btree (vehicle_id, day);


--
-- Name: office_equipment_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_equipment_org ON public.office_equipment USING btree (org_id);


--
-- Name: office_fixed_costs_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_fixed_costs_org ON public.office_fixed_costs USING btree (org_id);


--
-- Name: office_gen_docs_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_gen_docs_client ON public.office_gen_docs USING btree (client_id) WHERE (client_id IS NOT NULL);


--
-- Name: office_gen_docs_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_gen_docs_org ON public.office_gen_docs USING btree (org_id);


--
-- Name: office_import_runs_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_import_runs_org ON public.office_import_runs USING btree (org_id, id);


--
-- Name: office_inv_series_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_inv_series_org ON public.office_inv_series USING btree (org_id);


--
-- Name: office_pack_installs_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX office_pack_installs_active ON public.office_pack_installs USING btree (org_id, kind, code) WHERE (removed_at IS NULL);


--
-- Name: office_pay_props_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_pay_props_org ON public.office_pay_props USING btree (org_id, state);


--
-- Name: office_payments_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_payments_doc ON public.office_payments USING btree (org_id, doc_id);


--
-- Name: office_purchases_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_purchases_doc ON public.office_purchases USING btree (doc_id);


--
-- Name: office_purchases_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_purchases_org ON public.office_purchases USING btree (org_id, date);


--
-- Name: office_roles_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_roles_org ON public.office_roles USING btree (org_id, kind);


--
-- Name: office_services_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_services_org ON public.office_services USING btree (org_id);


--
-- Name: office_sets_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_sets_org ON public.office_sets USING btree (org_id);


--
-- Name: office_signoffs_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_signoffs_doc ON public.office_signoffs USING btree (doc_id) WHERE (doc_id IS NOT NULL);


--
-- Name: office_signoffs_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_signoffs_list ON public.office_signoffs USING btree (list_id) WHERE (list_id IS NOT NULL);


--
-- Name: office_signoffs_video; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_signoffs_video ON public.office_signoffs USING btree (video_id) WHERE (video_id IS NOT NULL);


--
-- Name: office_sub_reminders_due; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX office_sub_reminders_due ON public.office_sub_reminders USING btree (fixed_id, due);


--
-- Name: office_texts_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_texts_org ON public.office_texts USING btree (org_id);


--
-- Name: office_trip_items_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_trip_items_org ON public.office_trip_items USING btree (org_id, date);


--
-- Name: office_trip_items_trip; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_trip_items_trip ON public.office_trip_items USING btree (trip_id, date);


--
-- Name: office_trips_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_trips_org ON public.office_trips USING btree (org_id, date_from);


--
-- Name: office_vehicles_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX office_vehicles_org ON public.office_vehicles USING btree (org_id);


--
-- Name: org_list_log_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX org_list_log_org ON public.org_list_log USING btree (org_id, id);


--
-- Name: org_members_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX org_members_user ON public.org_members USING btree (user_id);


--
-- Name: orgs_personal; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX orgs_personal ON public.orgs USING btree (personal_of) WHERE (personal_of IS NOT NULL);


--
-- Name: paperless_links_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX paperless_links_task ON public.paperless_links USING btree (task_id);


--
-- Name: pl_imported_sha; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pl_imported_sha ON public.pl_imported USING btree (ws, sha256);


--
-- Name: pl_uploads_ws; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pl_uploads_ws ON public.pl_uploads USING btree (ws);


--
-- Name: playbook_proposals_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX playbook_proposals_list ON public.playbook_proposals USING btree (list_id, state);


--
-- Name: playbooks_folder_v; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX playbooks_folder_v ON public.playbooks USING btree (owner_id, folder, version) WHERE (list_id IS NULL);


--
-- Name: playbooks_list_v; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX playbooks_list_v ON public.playbooks USING btree (list_id, version) WHERE (list_id IS NOT NULL);


--
-- Name: pomos_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pomos_user ON public.pomos USING btree (user_id);


--
-- Name: portal_logins_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX portal_logins_email ON public.portal_logins USING btree (email_hash, created_at);


--
-- Name: portal_tickets_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX portal_tickets_email ON public.portal_tickets USING btree (email_hash, org_id, owner_id);


--
-- Name: portal_tickets_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX portal_tickets_list ON public.portal_tickets USING btree (list_id);


--
-- Name: push_subs_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX push_subs_user ON public.push_subs USING btree (user_id);


--
-- Name: rc_receipts_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rc_receipts_list ON public.rc_receipts USING btree (list_id);


--
-- Name: rc_suggest_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rc_suggest_agent ON public.rc_suggest USING btree (agent_id, state);


--
-- Name: rc_suggest_node; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rc_suggest_node ON public.rc_suggest USING btree (node_id, state);


--
-- Name: recovery_codes_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX recovery_codes_user ON public.recovery_codes USING btree (user_id);


--
-- Name: rss_feeds_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rss_feeds_user ON public.rss_feeds USING btree (user_id);


--
-- Name: rss_items_published; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rss_items_published ON public.rss_items USING btree (published);


--
-- Name: rss_items_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rss_items_user ON public.rss_items USING btree (user_id, published);


--
-- Name: sample_items_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sample_items_user ON public.sample_items USING btree (user_id, kind);


--
-- Name: sessions_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_user ON public.sessions USING btree (user_id);


--
-- Name: sheet_cells_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sheet_cells_name ON public.sheet_cells USING btree (sheet_id, lower(name)) WHERE (name IS NOT NULL);


--
-- Name: sheet_cells_sheet; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sheet_cells_sheet ON public.sheet_cells USING btree (sheet_id);


--
-- Name: sheet_changes_batch; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sheet_changes_batch ON public.sheet_changes USING btree (sheet_id, batch);


--
-- Name: sheet_columns_sheet; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sheet_columns_sheet ON public.sheet_columns USING btree (sheet_id, pos);


--
-- Name: sheet_links_sheet; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sheet_links_sheet ON public.sheet_links USING btree (sheet_id, batch);


--
-- Name: sheet_links_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sheet_links_target ON public.sheet_links USING btree (kind, target_id);


--
-- Name: sheet_rows_sheet; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sheet_rows_sheet ON public.sheet_rows USING btree (sheet_id, pos);


--
-- Name: sheets_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sheets_list ON public.sheets USING btree (list_id) WHERE (list_id IS NOT NULL);


--
-- Name: sheets_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sheets_org ON public.sheets USING btree (org_id, updated_at);


--
-- Name: sheets_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sheets_owner ON public.sheets USING btree (owner_id) WHERE (org_id IS NULL);


--
-- Name: space_moves_obj; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX space_moves_obj ON public.space_moves USING btree (kind, obj_id);


--
-- Name: sprints_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sprints_list ON public.sprints USING btree (list_id, num);


--
-- Name: task_deps_blocker; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX task_deps_blocker ON public.task_deps USING btree (blocker_id);


--
-- Name: task_field_values_field; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX task_field_values_field ON public.task_field_values USING btree (field_id);


--
-- Name: task_links_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX task_links_list ON public.task_links USING btree (list_id);


--
-- Name: task_list_tags_tag; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX task_list_tags_tag ON public.task_list_tags USING btree (tag_id);


--
-- Name: task_people_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX task_people_user ON public.task_people USING btree (user_id);


--
-- Name: task_tags_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX task_tags_user ON public.task_tags USING btree (user_id, tag);


--
-- Name: task_vectors_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX task_vectors_org ON public.task_vectors USING btree (org_id);


--
-- Name: tasks_agroup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_agroup ON public.tasks USING btree (assignee_group_id) WHERE (assignee_group_id IS NOT NULL);


--
-- Name: tasks_assignee; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_assignee ON public.tasks USING btree (assignee_id);


--
-- Name: tasks_completed_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_completed_by ON public.tasks USING btree (completed_by, completed_at) WHERE (completed_by IS NOT NULL);


--
-- Name: tasks_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_list ON public.tasks USING btree (list_id);


--
-- Name: tasks_msid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_msid ON public.tasks USING btree (milestone_id) WHERE (milestone_id IS NOT NULL);


--
-- Name: tasks_open; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_open ON public.tasks USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: tasks_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_parent ON public.tasks USING btree (parent_id);


--
-- Name: tasks_tt_user; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tasks_tt_user ON public.tasks USING btree (created_by, tt_id) WHERE (tt_id IS NOT NULL);


--
-- Name: tchat_dm; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tchat_dm ON public.tchat_rooms USING btree (a, b) WHERE (kind = 'dm'::text);


--
-- Name: tchat_list; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tchat_list ON public.tchat_rooms USING btree (list_id) WHERE (kind = 'list'::text);


--
-- Name: tchat_msgs_pinned; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tchat_msgs_pinned ON public.tchat_msgs USING btree (room_id) WHERE (pinned_at IS NOT NULL);


--
-- Name: tchat_msgs_room; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tchat_msgs_room ON public.tchat_msgs USING btree (room_id, id);


--
-- Name: templates_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX templates_user ON public.templates USING btree (user_id);


--
-- Name: time_client; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX time_client ON public.time_entries USING btree (user_id, client_id) WHERE (client_id IS NOT NULL);


--
-- Name: time_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX time_list ON public.time_entries USING btree (list_id, start);


--
-- Name: time_pomo; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX time_pomo ON public.time_entries USING btree (pomo_id) WHERE (pomo_id IS NOT NULL);


--
-- Name: time_running; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX time_running ON public.time_entries USING btree (user_id) WHERE ("end" IS NULL);


--
-- Name: time_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX time_task ON public.time_entries USING btree (task_id);


--
-- Name: time_user_start; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX time_user_start ON public.time_entries USING btree (user_id, start);


--
-- Name: upload_scan_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX upload_scan_state ON public.upload_scan USING btree (state, id);


--
-- Name: users_oidc; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_oidc ON public.users USING btree (oidc_subject) WHERE (oidc_subject IS NOT NULL);


--
-- Name: video_comments_review; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX video_comments_review ON public.video_comments USING btree (review_id, version_id);


--
-- Name: video_reviews_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX video_reviews_client ON public.video_reviews USING btree (client_id) WHERE (client_id IS NOT NULL);


--
-- Name: video_reviews_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX video_reviews_list ON public.video_reviews USING btree (list_id) WHERE (list_id IS NOT NULL);


--
-- Name: video_reviews_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX video_reviews_task ON public.video_reviews USING btree (task_id) WHERE (task_id IS NOT NULL);


--
-- Name: video_versions_review; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX video_versions_review ON public.video_versions USING btree (review_id, n);


--
-- Name: view_layout_offers_from; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX view_layout_offers_from ON public.view_layout_offers USING btree (from_user);


--
-- Name: view_layout_offers_to; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX view_layout_offers_to ON public.view_layout_offers USING btree (to_user, state);


--
-- Name: view_layouts_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX view_layouts_user ON public.view_layouts USING btree (user_id, view_key, pos);


--
-- Name: webauthn_creds_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webauthn_creds_user ON public.webauthn_creds USING btree (user_id);


--
-- Name: webhook_log_hook; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhook_log_hook ON public.webhook_log USING btree (webhook_id, id);


--
-- Name: webhook_queue_next; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhook_queue_next ON public.webhook_queue USING btree (next_at);


--
-- Name: webhooks_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhooks_user ON public.webhooks USING btree (user_id);


--
-- Name: wiki_keys_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wiki_keys_user ON public.wiki_keys USING btree (user_id);


--
-- Name: wiki_links_from; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wiki_links_from ON public.wiki_links USING btree (from_id);


--
-- Name: wiki_links_path; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wiki_links_path ON public.wiki_links USING btree (to_path) WHERE (to_path IS NOT NULL);


--
-- Name: wiki_links_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wiki_links_task ON public.wiki_links USING btree (to_task) WHERE (to_task IS NOT NULL);


--
-- Name: wiki_pages_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wiki_pages_org ON public.wiki_pages USING btree (org_id, updated_at);


--
-- Name: wiki_pages_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wiki_pages_owner ON public.wiki_pages USING btree (owner_id) WHERE (org_id IS NULL);


--
-- Name: wiki_pages_path; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX wiki_pages_path ON public.wiki_pages USING btree (COALESCE(org_id, (0)::bigint), COALESCE(owner_id, (0)::bigint), lower(path)) WHERE (deleted_at IS NULL);


--
-- Name: wiki_spaces_one; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX wiki_spaces_one ON public.wiki_spaces USING btree (COALESCE(org_id, (0)::bigint), COALESCE(owner_id, (0)::bigint));


--
-- Name: agent_usage kalmido_dl_agent_usage; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_agent_usage AFTER INSERT OR DELETE OR UPDATE ON public.agent_usage FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('task_id');


--
-- Name: attachments kalmido_dl_attachments; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_attachments AFTER INSERT OR DELETE OR UPDATE ON public.attachments FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('task_id');


--
-- Name: comments kalmido_dl_comments; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_comments AFTER INSERT OR DELETE OR UPDATE ON public.comments FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('task_id');


--
-- Name: contact_tasks kalmido_dl_contact_tasks; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_contact_tasks AFTER INSERT OR DELETE OR UPDATE ON public.contact_tasks FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('task_id');


--
-- Name: events kalmido_dl_events; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_events AFTER INSERT OR DELETE OR UPDATE ON public.events FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('task_id');


--
-- Name: folder_people kalmido_dl_folder_people; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_folder_people AFTER INSERT OR DELETE OR UPDATE ON public.folder_people FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('full');


--
-- Name: git_closes kalmido_dl_git_closes; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_git_closes AFTER INSERT OR DELETE OR UPDATE ON public.git_closes FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('task_id');


--
-- Name: git_links kalmido_dl_git_links; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_git_links AFTER INSERT OR DELETE OR UPDATE ON public.git_links FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('task_id');


--
-- Name: group_members kalmido_dl_group_members; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_group_members AFTER INSERT OR DELETE OR UPDATE ON public.group_members FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('full');


--
-- Name: group_shares kalmido_dl_group_shares; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_group_shares AFTER INSERT OR DELETE OR UPDATE ON public.group_shares FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('full');


--
-- Name: list_fields kalmido_dl_list_fields; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_list_fields AFTER INSERT OR DELETE OR UPDATE ON public.list_fields FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('full');


--
-- Name: list_key_pending kalmido_dl_list_key_pending; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_list_key_pending AFTER INSERT OR DELETE OR UPDATE ON public.list_key_pending FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('full');


--
-- Name: list_keys kalmido_dl_list_keys; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_list_keys AFTER INSERT OR DELETE OR UPDATE ON public.list_keys FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('full');


--
-- Name: list_members kalmido_dl_list_members; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_list_members AFTER INSERT OR DELETE OR UPDATE ON public.list_members FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('full');


--
-- Name: list_tags kalmido_dl_list_tags; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_list_tags AFTER INSERT OR DELETE OR UPDATE ON public.list_tags FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('full');


--
-- Name: lists kalmido_dl_lists; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_lists AFTER INSERT OR DELETE OR UPDATE ON public.lists FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('full');


--
-- Name: org_members kalmido_dl_org_members; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_org_members AFTER INSERT OR DELETE OR UPDATE ON public.org_members FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('full');


--
-- Name: sections kalmido_dl_sections; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_sections AFTER INSERT OR DELETE OR UPDATE ON public.sections FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('full');


--
-- Name: task_deps kalmido_dl_task_deps; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_task_deps AFTER INSERT OR DELETE OR UPDATE ON public.task_deps FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('task_id', 'blocker_id');


--
-- Name: task_enc_notes kalmido_dl_task_enc_notes; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_task_enc_notes AFTER INSERT OR DELETE OR UPDATE ON public.task_enc_notes FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('task_id');


--
-- Name: task_field_values kalmido_dl_task_field_values; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_task_field_values AFTER INSERT OR DELETE OR UPDATE ON public.task_field_values FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('task_id');


--
-- Name: task_links kalmido_dl_task_links; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_task_links AFTER INSERT OR DELETE OR UPDATE ON public.task_links FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('task_id');


--
-- Name: task_list_tags kalmido_dl_task_list_tags; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_task_list_tags AFTER INSERT OR DELETE OR UPDATE ON public.task_list_tags FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('task_id');


--
-- Name: task_note_locks kalmido_dl_task_note_locks; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_task_note_locks AFTER INSERT OR DELETE OR UPDATE ON public.task_note_locks FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('task_id');


--
-- Name: task_people kalmido_dl_task_people; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_task_people AFTER INSERT OR DELETE OR UPDATE ON public.task_people FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('task_id');


--
-- Name: task_seen kalmido_dl_task_seen; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_task_seen AFTER INSERT OR DELETE OR UPDATE ON public.task_seen FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('task_id');


--
-- Name: task_tags kalmido_dl_task_tags; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_task_tags AFTER INSERT OR DELETE OR UPDATE ON public.task_tags FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('task_id');


--
-- Name: tasks kalmido_dl_tasks; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_tasks AFTER INSERT OR DELETE OR UPDATE ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('id');


--
-- Name: time_entries kalmido_dl_time_entries; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_dl_time_entries AFTER INSERT OR DELETE OR UPDATE ON public.time_entries FOR EACH ROW EXECUTE FUNCTION public.kalmido_dl_touch('task_id');


--
-- Name: lists kalmido_ml_list; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_ml_list AFTER UPDATE OF org_id ON public.lists FOR EACH ROW WHEN ((new.org_id IS DISTINCT FROM old.org_id)) EXECUTE FUNCTION public.kalmido_ml_prune();


--
-- Name: tasks kalmido_ml_task; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kalmido_ml_task AFTER UPDATE OF list_id, parent_id ON public.tasks FOR EACH ROW WHEN (((new.list_id IS DISTINCT FROM old.list_id) OR (new.parent_id IS DISTINCT FROM old.parent_id))) EXECUTE FUNCTION public.kalmido_ml_prune();


--
-- Name: list_members list_e2e_members; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER list_e2e_members BEFORE INSERT OR DELETE OR UPDATE OF role, user_id ON public.list_members FOR EACH ROW EXECUTE FUNCTION public.kalmido_list_e2e_members();


--
-- Name: tasks time_task_list; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER time_task_list AFTER UPDATE OF list_id ON public.tasks FOR EACH ROW WHEN ((new.list_id IS DISTINCT FROM old.list_id)) EXECUTE FUNCTION public.kalmido_time_task_list();


--
-- Name: tasks time_task_title; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER time_task_title AFTER UPDATE OF title ON public.tasks FOR EACH ROW WHEN ((new.title IS DISTINCT FROM old.title)) EXECUTE FUNCTION public.kalmido_time_task_title();


--
-- Name: time_entries time_title_e2e; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER time_title_e2e BEFORE INSERT OR UPDATE OF task_title ON public.time_entries FOR EACH ROW EXECUTE FUNCTION public.kalmido_time_title_e2e();


--
-- Name: org_members wiki_e2e_members; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER wiki_e2e_members BEFORE INSERT OR DELETE OR UPDATE OF org_id, user_id ON public.org_members FOR EACH ROW EXECUTE FUNCTION public.kalmido_wiki_e2e_members();


--
-- Name: activity activity_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity
    ADD CONSTRAINT activity_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: admin_login_ips admin_login_ips_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_login_ips
    ADD CONSTRAINT admin_login_ips_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agent_bridges agent_bridges_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_bridges
    ADD CONSTRAINT agent_bridges_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agent_bridges agent_bridges_list_a_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_bridges
    ADD CONSTRAINT agent_bridges_list_a_fkey FOREIGN KEY (list_a) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: agent_bridges agent_bridges_list_b_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_bridges
    ADD CONSTRAINT agent_bridges_list_b_fkey FOREIGN KEY (list_b) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: agent_chat agent_chat_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_chat
    ADD CONSTRAINT agent_chat_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agent_chat agent_chat_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_chat
    ADD CONSTRAINT agent_chat_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.agent_jobs(id) ON DELETE SET NULL;


--
-- Name: agent_chat agent_chat_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_chat
    ADD CONSTRAINT agent_chat_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: agent_chat agent_chat_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_chat
    ADD CONSTRAINT agent_chat_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agent_events agent_events_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_events
    ADD CONSTRAINT agent_events_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agent_jobs agent_jobs_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_jobs
    ADD CONSTRAINT agent_jobs_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agent_jobs agent_jobs_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_jobs
    ADD CONSTRAINT agent_jobs_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.agent_jobs(id) ON DELETE SET NULL;


--
-- Name: agent_jobs agent_jobs_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_jobs
    ADD CONSTRAINT agent_jobs_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: agent_jobs agent_jobs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_jobs
    ADD CONSTRAINT agent_jobs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: agent_list_access agent_list_access_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_list_access
    ADD CONSTRAINT agent_list_access_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agent_list_access agent_list_access_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_list_access
    ADD CONSTRAINT agent_list_access_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: agent_schedules agent_schedules_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_schedules
    ADD CONSTRAINT agent_schedules_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agent_schedules agent_schedules_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_schedules
    ADD CONSTRAINT agent_schedules_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: agent_schedules agent_schedules_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_schedules
    ADD CONSTRAINT agent_schedules_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agent_setup_codes agent_setup_codes_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_setup_codes
    ADD CONSTRAINT agent_setup_codes_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agent_steps agent_steps_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_steps
    ADD CONSTRAINT agent_steps_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agent_steps agent_steps_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_steps
    ADD CONSTRAINT agent_steps_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.agent_jobs(id) ON DELETE CASCADE;


--
-- Name: agent_steps agent_steps_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_steps
    ADD CONSTRAINT agent_steps_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.agent_chat(id) ON DELETE CASCADE;


--
-- Name: agent_steps agent_steps_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_steps
    ADD CONSTRAINT agent_steps_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agent_usage agent_usage_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_usage
    ADD CONSTRAINT agent_usage_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agent_usage agent_usage_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_usage
    ADD CONSTRAINT agent_usage_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.agent_jobs(id) ON DELETE SET NULL;


--
-- Name: agent_usage agent_usage_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_usage
    ADD CONSTRAINT agent_usage_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE SET NULL;


--
-- Name: agent_usage agent_usage_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_usage
    ADD CONSTRAINT agent_usage_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: agents agents_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE SET NULL;


--
-- Name: agents agents_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: api_tokens api_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_tokens
    ADD CONSTRAINT api_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: app_passwords app_passwords_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_passwords
    ADD CONSTRAINT app_passwords_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: appt_bookings appt_bookings_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appt_bookings
    ADD CONSTRAINT appt_bookings_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id) ON DELETE SET NULL;


--
-- Name: appt_bookings appt_bookings_deal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appt_bookings
    ADD CONSTRAINT appt_bookings_deal_id_fkey FOREIGN KEY (deal_id) REFERENCES public.office_deals(id) ON DELETE SET NULL;


--
-- Name: appt_bookings appt_bookings_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appt_bookings
    ADD CONSTRAINT appt_bookings_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE SET NULL;


--
-- Name: appt_bookings appt_bookings_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appt_bookings
    ADD CONSTRAINT appt_bookings_type_id_fkey FOREIGN KEY (type_id) REFERENCES public.appt_types(id) ON DELETE SET NULL;


--
-- Name: appt_bookings appt_bookings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appt_bookings
    ADD CONSTRAINT appt_bookings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: appt_pages appt_pages_cal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appt_pages
    ADD CONSTRAINT appt_pages_cal_id_fkey FOREIGN KEY (cal_id) REFERENCES public.ev_cals(id) ON DELETE SET NULL;


--
-- Name: appt_pages appt_pages_office_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appt_pages
    ADD CONSTRAINT appt_pages_office_org_id_fkey FOREIGN KEY (office_org_id) REFERENCES public.orgs(id) ON DELETE SET NULL;


--
-- Name: appt_pages appt_pages_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appt_pages
    ADD CONSTRAINT appt_pages_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: appt_types appt_types_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appt_types
    ADD CONSTRAINT appt_types_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: assistant_access assistant_access_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_access
    ADD CONSTRAINT assistant_access_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: assistant_access assistant_access_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_access
    ADD CONSTRAINT assistant_access_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: assistant_log assistant_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant_log
    ADD CONSTRAINT assistant_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: attachments attachments_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: book_members book_members_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.book_members
    ADD CONSTRAINT book_members_book_id_fkey FOREIGN KEY (book_id) REFERENCES public.books(id) ON DELETE CASCADE;


--
-- Name: book_members book_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.book_members
    ADD CONSTRAINT book_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: bookmarks bookmarks_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookmarks
    ADD CONSTRAINT bookmarks_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: bookmarks bookmarks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookmarks
    ADD CONSTRAINT bookmarks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: books books_occ_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT books_occ_list_id_fkey FOREIGN KEY (occ_list_id) REFERENCES public.lists(id) ON DELETE SET NULL;


--
-- Name: books books_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT books_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE SET NULL;


--
-- Name: books books_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT books_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: books books_owner_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT books_owner_org_id_fkey FOREIGN KEY (owner_org_id) REFERENCES public.orgs(id) ON DELETE SET NULL;


--
-- Name: books books_src_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT books_src_id_fkey FOREIGN KEY (src_id) REFERENCES public.contact_srcs(id) ON DELETE SET NULL;


--
-- Name: budget_cats budget_cats_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_cats
    ADD CONSTRAINT budget_cats_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: budget_entries budget_entries_cat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_entries
    ADD CONSTRAINT budget_entries_cat_id_fkey FOREIGN KEY (cat_id) REFERENCES public.budget_cats(id) ON DELETE SET NULL;


--
-- Name: budget_entries budget_entries_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_entries
    ADD CONSTRAINT budget_entries_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: budget_entries budget_entries_recurring_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_entries
    ADD CONSTRAINT budget_entries_recurring_id_fkey FOREIGN KEY (recurring_id) REFERENCES public.budget_recurring(id) ON DELETE SET NULL;


--
-- Name: budget_files budget_files_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_files
    ADD CONSTRAINT budget_files_entry_id_fkey FOREIGN KEY (entry_id) REFERENCES public.budget_entries(id) ON DELETE CASCADE;


--
-- Name: budget_files budget_files_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_files
    ADD CONSTRAINT budget_files_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: budget_meta budget_meta_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_meta
    ADD CONSTRAINT budget_meta_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: budget_recurring budget_recurring_cat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_recurring
    ADD CONSTRAINT budget_recurring_cat_id_fkey FOREIGN KEY (cat_id) REFERENCES public.budget_cats(id) ON DELETE SET NULL;


--
-- Name: budget_recurring budget_recurring_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_recurring
    ADD CONSTRAINT budget_recurring_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: cal_dav_res cal_dav_res_sub_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cal_dav_res
    ADD CONSTRAINT cal_dav_res_sub_id_fkey FOREIGN KEY (sub_id) REFERENCES public.cal_subs(id) ON DELETE CASCADE;


--
-- Name: cal_events cal_events_sub_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cal_events
    ADD CONSTRAINT cal_events_sub_id_fkey FOREIGN KEY (sub_id) REFERENCES public.cal_subs(id) ON DELETE CASCADE;


--
-- Name: cal_subs cal_subs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cal_subs
    ADD CONSTRAINT cal_subs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: chat_files chat_files_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_files
    ADD CONSTRAINT chat_files_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.agent_chat(id) ON DELETE CASCADE;


--
-- Name: chat_reactions chat_reactions_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_reactions
    ADD CONSTRAINT chat_reactions_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.agent_chat(id) ON DELETE CASCADE;


--
-- Name: chat_reactions chat_reactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_reactions
    ADD CONSTRAINT chat_reactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: chat_saves chat_saves_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_saves
    ADD CONSTRAINT chat_saves_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: chat_saves chat_saves_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_saves
    ADD CONSTRAINT chat_saves_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: clients clients_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE SET NULL;


--
-- Name: comment_reactions comment_reactions_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_reactions
    ADD CONSTRAINT comment_reactions_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES public.comments(id) ON DELETE CASCADE;


--
-- Name: comment_reactions comment_reactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_reactions
    ADD CONSTRAINT comment_reactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: comments comments_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: comments comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: conn_blocks conn_blocks_blocked_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conn_blocks
    ADD CONSTRAINT conn_blocks_blocked_id_fkey FOREIGN KEY (blocked_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: conn_blocks conn_blocks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conn_blocks
    ADD CONSTRAINT conn_blocks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: conn_links conn_links_a_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conn_links
    ADD CONSTRAINT conn_links_a_id_fkey FOREIGN KEY (a_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: conn_links conn_links_b_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conn_links
    ADD CONSTRAINT conn_links_b_id_fkey FOREIGN KEY (b_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: conn_requests conn_requests_from_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conn_requests
    ADD CONSTRAINT conn_requests_from_id_fkey FOREIGN KEY (from_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: conn_requests conn_requests_to_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conn_requests
    ADD CONSTRAINT conn_requests_to_id_fkey FOREIGN KEY (to_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: contact_care contact_care_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_care
    ADD CONSTRAINT contact_care_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id) ON DELETE CASCADE;


--
-- Name: contact_care contact_care_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_care
    ADD CONSTRAINT contact_care_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: contact_links contact_links_src_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_links
    ADD CONSTRAINT contact_links_src_id_fkey FOREIGN KEY (src_id) REFERENCES public.contact_srcs(id) ON DELETE CASCADE;


--
-- Name: contact_links contact_links_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_links
    ADD CONSTRAINT contact_links_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: contact_occ contact_occ_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_occ
    ADD CONSTRAINT contact_occ_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id) ON DELETE CASCADE;


--
-- Name: contact_occ contact_occ_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_occ
    ADD CONSTRAINT contact_occ_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: contact_srcs contact_srcs_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_srcs
    ADD CONSTRAINT contact_srcs_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE SET NULL;


--
-- Name: contact_srcs contact_srcs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_srcs
    ADD CONSTRAINT contact_srcs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: contact_tasks contact_tasks_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_tasks
    ADD CONSTRAINT contact_tasks_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id) ON DELETE CASCADE;


--
-- Name: contact_tasks contact_tasks_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_tasks
    ADD CONSTRAINT contact_tasks_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: contacts contacts_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_book_id_fkey FOREIGN KEY (book_id) REFERENCES public.books(id) ON DELETE CASCADE;


--
-- Name: ctr_notices ctr_notices_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ctr_notices
    ADD CONSTRAINT ctr_notices_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ctr_notices ctr_notices_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ctr_notices
    ADD CONSTRAINT ctr_notices_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: ctr_notices ctr_notices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ctr_notices
    ADD CONSTRAINT ctr_notices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: dav_meta dav_meta_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dav_meta
    ADD CONSTRAINT dav_meta_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: dav_sync2 dav_sync2_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dav_sync2
    ADD CONSTRAINT dav_sync2_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: dav_sync dav_sync_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dav_sync
    ADD CONSTRAINT dav_sync_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: dav_sync dav_sync_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dav_sync
    ADD CONSTRAINT dav_sync_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: disc_profiles disc_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disc_profiles
    ADD CONSTRAINT disc_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: disc_quota disc_quota_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disc_quota
    ADD CONSTRAINT disc_quota_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: disc_tokens disc_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disc_tokens
    ADD CONSTRAINT disc_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: doc_cfg doc_cfg_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_cfg
    ADD CONSTRAINT doc_cfg_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: doc_mail doc_mail_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_mail
    ADD CONSTRAINT doc_mail_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: doc_mail doc_mail_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_mail
    ADD CONSTRAINT doc_mail_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: doc_meta doc_meta_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_meta
    ADD CONSTRAINT doc_meta_node_id_fkey FOREIGN KEY (node_id) REFERENCES public.fs_nodes(id) ON DELETE CASCADE;


--
-- Name: doc_meta doc_meta_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_meta
    ADD CONSTRAINT doc_meta_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: doc_models doc_models_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_models
    ADD CONSTRAINT doc_models_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: doc_node_tags doc_node_tags_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_node_tags
    ADD CONSTRAINT doc_node_tags_node_id_fkey FOREIGN KEY (node_id) REFERENCES public.fs_nodes(id) ON DELETE CASCADE;


--
-- Name: doc_node_tags doc_node_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_node_tags
    ADD CONSTRAINT doc_node_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.doc_tags(id) ON DELETE CASCADE;


--
-- Name: doc_rules doc_rules_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_rules
    ADD CONSTRAINT doc_rules_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: doc_senders doc_senders_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_senders
    ADD CONSTRAINT doc_senders_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: doc_tags doc_tags_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_tags
    ADD CONSTRAINT doc_tags_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: doc_types doc_types_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_types
    ADD CONSTRAINT doc_types_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: doc_words doc_words_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.doc_words
    ADD CONSTRAINT doc_words_node_id_fkey FOREIGN KEY (node_id) REFERENCES public.fs_nodes(id) ON DELETE CASCADE;


--
-- Name: e2e_keys e2e_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.e2e_keys
    ADD CONSTRAINT e2e_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: env_deploys env_deploys_env_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.env_deploys
    ADD CONSTRAINT env_deploys_env_id_fkey FOREIGN KEY (env_id) REFERENCES public.list_envs(id) ON DELETE CASCADE;


--
-- Name: env_deploys env_deploys_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.env_deploys
    ADD CONSTRAINT env_deploys_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: ev_cal_members ev_cal_members_cal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ev_cal_members
    ADD CONSTRAINT ev_cal_members_cal_id_fkey FOREIGN KEY (cal_id) REFERENCES public.ev_cals(id) ON DELETE CASCADE;


--
-- Name: ev_cal_members ev_cal_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ev_cal_members
    ADD CONSTRAINT ev_cal_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ev_cals ev_cals_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ev_cals
    ADD CONSTRAINT ev_cals_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE SET NULL;


--
-- Name: ev_cals ev_cals_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ev_cals
    ADD CONSTRAINT ev_cals_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ev_reminded ev_reminded_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ev_reminded
    ADD CONSTRAINT ev_reminded_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: event_attendees event_attendees_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_attendees
    ADD CONSTRAINT event_attendees_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id) ON DELETE SET NULL;


--
-- Name: event_attendees event_attendees_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_attendees
    ADD CONSTRAINT event_attendees_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: event_attendees event_attendees_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_attendees
    ADD CONSTRAINT event_attendees_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: events events_cal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_cal_id_fkey FOREIGN KEY (cal_id) REFERENCES public.ev_cals(id) ON DELETE CASCADE;


--
-- Name: events events_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: file_text file_text_att_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_text
    ADD CONSTRAINT file_text_att_id_fkey FOREIGN KEY (att_id) REFERENCES public.attachments(id) ON DELETE CASCADE;


--
-- Name: file_text file_text_list_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_text
    ADD CONSTRAINT file_text_list_file_id_fkey FOREIGN KEY (list_file_id) REFERENCES public.list_files(id) ON DELETE CASCADE;


--
-- Name: file_text file_text_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_text
    ADD CONSTRAINT file_text_node_id_fkey FOREIGN KEY (node_id) REFERENCES public.fs_nodes(id) ON DELETE CASCADE;


--
-- Name: file_text file_text_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_text
    ADD CONSTRAINT file_text_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: file_words file_words_ft_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_words
    ADD CONSTRAINT file_words_ft_id_fkey FOREIGN KEY (ft_id) REFERENCES public.file_text(id) ON DELETE CASCADE;


--
-- Name: folder_agents folder_agents_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folder_agents
    ADD CONSTRAINT folder_agents_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: folder_agents folder_agents_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folder_agents
    ADD CONSTRAINT folder_agents_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: folder_heads folder_heads_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folder_heads
    ADD CONSTRAINT folder_heads_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: folder_notif folder_notif_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folder_notif
    ADD CONSTRAINT folder_notif_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: folder_people folder_people_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folder_people
    ADD CONSTRAINT folder_people_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: folder_people folder_people_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folder_people
    ADD CONSTRAINT folder_people_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: folder_props folder_props_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folder_props
    ADD CONSTRAINT folder_props_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: forms forms_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forms
    ADD CONSTRAINT forms_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: fs_log fs_log_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fs_log
    ADD CONSTRAINT fs_log_node_id_fkey FOREIGN KEY (node_id) REFERENCES public.fs_nodes(id) ON DELETE CASCADE;


--
-- Name: fs_nodes fs_nodes_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fs_nodes
    ADD CONSTRAINT fs_nodes_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: fs_nodes fs_nodes_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fs_nodes
    ADD CONSTRAINT fs_nodes_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: fs_nodes fs_nodes_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fs_nodes
    ADD CONSTRAINT fs_nodes_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: fs_nodes fs_nodes_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fs_nodes
    ADD CONSTRAINT fs_nodes_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.fs_nodes(id) ON DELETE CASCADE;


--
-- Name: fs_shares fs_shares_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fs_shares
    ADD CONSTRAINT fs_shares_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: fs_shares fs_shares_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fs_shares
    ADD CONSTRAINT fs_shares_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: fs_shares fs_shares_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fs_shares
    ADD CONSTRAINT fs_shares_node_id_fkey FOREIGN KEY (node_id) REFERENCES public.fs_nodes(id) ON DELETE CASCADE;


--
-- Name: fs_shares fs_shares_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fs_shares
    ADD CONSTRAINT fs_shares_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: fs_versions fs_versions_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fs_versions
    ADD CONSTRAINT fs_versions_node_id_fkey FOREIGN KEY (node_id) REFERENCES public.fs_nodes(id) ON DELETE CASCADE;


--
-- Name: git_closes git_closes_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.git_closes
    ADD CONSTRAINT git_closes_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: git_commits git_commits_conn_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.git_commits
    ADD CONSTRAINT git_commits_conn_id_fkey FOREIGN KEY (conn_id) REFERENCES public.git_conns(id) ON DELETE CASCADE;


--
-- Name: git_conns git_conns_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.git_conns
    ADD CONSTRAINT git_conns_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: git_folders git_folders_conn_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.git_folders
    ADD CONSTRAINT git_folders_conn_id_fkey FOREIGN KEY (conn_id) REFERENCES public.git_conns(id) ON DELETE CASCADE;


--
-- Name: git_folders git_folders_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.git_folders
    ADD CONSTRAINT git_folders_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: git_links git_links_conn_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.git_links
    ADD CONSTRAINT git_links_conn_id_fkey FOREIGN KEY (conn_id) REFERENCES public.git_conns(id) ON DELETE CASCADE;


--
-- Name: git_links git_links_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.git_links
    ADD CONSTRAINT git_links_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: git_prs git_prs_conn_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.git_prs
    ADD CONSTRAINT git_prs_conn_id_fkey FOREIGN KEY (conn_id) REFERENCES public.git_conns(id) ON DELETE CASCADE;


--
-- Name: git_tags git_tags_conn_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.git_tags
    ADD CONSTRAINT git_tags_conn_id_fkey FOREIGN KEY (conn_id) REFERENCES public.git_conns(id) ON DELETE CASCADE;


--
-- Name: group_members group_members_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: group_members group_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: group_shares group_shares_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_shares
    ADD CONSTRAINT group_shares_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: group_shares group_shares_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_shares
    ADD CONSTRAINT group_shares_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: group_shares group_shares_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_shares
    ADD CONSTRAINT group_shares_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: habit_logs habit_logs_habit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.habit_logs
    ADD CONSTRAINT habit_logs_habit_id_fkey FOREIGN KEY (habit_id) REFERENCES public.habits(id) ON DELETE CASCADE;


--
-- Name: hub_absences hub_absences_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hub_absences
    ADD CONSTRAINT hub_absences_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: hub_absences hub_absences_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hub_absences
    ADD CONSTRAINT hub_absences_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: hub_absences hub_absences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hub_absences
    ADD CONSTRAINT hub_absences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: hub_bookings hub_bookings_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hub_bookings
    ADD CONSTRAINT hub_bookings_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: hub_bookings hub_bookings_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hub_bookings
    ADD CONSTRAINT hub_bookings_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE SET NULL;


--
-- Name: hub_bookings hub_bookings_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hub_bookings
    ADD CONSTRAINT hub_bookings_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE SET NULL;


--
-- Name: hub_bookings hub_bookings_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hub_bookings
    ADD CONSTRAINT hub_bookings_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: hub_mails hub_mails_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hub_mails
    ADD CONSTRAINT hub_mails_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: hub_mails hub_mails_eml_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hub_mails
    ADD CONSTRAINT hub_mails_eml_id_fkey FOREIGN KEY (eml_id) REFERENCES public.fs_nodes(id) ON DELETE SET NULL;


--
-- Name: hub_mails hub_mails_folder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hub_mails
    ADD CONSTRAINT hub_mails_folder_id_fkey FOREIGN KEY (folder_id) REFERENCES public.fs_nodes(id) ON DELETE SET NULL;


--
-- Name: hub_mails hub_mails_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hub_mails
    ADD CONSTRAINT hub_mails_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE SET NULL;


--
-- Name: hub_mails hub_mails_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hub_mails
    ADD CONSTRAINT hub_mails_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: hub_mails hub_mails_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hub_mails
    ADD CONSTRAINT hub_mails_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: hub_tokens hub_tokens_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hub_tokens
    ADD CONSTRAINT hub_tokens_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: hub_tokens hub_tokens_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hub_tokens
    ADD CONSTRAINT hub_tokens_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: hub_tokens hub_tokens_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hub_tokens
    ADD CONSTRAINT hub_tokens_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: hub_tokens hub_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hub_tokens
    ADD CONSTRAINT hub_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: hub_words hub_words_mail_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hub_words
    ADD CONSTRAINT hub_words_mail_id_fkey FOREIGN KEY (mail_id) REFERENCES public.hub_mails(id) ON DELETE CASCADE;


--
-- Name: imports imports_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imports
    ADD CONSTRAINT imports_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: issue_hooks issue_hooks_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_hooks
    ADD CONSTRAINT issue_hooks_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: issue_reports issue_reports_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_reports
    ADD CONSTRAINT issue_reports_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: issue_reports issue_reports_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_reports
    ADD CONSTRAINT issue_reports_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: journal journal_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal
    ADD CONSTRAINT journal_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: kid_parents kid_parents_kid_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kid_parents
    ADD CONSTRAINT kid_parents_kid_id_fkey FOREIGN KEY (kid_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: kid_parents kid_parents_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kid_parents
    ADD CONSTRAINT kid_parents_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: kid_pin_open kid_pin_open_kid_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kid_pin_open
    ADD CONSTRAINT kid_pin_open_kid_id_fkey FOREIGN KEY (kid_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: kid_pin_open kid_pin_open_token_hash_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kid_pin_open
    ADD CONSTRAINT kid_pin_open_token_hash_fkey FOREIGN KEY (token_hash) REFERENCES public.sessions(token_hash) ON DELETE CASCADE;


--
-- Name: kid_pins kid_pins_kid_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kid_pins
    ADD CONSTRAINT kid_pins_kid_id_fkey FOREIGN KEY (kid_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: kid_pins kid_pins_set_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kid_pins
    ADD CONSTRAINT kid_pins_set_by_fkey FOREIGN KEY (set_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: kid_rewards kid_rewards_kid_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kid_rewards
    ADD CONSTRAINT kid_rewards_kid_id_fkey FOREIGN KEY (kid_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: kid_stars kid_stars_kid_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kid_stars
    ADD CONSTRAINT kid_stars_kid_id_fkey FOREIGN KEY (kid_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: kid_stars kid_stars_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kid_stars
    ADD CONSTRAINT kid_stars_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: kk_conns kk_conns_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kk_conns
    ADD CONSTRAINT kk_conns_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: list_activity list_activity_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_activity
    ADD CONSTRAINT list_activity_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: list_bell list_bell_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_bell
    ADD CONSTRAINT list_bell_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: list_envs list_envs_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_envs
    ADD CONSTRAINT list_envs_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: list_fields list_fields_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_fields
    ADD CONSTRAINT list_fields_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: list_files list_files_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_files
    ADD CONSTRAINT list_files_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: list_key_pending list_key_pending_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_key_pending
    ADD CONSTRAINT list_key_pending_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: list_key_pending list_key_pending_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_key_pending
    ADD CONSTRAINT list_key_pending_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: list_keys list_keys_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_keys
    ADD CONSTRAINT list_keys_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: list_keys list_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_keys
    ADD CONSTRAINT list_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: list_keys list_keys_wrapped_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_keys
    ADD CONSTRAINT list_keys_wrapped_by_fkey FOREIGN KEY (wrapped_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: list_layouts list_layouts_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_layouts
    ADD CONSTRAINT list_layouts_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: list_layouts list_layouts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_layouts
    ADD CONSTRAINT list_layouts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: list_links list_links_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_links
    ADD CONSTRAINT list_links_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: list_members list_members_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_members
    ADD CONSTRAINT list_members_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: list_members list_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_members
    ADD CONSTRAINT list_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: list_milestones list_milestones_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_milestones
    ADD CONSTRAINT list_milestones_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: list_mine_hide list_mine_hide_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_mine_hide
    ADD CONSTRAINT list_mine_hide_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: list_mine_hide list_mine_hide_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_mine_hide
    ADD CONSTRAINT list_mine_hide_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: list_notepads list_notepads_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_notepads
    ADD CONSTRAINT list_notepads_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: list_notepads list_notepads_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_notepads
    ADD CONSTRAINT list_notepads_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: list_notif list_notif_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_notif
    ADD CONSTRAINT list_notif_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: list_paperless list_paperless_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_paperless
    ADD CONSTRAINT list_paperless_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: list_rule_runs list_rule_runs_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_rule_runs
    ADD CONSTRAINT list_rule_runs_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.list_rules(id) ON DELETE CASCADE;


--
-- Name: list_rule_runs list_rule_runs_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_rule_runs
    ADD CONSTRAINT list_rule_runs_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: list_rules list_rules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_rules
    ADD CONSTRAINT list_rules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: list_rules list_rules_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_rules
    ADD CONSTRAINT list_rules_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: list_rules list_rules_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_rules
    ADD CONSTRAINT list_rules_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE SET NULL;


--
-- Name: list_rules list_rules_target_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_rules
    ADD CONSTRAINT list_rules_target_list_id_fkey FOREIGN KEY (target_list_id) REFERENCES public.lists(id) ON DELETE SET NULL;


--
-- Name: list_status list_status_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_status
    ADD CONSTRAINT list_status_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: list_status list_status_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_status
    ADD CONSTRAINT list_status_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: list_tags list_tags_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.list_tags
    ADD CONSTRAINT list_tags_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: lists lists_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lists
    ADD CONSTRAINT lists_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE SET NULL;


--
-- Name: login_ips login_ips_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_ips
    ADD CONSTRAINT login_ips_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mail_tokens mail_tokens_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mail_tokens
    ADD CONSTRAINT mail_tokens_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: mail_tokens mail_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mail_tokens
    ADD CONSTRAINT mail_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: merge_runs merge_runs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.merge_runs
    ADD CONSTRAINT merge_runs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: merge_runs merge_runs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.merge_runs
    ADD CONSTRAINT merge_runs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: msv_links msv_links_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.msv_links
    ADD CONSTRAINT msv_links_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: nl_conns nl_conns_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nl_conns
    ADD CONSTRAINT nl_conns_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: nl_conns nl_conns_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nl_conns
    ADD CONSTRAINT nl_conns_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: nl_members nl_members_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nl_members
    ADD CONSTRAINT nl_members_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: nl_members nl_members_seg_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nl_members
    ADD CONSTRAINT nl_members_seg_id_fkey FOREIGN KEY (seg_id) REFERENCES public.nl_segments(id) ON DELETE CASCADE;


--
-- Name: nl_runs nl_runs_conn_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nl_runs
    ADD CONSTRAINT nl_runs_conn_id_fkey FOREIGN KEY (conn_id) REFERENCES public.nl_conns(id) ON DELETE CASCADE;


--
-- Name: nl_runs nl_runs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nl_runs
    ADD CONSTRAINT nl_runs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: nl_segments nl_segments_conn_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nl_segments
    ADD CONSTRAINT nl_segments_conn_id_fkey FOREIGN KEY (conn_id) REFERENCES public.nl_conns(id) ON DELETE CASCADE;


--
-- Name: nl_segments nl_segments_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nl_segments
    ADD CONSTRAINT nl_segments_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: notes notes_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: notifications notifications_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE SET NULL;


--
-- Name: notifications notifications_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: office_agreements office_agreements_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_agreements
    ADD CONSTRAINT office_agreements_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_archive office_archive_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_archive
    ADD CONSTRAINT office_archive_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: office_archive_log office_archive_log_archive_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_archive_log
    ADD CONSTRAINT office_archive_log_archive_id_fkey FOREIGN KEY (archive_id) REFERENCES public.office_archive(id) ON DELETE CASCADE;


--
-- Name: office_archive_log office_archive_log_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_archive_log
    ADD CONSTRAINT office_archive_log_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_archive_log office_archive_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_archive_log
    ADD CONSTRAINT office_archive_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: office_archive office_archive_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_archive
    ADD CONSTRAINT office_archive_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_archive office_archive_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_archive
    ADD CONSTRAINT office_archive_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.office_import_runs(id) ON DELETE SET NULL;


--
-- Name: office_bank_imports office_bank_imports_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_bank_imports
    ADD CONSTRAINT office_bank_imports_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_bank_tx office_bank_tx_import_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_bank_tx
    ADD CONSTRAINT office_bank_tx_import_id_fkey FOREIGN KEY (import_id) REFERENCES public.office_bank_imports(id) ON DELETE SET NULL;


--
-- Name: office_bank_tx office_bank_tx_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_bank_tx
    ADD CONSTRAINT office_bank_tx_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_client_contacts office_client_contacts_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_client_contacts
    ADD CONSTRAINT office_client_contacts_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: office_client_contacts office_client_contacts_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_client_contacts
    ADD CONSTRAINT office_client_contacts_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id) ON DELETE SET NULL;


--
-- Name: office_client_contacts office_client_contacts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_client_contacts
    ADD CONSTRAINT office_client_contacts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE SET NULL;


--
-- Name: office_company office_company_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_company
    ADD CONSTRAINT office_company_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_contracts office_contracts_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_contracts
    ADD CONSTRAINT office_contracts_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: office_contracts office_contracts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_contracts
    ADD CONSTRAINT office_contracts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_contracts office_contracts_rights_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_contracts
    ADD CONSTRAINT office_contracts_rights_media_id_fkey FOREIGN KEY (rights_media_id) REFERENCES public.office_texts(id) ON DELETE SET NULL;


--
-- Name: office_contracts office_contracts_rights_territory_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_contracts
    ADD CONSTRAINT office_contracts_rights_territory_id_fkey FOREIGN KEY (rights_territory_id) REFERENCES public.office_texts(id) ON DELETE SET NULL;


--
-- Name: office_contracts office_contracts_rights_time_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_contracts
    ADD CONSTRAINT office_contracts_rights_time_id_fkey FOREIGN KEY (rights_time_id) REFERENCES public.office_texts(id) ON DELETE SET NULL;


--
-- Name: office_deals office_deals_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_deals
    ADD CONSTRAINT office_deals_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: office_deals office_deals_lead_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_deals
    ADD CONSTRAINT office_deals_lead_client_id_fkey FOREIGN KEY (lead_client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: office_deals office_deals_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_deals
    ADD CONSTRAINT office_deals_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE SET NULL;


--
-- Name: office_deals office_deals_offer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_deals
    ADD CONSTRAINT office_deals_offer_id_fkey FOREIGN KEY (offer_id) REFERENCES public.office_docs(id) ON DELETE SET NULL;


--
-- Name: office_deals office_deals_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_deals
    ADD CONSTRAINT office_deals_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_doc_items office_doc_items_doc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_doc_items
    ADD CONSTRAINT office_doc_items_doc_id_fkey FOREIGN KEY (doc_id) REFERENCES public.office_docs(id) ON DELETE CASCADE;


--
-- Name: office_doc_items office_doc_items_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_doc_items
    ADD CONSTRAINT office_doc_items_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_doc_items office_doc_items_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_doc_items
    ADD CONSTRAINT office_doc_items_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.office_services(id) ON DELETE SET NULL;


--
-- Name: office_doc_log office_doc_log_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_doc_log
    ADD CONSTRAINT office_doc_log_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_doc_log office_doc_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_doc_log
    ADD CONSTRAINT office_doc_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: office_doc_parts office_doc_parts_doc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_doc_parts
    ADD CONSTRAINT office_doc_parts_doc_id_fkey FOREIGN KEY (doc_id) REFERENCES public.office_docs(id) ON DELETE CASCADE;


--
-- Name: office_doc_parts office_doc_parts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_doc_parts
    ADD CONSTRAINT office_doc_parts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_doc_templates office_doc_templates_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_doc_templates
    ADD CONSTRAINT office_doc_templates_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_docs office_docs_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_docs
    ADD CONSTRAINT office_docs_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: office_docs office_docs_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_docs
    ADD CONSTRAINT office_docs_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES public.office_contracts(id) ON DELETE SET NULL;


--
-- Name: office_docs office_docs_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_docs
    ADD CONSTRAINT office_docs_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE SET NULL;


--
-- Name: office_docs office_docs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_docs
    ADD CONSTRAINT office_docs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_drive_log office_drive_log_drive_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_drive_log
    ADD CONSTRAINT office_drive_log_drive_id_fkey FOREIGN KEY (drive_id) REFERENCES public.office_drives(id) ON DELETE CASCADE;


--
-- Name: office_drive_log office_drive_log_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_drive_log
    ADD CONSTRAINT office_drive_log_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_drives office_drives_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_drives
    ADD CONSTRAINT office_drives_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: office_drives office_drives_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_drives
    ADD CONSTRAINT office_drives_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_drives office_drives_trip_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_drives
    ADD CONSTRAINT office_drives_trip_id_fkey FOREIGN KEY (trip_id) REFERENCES public.office_trips(id) ON DELETE SET NULL;


--
-- Name: office_drives office_drives_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_drives
    ADD CONSTRAINT office_drives_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.office_vehicles(id) ON DELETE SET NULL;


--
-- Name: office_equipment office_equipment_agreement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_equipment
    ADD CONSTRAINT office_equipment_agreement_id_fkey FOREIGN KEY (agreement_id) REFERENCES public.office_agreements(id) ON DELETE SET NULL;


--
-- Name: office_equipment office_equipment_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_equipment
    ADD CONSTRAINT office_equipment_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_fixed_costs office_fixed_costs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_fixed_costs
    ADD CONSTRAINT office_fixed_costs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_gen_docs office_gen_docs_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_gen_docs
    ADD CONSTRAINT office_gen_docs_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: office_gen_docs office_gen_docs_doc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_gen_docs
    ADD CONSTRAINT office_gen_docs_doc_id_fkey FOREIGN KEY (doc_id) REFERENCES public.office_docs(id) ON DELETE SET NULL;


--
-- Name: office_gen_docs office_gen_docs_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_gen_docs
    ADD CONSTRAINT office_gen_docs_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE SET NULL;


--
-- Name: office_gen_docs office_gen_docs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_gen_docs
    ADD CONSTRAINT office_gen_docs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_gen_docs office_gen_docs_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_gen_docs
    ADD CONSTRAINT office_gen_docs_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.office_doc_templates(id) ON DELETE SET NULL;


--
-- Name: office_import_runs office_import_runs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_import_runs
    ADD CONSTRAINT office_import_runs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_inv_series office_inv_series_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_inv_series
    ADD CONSTRAINT office_inv_series_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_inv_series office_inv_series_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_inv_series
    ADD CONSTRAINT office_inv_series_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.office_docs(id) ON DELETE SET NULL;


--
-- Name: office_numbers office_numbers_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_numbers
    ADD CONSTRAINT office_numbers_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_pack_installs office_pack_installs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_pack_installs
    ADD CONSTRAINT office_pack_installs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_pay_props office_pay_props_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_pay_props
    ADD CONSTRAINT office_pay_props_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: office_pay_props office_pay_props_doc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_pay_props
    ADD CONSTRAINT office_pay_props_doc_id_fkey FOREIGN KEY (doc_id) REFERENCES public.office_docs(id) ON DELETE CASCADE;


--
-- Name: office_pay_props office_pay_props_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_pay_props
    ADD CONSTRAINT office_pay_props_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_payments office_payments_doc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_payments
    ADD CONSTRAINT office_payments_doc_id_fkey FOREIGN KEY (doc_id) REFERENCES public.office_docs(id) ON DELETE CASCADE;


--
-- Name: office_payments office_payments_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_payments
    ADD CONSTRAINT office_payments_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_purchases office_purchases_doc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_purchases
    ADD CONSTRAINT office_purchases_doc_id_fkey FOREIGN KEY (doc_id) REFERENCES public.office_docs(id) ON DELETE CASCADE;


--
-- Name: office_purchases office_purchases_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_purchases
    ADD CONSTRAINT office_purchases_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_roles office_roles_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_roles
    ADD CONSTRAINT office_roles_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_services office_services_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_services
    ADD CONSTRAINT office_services_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_sets office_sets_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_sets
    ADD CONSTRAINT office_sets_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_settings office_settings_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_settings
    ADD CONSTRAINT office_settings_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_signoffs office_signoffs_doc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_signoffs
    ADD CONSTRAINT office_signoffs_doc_id_fkey FOREIGN KEY (doc_id) REFERENCES public.office_docs(id) ON DELETE CASCADE;


--
-- Name: office_signoffs office_signoffs_gen_doc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_signoffs
    ADD CONSTRAINT office_signoffs_gen_doc_id_fkey FOREIGN KEY (gen_doc_id) REFERENCES public.office_gen_docs(id) ON DELETE CASCADE;


--
-- Name: office_signoffs office_signoffs_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_signoffs
    ADD CONSTRAINT office_signoffs_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: office_signoffs office_signoffs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_signoffs
    ADD CONSTRAINT office_signoffs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_signoffs office_signoffs_video_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_signoffs
    ADD CONSTRAINT office_signoffs_video_id_fkey FOREIGN KEY (video_id) REFERENCES public.video_reviews(id) ON DELETE CASCADE;


--
-- Name: office_sub_reminders office_sub_reminders_fixed_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_sub_reminders
    ADD CONSTRAINT office_sub_reminders_fixed_id_fkey FOREIGN KEY (fixed_id) REFERENCES public.office_fixed_costs(id) ON DELETE CASCADE;


--
-- Name: office_sub_reminders office_sub_reminders_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_sub_reminders
    ADD CONSTRAINT office_sub_reminders_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_texts office_texts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_texts
    ADD CONSTRAINT office_texts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_trip_items office_trip_items_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_trip_items
    ADD CONSTRAINT office_trip_items_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_trip_items office_trip_items_trip_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_trip_items
    ADD CONSTRAINT office_trip_items_trip_id_fkey FOREIGN KEY (trip_id) REFERENCES public.office_trips(id) ON DELETE CASCADE;


--
-- Name: office_trips office_trips_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_trips
    ADD CONSTRAINT office_trips_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: office_trips office_trips_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_trips
    ADD CONSTRAINT office_trips_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: office_vehicles office_vehicles_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_vehicles
    ADD CONSTRAINT office_vehicles_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: org_keys org_keys_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_keys
    ADD CONSTRAINT org_keys_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: org_list_log org_list_log_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_list_log
    ADD CONSTRAINT org_list_log_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: org_members org_members_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: org_members org_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: orgs orgs_personal_of_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgs
    ADD CONSTRAINT orgs_personal_of_fkey FOREIGN KEY (personal_of) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: paperless_links paperless_links_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paperless_links
    ADD CONSTRAINT paperless_links_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: pl_conn_users pl_conn_users_conn_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pl_conn_users
    ADD CONSTRAINT pl_conn_users_conn_id_fkey FOREIGN KEY (conn_id) REFERENCES public.pl_conns(id) ON DELETE CASCADE;


--
-- Name: pl_imported pl_imported_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pl_imported
    ADD CONSTRAINT pl_imported_node_id_fkey FOREIGN KEY (node_id) REFERENCES public.fs_nodes(id) ON DELETE SET NULL;


--
-- Name: pl_imported pl_imported_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pl_imported
    ADD CONSTRAINT pl_imported_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: pl_rules pl_rules_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pl_rules
    ADD CONSTRAINT pl_rules_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: pl_rules pl_rules_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pl_rules
    ADD CONSTRAINT pl_rules_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.doc_rules(id) ON DELETE SET NULL;


--
-- Name: pl_sources pl_sources_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pl_sources
    ADD CONSTRAINT pl_sources_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: pl_tokens pl_tokens_conn_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pl_tokens
    ADD CONSTRAINT pl_tokens_conn_id_fkey FOREIGN KEY (conn_id) REFERENCES public.pl_conns(id) ON DELETE CASCADE;


--
-- Name: pl_uploads pl_uploads_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pl_uploads
    ADD CONSTRAINT pl_uploads_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: playbook_proposals playbook_proposals_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playbook_proposals
    ADD CONSTRAINT playbook_proposals_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: playbook_proposals playbook_proposals_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playbook_proposals
    ADD CONSTRAINT playbook_proposals_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: playbooks playbooks_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playbooks
    ADD CONSTRAINT playbooks_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: playbooks playbooks_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playbooks
    ADD CONSTRAINT playbooks_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: pomos pomos_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pomos
    ADD CONSTRAINT pomos_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: portal_logins portal_logins_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_logins
    ADD CONSTRAINT portal_logins_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: portal_tickets portal_tickets_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_tickets
    ADD CONSTRAINT portal_tickets_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: portal_tickets portal_tickets_form_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_tickets
    ADD CONSTRAINT portal_tickets_form_id_fkey FOREIGN KEY (form_id) REFERENCES public.forms(id) ON DELETE SET NULL;


--
-- Name: portal_tickets portal_tickets_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_tickets
    ADD CONSTRAINT portal_tickets_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: portal_tickets portal_tickets_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_tickets
    ADD CONSTRAINT portal_tickets_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: portal_tickets portal_tickets_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_tickets
    ADD CONSTRAINT portal_tickets_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: public_links public_links_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.public_links
    ADD CONSTRAINT public_links_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: push_subs push_subs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subs
    ADD CONSTRAINT push_subs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: push_tags push_tags_sub_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_tags
    ADD CONSTRAINT push_tags_sub_id_fkey FOREIGN KEY (sub_id) REFERENCES public.push_subs(id) ON DELETE CASCADE;


--
-- Name: rc_receipts rc_receipts_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rc_receipts
    ADD CONSTRAINT rc_receipts_node_id_fkey FOREIGN KEY (node_id) REFERENCES public.fs_nodes(id) ON DELETE CASCADE;


--
-- Name: rc_receipts rc_receipts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rc_receipts
    ADD CONSTRAINT rc_receipts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: rc_suggest rc_suggest_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rc_suggest
    ADD CONSTRAINT rc_suggest_node_id_fkey FOREIGN KEY (node_id) REFERENCES public.fs_nodes(id) ON DELETE CASCADE;


--
-- Name: rc_suggest rc_suggest_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rc_suggest
    ADD CONSTRAINT rc_suggest_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: recovery_codes recovery_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recovery_codes
    ADD CONSTRAINT recovery_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: rss_feeds rss_feeds_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rss_feeds
    ADD CONSTRAINT rss_feeds_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: rss_items rss_items_feed_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rss_items
    ADD CONSTRAINT rss_items_feed_id_fkey FOREIGN KEY (feed_id) REFERENCES public.rss_feeds(id) ON DELETE CASCADE;


--
-- Name: rss_items rss_items_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rss_items
    ADD CONSTRAINT rss_items_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: sample_items sample_items_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sample_items
    ADD CONSTRAINT sample_items_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: sections sections_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sections
    ADD CONSTRAINT sections_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: sheet_cells sheet_cells_col_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheet_cells
    ADD CONSTRAINT sheet_cells_col_id_fkey FOREIGN KEY (col_id) REFERENCES public.sheet_columns(id) ON DELETE CASCADE;


--
-- Name: sheet_cells sheet_cells_row_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheet_cells
    ADD CONSTRAINT sheet_cells_row_id_fkey FOREIGN KEY (row_id) REFERENCES public.sheet_rows(id) ON DELETE CASCADE;


--
-- Name: sheet_cells sheet_cells_sheet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheet_cells
    ADD CONSTRAINT sheet_cells_sheet_id_fkey FOREIGN KEY (sheet_id) REFERENCES public.sheets(id) ON DELETE CASCADE;


--
-- Name: sheet_cells sheet_cells_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheet_cells
    ADD CONSTRAINT sheet_cells_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: sheet_changes sheet_changes_sheet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheet_changes
    ADD CONSTRAINT sheet_changes_sheet_id_fkey FOREIGN KEY (sheet_id) REFERENCES public.sheets(id) ON DELETE CASCADE;


--
-- Name: sheet_columns sheet_columns_sheet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheet_columns
    ADD CONSTRAINT sheet_columns_sheet_id_fkey FOREIGN KEY (sheet_id) REFERENCES public.sheets(id) ON DELETE CASCADE;


--
-- Name: sheet_lastvals sheet_lastvals_cell_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheet_lastvals
    ADD CONSTRAINT sheet_lastvals_cell_id_fkey FOREIGN KEY (cell_id) REFERENCES public.sheet_cells(id) ON DELETE CASCADE;


--
-- Name: sheet_lastvals sheet_lastvals_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheet_lastvals
    ADD CONSTRAINT sheet_lastvals_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: sheet_links sheet_links_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheet_links
    ADD CONSTRAINT sheet_links_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: sheet_links sheet_links_row_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheet_links
    ADD CONSTRAINT sheet_links_row_id_fkey FOREIGN KEY (row_id) REFERENCES public.sheet_rows(id) ON DELETE CASCADE;


--
-- Name: sheet_links sheet_links_sheet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheet_links
    ADD CONSTRAINT sheet_links_sheet_id_fkey FOREIGN KEY (sheet_id) REFERENCES public.sheets(id) ON DELETE CASCADE;


--
-- Name: sheet_rows sheet_rows_sheet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheet_rows
    ADD CONSTRAINT sheet_rows_sheet_id_fkey FOREIGN KEY (sheet_id) REFERENCES public.sheets(id) ON DELETE CASCADE;


--
-- Name: sheets sheets_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheets
    ADD CONSTRAINT sheets_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: sheets sheets_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheets
    ADD CONSTRAINT sheets_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE SET NULL;


--
-- Name: sheets sheets_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheets
    ADD CONSTRAINT sheets_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: sheets sheets_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheets
    ADD CONSTRAINT sheets_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: sheets sheets_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheets
    ADD CONSTRAINT sheets_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: shop_memory shop_memory_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_memory
    ADD CONSTRAINT shop_memory_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: shop_memory shop_memory_section_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_memory
    ADD CONSTRAINT shop_memory_section_id_fkey FOREIGN KEY (section_id) REFERENCES public.sections(id) ON DELETE CASCADE;


--
-- Name: space_moves space_moves_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.space_moves
    ADD CONSTRAINT space_moves_by_id_fkey FOREIGN KEY (by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: sprints sprints_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sprints
    ADD CONSTRAINT sprints_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: task_bell task_bell_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_bell
    ADD CONSTRAINT task_bell_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: task_bell task_bell_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_bell
    ADD CONSTRAINT task_bell_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_bell task_bell_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_bell
    ADD CONSTRAINT task_bell_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: task_deps task_deps_blocker_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_deps
    ADD CONSTRAINT task_deps_blocker_id_fkey FOREIGN KEY (blocker_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_deps task_deps_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_deps
    ADD CONSTRAINT task_deps_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_enc_notes task_enc_notes_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_enc_notes
    ADD CONSTRAINT task_enc_notes_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_enc_notes task_enc_notes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_enc_notes
    ADD CONSTRAINT task_enc_notes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: task_field_values task_field_values_field_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_field_values
    ADD CONSTRAINT task_field_values_field_id_fkey FOREIGN KEY (field_id) REFERENCES public.list_fields(id) ON DELETE CASCADE;


--
-- Name: task_field_values task_field_values_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_field_values
    ADD CONSTRAINT task_field_values_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_links task_links_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_links
    ADD CONSTRAINT task_links_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: task_links task_links_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_links
    ADD CONSTRAINT task_links_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: task_links task_links_section_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_links
    ADD CONSTRAINT task_links_section_id_fkey FOREIGN KEY (section_id) REFERENCES public.sections(id) ON DELETE SET NULL;


--
-- Name: task_links task_links_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_links
    ADD CONSTRAINT task_links_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_list_tags task_list_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_list_tags
    ADD CONSTRAINT task_list_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.list_tags(id) ON DELETE CASCADE;


--
-- Name: task_list_tags task_list_tags_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_list_tags
    ADD CONSTRAINT task_list_tags_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_note_locks task_note_locks_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_note_locks
    ADD CONSTRAINT task_note_locks_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_note_locks task_note_locks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_note_locks
    ADD CONSTRAINT task_note_locks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: task_people task_people_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_people
    ADD CONSTRAINT task_people_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_people task_people_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_people
    ADD CONSTRAINT task_people_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: task_push task_push_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_push
    ADD CONSTRAINT task_push_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_push task_push_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_push
    ADD CONSTRAINT task_push_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: task_seen task_seen_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_seen
    ADD CONSTRAINT task_seen_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_seen task_seen_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_seen
    ADD CONSTRAINT task_seen_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: task_tags task_tags_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_tags
    ADD CONSTRAINT task_tags_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_vectors task_vectors_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_vectors
    ADD CONSTRAINT task_vectors_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: task_vectors task_vectors_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_vectors
    ADD CONSTRAINT task_vectors_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_section_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_section_id_fkey FOREIGN KEY (section_id) REFERENCES public.sections(id) ON DELETE SET NULL;


--
-- Name: tchat_msgs tchat_msgs_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tchat_msgs
    ADD CONSTRAINT tchat_msgs_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.tchat_rooms(id) ON DELETE CASCADE;


--
-- Name: tchat_msgs tchat_msgs_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tchat_msgs
    ADD CONSTRAINT tchat_msgs_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: tchat_msgs tchat_msgs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tchat_msgs
    ADD CONSTRAINT tchat_msgs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tchat_reads tchat_reads_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tchat_reads
    ADD CONSTRAINT tchat_reads_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.tchat_rooms(id) ON DELETE CASCADE;


--
-- Name: tchat_reads tchat_reads_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tchat_reads
    ADD CONSTRAINT tchat_reads_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tchat_rooms tchat_rooms_a_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tchat_rooms
    ADD CONSTRAINT tchat_rooms_a_fkey FOREIGN KEY (a) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tchat_rooms tchat_rooms_b_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tchat_rooms
    ADD CONSTRAINT tchat_rooms_b_fkey FOREIGN KEY (b) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tchat_rooms tchat_rooms_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tchat_rooms
    ADD CONSTRAINT tchat_rooms_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: tchat_rx tchat_rx_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tchat_rx
    ADD CONSTRAINT tchat_rx_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.tchat_msgs(id) ON DELETE CASCADE;


--
-- Name: tchat_rx tchat_rx_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tchat_rx
    ADD CONSTRAINT tchat_rx_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: templates templates_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT templates_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tidy_pending tidy_pending_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tidy_pending
    ADD CONSTRAINT tidy_pending_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: time_entries time_entries_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE SET NULL;


--
-- Name: time_entries time_entries_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: time_entries time_entries_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: upload_scan upload_scan_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.upload_scan
    ADD CONSTRAINT upload_scan_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: user_invites user_invites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_invites
    ADD CONSTRAINT user_invites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_keys user_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_keys
    ADD CONSTRAINT user_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_settings user_settings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_settings
    ADD CONSTRAINT user_settings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_task_order user_task_order_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_task_order
    ADD CONSTRAINT user_task_order_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: user_task_order user_task_order_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_task_order
    ADD CONSTRAINT user_task_order_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: video_comments video_comments_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.video_comments
    ADD CONSTRAINT video_comments_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: video_comments video_comments_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.video_comments
    ADD CONSTRAINT video_comments_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: video_comments video_comments_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.video_comments
    ADD CONSTRAINT video_comments_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.video_comments(id) ON DELETE CASCADE;


--
-- Name: video_comments video_comments_review_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.video_comments
    ADD CONSTRAINT video_comments_review_id_fkey FOREIGN KEY (review_id) REFERENCES public.video_reviews(id) ON DELETE CASCADE;


--
-- Name: video_comments video_comments_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.video_comments
    ADD CONSTRAINT video_comments_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.video_versions(id) ON DELETE CASCADE;


--
-- Name: video_reviews video_reviews_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.video_reviews
    ADD CONSTRAINT video_reviews_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: video_reviews video_reviews_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.video_reviews
    ADD CONSTRAINT video_reviews_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.lists(id) ON DELETE CASCADE;


--
-- Name: video_reviews video_reviews_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.video_reviews
    ADD CONSTRAINT video_reviews_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: video_reviews video_reviews_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.video_reviews
    ADD CONSTRAINT video_reviews_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: video_reviews video_reviews_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.video_reviews
    ADD CONSTRAINT video_reviews_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: video_versions video_versions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.video_versions
    ADD CONSTRAINT video_versions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: video_versions video_versions_review_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.video_versions
    ADD CONSTRAINT video_versions_review_id_fkey FOREIGN KEY (review_id) REFERENCES public.video_reviews(id) ON DELETE CASCADE;


--
-- Name: view_layout_offers view_layout_offers_from_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.view_layout_offers
    ADD CONSTRAINT view_layout_offers_from_user_fkey FOREIGN KEY (from_user) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: view_layout_offers view_layout_offers_to_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.view_layout_offers
    ADD CONSTRAINT view_layout_offers_to_user_fkey FOREIGN KEY (to_user) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: view_layouts view_layouts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.view_layouts
    ADD CONSTRAINT view_layouts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: wait_hidden wait_hidden_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wait_hidden
    ADD CONSTRAINT wait_hidden_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: webauthn_creds webauthn_creds_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webauthn_creds
    ADD CONSTRAINT webauthn_creds_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: webhook_log webhook_log_webhook_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_log
    ADD CONSTRAINT webhook_log_webhook_id_fkey FOREIGN KEY (webhook_id) REFERENCES public.webhooks(id) ON DELETE CASCADE;


--
-- Name: webhook_queue webhook_queue_webhook_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_queue
    ADD CONSTRAINT webhook_queue_webhook_id_fkey FOREIGN KEY (webhook_id) REFERENCES public.webhooks(id) ON DELETE CASCADE;


--
-- Name: webhooks webhooks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: wiki_key_pending wiki_key_pending_space_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_key_pending
    ADD CONSTRAINT wiki_key_pending_space_id_fkey FOREIGN KEY (space_id) REFERENCES public.wiki_spaces(id) ON DELETE CASCADE;


--
-- Name: wiki_key_pending wiki_key_pending_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_key_pending
    ADD CONSTRAINT wiki_key_pending_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: wiki_keys wiki_keys_space_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_keys
    ADD CONSTRAINT wiki_keys_space_id_fkey FOREIGN KEY (space_id) REFERENCES public.wiki_spaces(id) ON DELETE CASCADE;


--
-- Name: wiki_keys wiki_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_keys
    ADD CONSTRAINT wiki_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: wiki_keys wiki_keys_wrapped_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_keys
    ADD CONSTRAINT wiki_keys_wrapped_by_fkey FOREIGN KEY (wrapped_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: wiki_links wiki_links_from_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_links
    ADD CONSTRAINT wiki_links_from_id_fkey FOREIGN KEY (from_id) REFERENCES public.wiki_pages(id) ON DELETE CASCADE;


--
-- Name: wiki_pages wiki_pages_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_pages
    ADD CONSTRAINT wiki_pages_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: wiki_pages wiki_pages_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_pages
    ADD CONSTRAINT wiki_pages_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: wiki_pages wiki_pages_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_pages
    ADD CONSTRAINT wiki_pages_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: wiki_pages wiki_pages_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_pages
    ADD CONSTRAINT wiki_pages_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: wiki_spaces wiki_spaces_e2e_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_spaces
    ADD CONSTRAINT wiki_spaces_e2e_by_fkey FOREIGN KEY (e2e_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: wiki_spaces wiki_spaces_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_spaces
    ADD CONSTRAINT wiki_spaces_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: wiki_spaces wiki_spaces_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_spaces
    ADD CONSTRAINT wiki_spaces_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agents; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agents ENABLE ROW LEVEL SECURITY;

--
-- Name: bookmarks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.bookmarks ENABLE ROW LEVEL SECURITY;

--
-- Name: books; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.books ENABLE ROW LEVEL SECURITY;

--
-- Name: clients; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;

--
-- Name: doc_cfg; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.doc_cfg ENABLE ROW LEVEL SECURITY;

--
-- Name: doc_mail; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.doc_mail ENABLE ROW LEVEL SECURITY;

--
-- Name: doc_meta; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.doc_meta ENABLE ROW LEVEL SECURITY;

--
-- Name: doc_models; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.doc_models ENABLE ROW LEVEL SECURITY;

--
-- Name: doc_rules; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.doc_rules ENABLE ROW LEVEL SECURITY;

--
-- Name: doc_senders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.doc_senders ENABLE ROW LEVEL SECURITY;

--
-- Name: doc_tags; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.doc_tags ENABLE ROW LEVEL SECURITY;

--
-- Name: doc_types; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.doc_types ENABLE ROW LEVEL SECURITY;

--
-- Name: ev_cals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ev_cals ENABLE ROW LEVEL SECURITY;

--
-- Name: file_text; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.file_text ENABLE ROW LEVEL SECURITY;

--
-- Name: fs_nodes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fs_nodes ENABLE ROW LEVEL SECURITY;

--
-- Name: hub_absences; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.hub_absences ENABLE ROW LEVEL SECURITY;

--
-- Name: hub_bookings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.hub_bookings ENABLE ROW LEVEL SECURITY;

--
-- Name: hub_mails; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.hub_mails ENABLE ROW LEVEL SECURITY;

--
-- Name: hub_tokens; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.hub_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: agents kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.agents USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: bookmarks kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.bookmarks USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: books kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.books USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: clients kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.clients USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: doc_cfg kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.doc_cfg USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: doc_mail kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.doc_mail USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: doc_meta kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.doc_meta USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: doc_models kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.doc_models USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: doc_rules kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.doc_rules USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: doc_senders kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.doc_senders USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: doc_tags kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.doc_tags USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: doc_types kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.doc_types USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: ev_cals kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.ev_cals USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: file_text kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.file_text USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: fs_nodes kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.fs_nodes USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: hub_absences kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.hub_absences USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: hub_bookings kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.hub_bookings USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: hub_mails kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.hub_mails USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: hub_tokens kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.hub_tokens USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: list_rules kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.list_rules USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: lists kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.lists USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: merge_runs kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.merge_runs USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: nl_conns kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.nl_conns USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: nl_members kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.nl_members USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: nl_runs kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.nl_runs USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: nl_segments kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.nl_segments USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_agreements kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_agreements USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_archive kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_archive USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_archive_log kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_archive_log USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_bank_imports kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_bank_imports USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_bank_tx kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_bank_tx USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_client_contacts kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_client_contacts USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_company kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_company USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_contracts kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_contracts USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_deals kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_deals USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_doc_items kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_doc_items USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_doc_log kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_doc_log USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_doc_parts kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_doc_parts USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_doc_templates kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_doc_templates USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_docs kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_docs USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_drive_log kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_drive_log USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_drives kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_drives USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_equipment kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_equipment USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_fixed_costs kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_fixed_costs USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_gen_docs kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_gen_docs USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_import_runs kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_import_runs USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_inv_series kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_inv_series USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_numbers kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_numbers USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_pack_installs kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_pack_installs USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_pay_props kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_pay_props USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_payments kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_payments USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_purchases kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_purchases USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_roles kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_roles USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_services kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_services USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_sets kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_sets USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_settings kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_settings USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_signoffs kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_signoffs USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_sub_reminders kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_sub_reminders USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_texts kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_texts USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_trip_items kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_trip_items USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_trips kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_trips USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: office_vehicles kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.office_vehicles USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: org_keys kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.org_keys USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: org_list_log kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.org_list_log USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: org_members kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.org_members USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (user_id = (NULLIF(current_setting('app.user_id'::text, true), ''::text))::bigint) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (user_id = (NULLIF(current_setting('app.user_id'::text, true), ''::text))::bigint) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: orgs kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.orgs USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: pl_imported kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.pl_imported USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: pl_rules kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.pl_rules USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: pl_sources kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.pl_sources USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: pl_uploads kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.pl_uploads USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: portal_logins kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.portal_logins USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: portal_tickets kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.portal_tickets USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: rc_receipts kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.rc_receipts USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: rc_suggest kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.rc_suggest USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: sheets kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.sheets USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: task_bell kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.task_bell USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: task_links kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.task_links USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: task_vectors kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.task_vectors USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: upload_scan kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.upload_scan USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: video_comments kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.video_comments USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: video_reviews kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.video_reviews USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: video_versions kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.video_versions USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: wiki_pages kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.wiki_pages USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: wiki_spaces kalmido_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kalmido_org ON public.wiki_spaces USING (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[])))) WITH CHECK (((NULLIF(current_setting('app.role'::text, true), ''::text) = 'system'::text) OR (org_id IS NULL) OR (org_id = ANY ((string_to_array(NULLIF(current_setting('app.org_ids'::text, true), ''::text), ','::text))::bigint[]))));


--
-- Name: list_rules; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.list_rules ENABLE ROW LEVEL SECURITY;

--
-- Name: lists; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.lists ENABLE ROW LEVEL SECURITY;

--
-- Name: merge_runs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.merge_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: nl_conns; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.nl_conns ENABLE ROW LEVEL SECURITY;

--
-- Name: nl_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.nl_members ENABLE ROW LEVEL SECURITY;

--
-- Name: nl_runs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.nl_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: nl_segments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.nl_segments ENABLE ROW LEVEL SECURITY;

--
-- Name: office_agreements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_agreements ENABLE ROW LEVEL SECURITY;

--
-- Name: office_archive; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_archive ENABLE ROW LEVEL SECURITY;

--
-- Name: office_archive_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_archive_log ENABLE ROW LEVEL SECURITY;

--
-- Name: office_bank_imports; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_bank_imports ENABLE ROW LEVEL SECURITY;

--
-- Name: office_bank_tx; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_bank_tx ENABLE ROW LEVEL SECURITY;

--
-- Name: office_client_contacts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_client_contacts ENABLE ROW LEVEL SECURITY;

--
-- Name: office_company; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_company ENABLE ROW LEVEL SECURITY;

--
-- Name: office_contracts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_contracts ENABLE ROW LEVEL SECURITY;

--
-- Name: office_deals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_deals ENABLE ROW LEVEL SECURITY;

--
-- Name: office_doc_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_doc_items ENABLE ROW LEVEL SECURITY;

--
-- Name: office_doc_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_doc_log ENABLE ROW LEVEL SECURITY;

--
-- Name: office_doc_parts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_doc_parts ENABLE ROW LEVEL SECURITY;

--
-- Name: office_doc_templates; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_doc_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: office_docs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_docs ENABLE ROW LEVEL SECURITY;

--
-- Name: office_drive_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_drive_log ENABLE ROW LEVEL SECURITY;

--
-- Name: office_drives; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_drives ENABLE ROW LEVEL SECURITY;

--
-- Name: office_equipment; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_equipment ENABLE ROW LEVEL SECURITY;

--
-- Name: office_fixed_costs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_fixed_costs ENABLE ROW LEVEL SECURITY;

--
-- Name: office_gen_docs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_gen_docs ENABLE ROW LEVEL SECURITY;

--
-- Name: office_import_runs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_import_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: office_inv_series; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_inv_series ENABLE ROW LEVEL SECURITY;

--
-- Name: office_numbers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_numbers ENABLE ROW LEVEL SECURITY;

--
-- Name: office_pack_installs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_pack_installs ENABLE ROW LEVEL SECURITY;

--
-- Name: office_pay_props; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_pay_props ENABLE ROW LEVEL SECURITY;

--
-- Name: office_payments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_payments ENABLE ROW LEVEL SECURITY;

--
-- Name: office_purchases; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_purchases ENABLE ROW LEVEL SECURITY;

--
-- Name: office_roles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_roles ENABLE ROW LEVEL SECURITY;

--
-- Name: office_services; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_services ENABLE ROW LEVEL SECURITY;

--
-- Name: office_sets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_sets ENABLE ROW LEVEL SECURITY;

--
-- Name: office_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: office_signoffs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_signoffs ENABLE ROW LEVEL SECURITY;

--
-- Name: office_sub_reminders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_sub_reminders ENABLE ROW LEVEL SECURITY;

--
-- Name: office_texts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_texts ENABLE ROW LEVEL SECURITY;

--
-- Name: office_trip_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_trip_items ENABLE ROW LEVEL SECURITY;

--
-- Name: office_trips; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_trips ENABLE ROW LEVEL SECURITY;

--
-- Name: office_vehicles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.office_vehicles ENABLE ROW LEVEL SECURITY;

--
-- Name: org_keys; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.org_keys ENABLE ROW LEVEL SECURITY;

--
-- Name: org_list_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.org_list_log ENABLE ROW LEVEL SECURITY;

--
-- Name: org_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.org_members ENABLE ROW LEVEL SECURITY;

--
-- Name: orgs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.orgs ENABLE ROW LEVEL SECURITY;

--
-- Name: pl_imported; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pl_imported ENABLE ROW LEVEL SECURITY;

--
-- Name: pl_rules; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pl_rules ENABLE ROW LEVEL SECURITY;

--
-- Name: pl_sources; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pl_sources ENABLE ROW LEVEL SECURITY;

--
-- Name: pl_uploads; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pl_uploads ENABLE ROW LEVEL SECURITY;

--
-- Name: portal_logins; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.portal_logins ENABLE ROW LEVEL SECURITY;

--
-- Name: portal_tickets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.portal_tickets ENABLE ROW LEVEL SECURITY;

--
-- Name: rc_receipts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.rc_receipts ENABLE ROW LEVEL SECURITY;

--
-- Name: rc_suggest; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.rc_suggest ENABLE ROW LEVEL SECURITY;

--
-- Name: sheets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sheets ENABLE ROW LEVEL SECURITY;

--
-- Name: task_bell; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.task_bell ENABLE ROW LEVEL SECURITY;

--
-- Name: task_links; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.task_links ENABLE ROW LEVEL SECURITY;

--
-- Name: task_vectors; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.task_vectors ENABLE ROW LEVEL SECURITY;

--
-- Name: upload_scan; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.upload_scan ENABLE ROW LEVEL SECURITY;

--
-- Name: video_comments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.video_comments ENABLE ROW LEVEL SECURITY;

--
-- Name: video_reviews; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.video_reviews ENABLE ROW LEVEL SECURITY;

--
-- Name: video_versions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.video_versions ENABLE ROW LEVEL SECURITY;

--
-- Name: wiki_pages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.wiki_pages ENABLE ROW LEVEL SECURITY;

--
-- Name: wiki_spaces; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.wiki_spaces ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict p5X2aQRSk5xstjDtvA31qQM58pvJz39efiP7zi1rlJFM6L8Ei72usCwZ5tbTkEZ

